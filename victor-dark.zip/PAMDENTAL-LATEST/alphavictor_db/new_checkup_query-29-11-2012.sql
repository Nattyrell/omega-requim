SELECT
      l.`patient_login_id`
    , r.`patient_id`
    , r.`is_primary`
    , c.`patient_checkup_id`
    , c.`patient_checkup_id`
    , DATE_FORMAT(c.`date`, \'%h:%i %p\') AS `time`
    , DATE_FORMAT(c.`date`, \'%Y-%m-%d\') AS `date`
    , c.`status`, c.`paid_for`
FROM
    patient_login AS l
    INNER JOIN patient_registration AS r 
        ON (l.`patient_login_id` = r.`patient_login_id`)
    INNER JOIN patient_checkup AS c 
        ON (r.`patient_id` = c.`patient_id`)
WHERE (`patient_login`.`patient_login_id` =2);