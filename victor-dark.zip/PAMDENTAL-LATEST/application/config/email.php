<?php defined('BASEPATH') OR exit('No direct script access allowed');
/** SMTP VARIABLES
 * @author Rohitashva Singh <rohitashvarathore@gmail.com>
 */
$config['useragent'] = 'None';
$config['smtp_host'] = 'mail.ranosys.net';
$config['smtp_user'] = 'mylglobal@ranosys.net';
$config['smtp_pass'] = 'fKx9m?l&_!eQ';
$config['smtp_port'] = 25;
$config['protocol'] = 'smtp';
$config['mailtype'] = 'html';
$config['useragent'] = 'None';
$config['bcc_batch_mode'] = 'TRUE';

/* End of emails.php */
/* Location: ./application/config/emails.php */