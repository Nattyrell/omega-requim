<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

/**
 * PAM DENTAL - ADMIN Controller
 * @author Vaibhav Soni
 * @copyright 2012, Rohitashva Singh
 */
class Admin extends CI_Controller {
    public function __construct()
    {
        parent::__construct();
        $this->load->model('admin/admin_model');
        $this->load->model('patients');
        $this->load->model('dentists');
        $this->load->model('frontoffice_model');
        $this->load->model('emails'); 
        $this->output->enable_profiler(FALSE);
    }

    /** * INDEX function for checking admin is login or not
            *
            * @access public
            * @param none
            * @redirect
            * Vaibhav Soni
            * 11 October 2012
    */
    public function index()
    {
        if($this->session->userdata('admin_login')==1)
        {
                $this->dashboard();
        }
        else
        {
                $this->load->view('admin/login');
        }
    }

    /** * Admin already login or not
            *
            * @access public
            * @param none
            * @redirect
            * Vaibhav Soni
            * 11 October 2012
    */

    private function _is_admin_not_login()
    {
            if($this->session->userdata('admin_login')==1)
                    redirect('admin');
    }

    /** * Admin already login or not
            *
            * @access public
            * @param none
            * @redirect
            * Vaibhav Soni
            * 11 October 2012
    */
    private function _is_admin_login()
    {
            if($this->session->userdata('admin_login')!=1)
                    redirect('admin');
    }

    /** * Login
            *
            * @access public
            * @param none
            * @return array
            * Vaibhav Soni
            * 11 October 2012
    */
    public function login()
    {
            $this->_is_admin_not_login();
            if(isset($_POST['username']))
            {
               $this->form_validation->set_rules('username', 'Username', 'required');
               $this->form_validation->set_rules('password', 'Password', 'required');
               if ($this->form_validation->run() == FALSE)
               {
                       $this->load->view('admin/login');
               }
               else
               {
                 $login_res = $this->admin_model->login();
                 if($login_res)
                 {
                           $this->session->set_userdata('username', $_POST['username']);
                           $this->session->set_userdata('password', $_POST['password']);
                           $this->session->set_userdata('admin_login', TRUE);
                           redirect('admin');
                 }
                 else
                 {
                         $this->session->set_flashdata('error', 'Use a valid username and password');
                         redirect('admin');
                 }
               }
            }
            else
                    redirect('admin');
    }

    /** * Dashboard
            *
            * @access public
            * @param none
            * @dashboard
            * Vaibhav Soni
            * 11 October 2012
    */

    public function dashboard()
    {
            $this->_is_admin_login();
            $data['title']='PAM :: Dashboard';
            $data['js']='<script type="text/javascript" language="javascript" src="'.base_url().'js/admin_home.js"></script>';
            $data['css']='<link type="text/css" rel="stylesheet" href="'.base_url().'css/demo_table.css" />
                                      <link type="text/css" rel="stylesheet" href="'.base_url().'css/admin_style.css" />';
            $this->load->view('admin/dashboard',$data);
    }

    /** * List Of ADA Codes
            *
            * @access public
            * @param none
            * @return array
            * Vaibhav Soni
            * 11 October 2012
    */
    public function ada_list()
    {
        $this->_is_admin_login();
        $data['title']='PAM :: ADA Code List';
        $data['js']='<script type="text/javascript" language="javascript" src="'.base_url().'js/jquery_1.7.1.js"></script>
                                 <script type="text/javascript" language="javascript" src="'.base_url().'js/jquery.dataTables.js"></script>';
        $data['css']='<link type="text/css" rel="stylesheet" href="'.base_url().'css/demo_table.css" />
                                  <link type="text/css" rel="stylesheet" href="'.base_url().'css/admin_style.css" />';
        $data['result']=$this->admin_model->ada_list();
        $this->load->view('admin/ada_list',$data);
    }

    /** * ADD ADA Codes
    *
    * @access public
    * @param none
    * @return boolean
    * Vaibhav Soni
    * 12 October 2012
    */
    public function add_ada_code()
    {
        $this->_is_admin_login();
        $data['title']='PAM :: ADD ADA Code';
        $data['js']='<script type="text/javascript" language="javascript" src="'.base_url().'js/jquery_1.7.1.js"></script>
                                 <script type="text/javascript" language="javascript" src="'.base_url().'js/jquery.dataTables.js"></script>';
        $data['css']='<link type="text/css" rel="stylesheet" href="'.base_url().'css/demo_table.css" />
                                  <link type="text/css" rel="stylesheet" href="'.base_url().'css/admin_style.css" />';
        $this->form_validation->set_rules('ada_code','ADA Code','required|is_unique[ada_codes.ada_code]');
        $this->form_validation->set_rules('description','Description','required');

        if($this->form_validation->run()==FALSE)
        {
                $this->load->view('admin/ada_add_code',$data);
        }
        else
        {
                $this->admin_model->add_ada_code();
                $this->session->set_flashdata('show_message', 'ADA Code has been added successfully!');
                redirect('admin/ada_list');
        }
    }

    /** * Edit ADA Codes
    *
    * @access public
    * @param none
    * @return boolean
    * Vaibhav Soni
    * 12 October 2012
    */
    public function edit_ada_code()
    {
        $this->_is_admin_login();
        $data['title']='PAM :: Edit ADA Code';
        $data['js']='<script type="text/javascript" language="javascript" src="'.base_url().'js/jquery_1.7.1.js"></script>
                                 <script type="text/javascript" language="javascript" src="'.base_url().'js/jquery.dataTables.js"></script>';
        $data['css']='<link type="text/css" rel="stylesheet" href="'.base_url().'css/demo_table.css" />
                                  <link type="text/css" rel="stylesheet" href="'.base_url().'css/admin_style.css" />';
        $data['result']=$this->admin_model->ada_detail();
        $this->form_validation->set_rules('description','Description','required');

        if($this->form_validation->run()==FALSE)
        {
                $this->load->view('admin/ada_edit_code',$data);
        }
        else
        {
                $this->admin_model->edit_ada_code();
                $this->session->set_flashdata('show_message', 'ADA Code has been updated successfully!');
                redirect('admin/ada_list');
        }
    }

    /** * View Treastment List
    *
    * @access public
    * @param none
    * @return array
    * Vaibhav Soni
    * 12 October 2012
    */
    public function ada_treatment_list()
    {
        $this->_is_admin_login();
        $data['title']='PAM :: Treatment List';
        $data['js']='<script type="text/javascript" language="javascript" src="'.base_url().'js/jquery_1.7.1.js"></script>
                                 <script type="text/javascript" language="javascript" src="'.base_url().'js/jquery.dataTables.js"></script>';
        $data['css']='<link type="text/css" rel="stylesheet" href="'.base_url().'css/demo_table.css" />
                                  <link type="text/css" rel="stylesheet" href="'.base_url().'css/admin_style.css" />';
        $data['result']=$this->admin_model->ada_treatment_list();
        $data['record']=$this->admin_model->ada_detail();
        $this->load->view('admin/ada_treatment_list',$data);
    }

    /** * View Treastment List
    *
    * @access public
    * @param none
    * @return array
    * Vaibhav Soni
    * 12 October 2012
    */
    public function ada_add_treatment()
    {
        $this->_is_admin_login();
        $data['title']='PAM :: ADD ADA Treatment';
        $data['js']='<script type="text/javascript" language="javascript" src="'.base_url().'js/jquery_1.7.1.js"></script>
                                 <script type="text/javascript" language="javascript" src="'.base_url().'js/jquery.dataTables.js"></script>';
        $data['css']='<link type="text/css" rel="stylesheet" href="'.base_url().'css/demo_table.css" />
                                  <link type="text/css" rel="stylesheet" href="'.base_url().'css/admin_style.css" />';
        $data['result']=$this->admin_model->ada_detail();

        $this->form_validation->set_rules('description','Description','required');
        $this->form_validation->set_rules('price','Price','required|amount');
        $this->form_validation->set_rules('treatment_insurance','Treatment Insurance','required|amount');
        $this->form_validation->set_rules('treatment_deductable','Treatment Deductable','required|amount');

        if($this->form_validation->run()==FALSE)
        {
                $this->load->view('admin/ada_add_treatment',$data);
        }
        else
        {
                $this->admin_model->ada_add_treatment();
                $this->session->set_flashdata('show_message', 'ADA Treatment has been added successfully!');
                redirect('admin/ada_treatment_list/'.$this->uri->segment(3));
        }
    }

    /** * View Treastment List
    *
    * @access public
    * @param none
    * @return array
    * Vaibhav Soni
    * 12 October 2012
    */
    public function ada_edit_treatment()
    {
        $this->_is_admin_login();
        $data['title']='PAM :: Edit ADA Treatment';
        $data['js']='<script type="text/javascript" language="javascript" src="'.base_url().'js/jquery_1.7.1.js"></script>
                                 <script type="text/javascript" language="javascript" src="'.base_url().'js/jquery.dataTables.js"></script>';
        $data['css']='<link type="text/css" rel="stylesheet" href="'.base_url().'css/demo_table.css" />
                                  <link type="text/css" rel="stylesheet" href="'.base_url().'css/admin_style.css" />';
        $data['result']=$this->admin_model->ada_detail();
        $data['record']=$this->admin_model->ada_treatment_details();

        $this->form_validation->set_rules('description','Description','required');
        $this->form_validation->set_rules('price','Price','required|amount');
        $this->form_validation->set_rules('treatment_insurance','Treatment Insurance','required|amount');
        $this->form_validation->set_rules('treatment_deductable','Treatment Deductable','required|amount');

        if($this->form_validation->run()==FALSE)
        {
                $this->load->view('admin/ada_edit_treatment',$data);
        }
        else
        {
                $this->admin_model->ada_edit_treatment();
                $this->session->set_flashdata('show_message', 'ADA Treatment has been updated successfully!');
                redirect('admin/ada_treatment_list/'.$this->uri->segment(3));
        }
    }

    /** * List Of Teeth Record
    *
    * @access public
    * @param none
    * @return array
    * Vaibhav Soni
    * 11 October 2012
    */
    public function teeth_list()
    {
        $this->_is_admin_login();
        $data['title']='PAM :: Teeth List';
        $data['js']='<script type="text/javascript" language="javascript" src="'.base_url().'js/jquery_1.7.1.js"></script>
                                 <script type="text/javascript" language="javascript" src="'.base_url().'js/jquery.dataTables.js"></script>';
        $data['css']='<link type="text/css" rel="stylesheet" href="'.base_url().'css/demo_table.css" />
                                  <link type="text/css" rel="stylesheet" href="'.base_url().'css/admin_style.css" />';
        $data['result']=$this->admin_model->teeth_list();
        $this->load->view('admin/teeth_list',$data);
    }

    /** * Add Teeth Record
    *
    * @access public
    * @param none
    * @return array
    * Vaibhav Soni
    * 11 October 2012
    */
    public function add_teeth()
    {
        $this->_is_admin_login();
        $data['title']='PAM :: Teeth List';
        $data['js']='<script type="text/javascript" language="javascript" src="'.base_url().'js/jquery_1.7.1.js"></script>
                                 <script type="text/javascript" language="javascript" src="'.base_url().'js/jquery.dataTables.js"></script>';
        $data['css']='<link type="text/css" rel="stylesheet" href="'.base_url().'css/demo_table.css" />
                                  <link type="text/css" rel="stylesheet" href="'.base_url().'css/admin_style.css" />';
        $data['result']=$this->admin_model->teeth_list();
        $this->load->view('admin/teeth_list',$data);
    }

    /** * Edit Teeth Record
    *
    * @access public
    * @param none
    * @return array
    * Vaibhav Soni
    * 11 October 2012
    */
    public function edit_teeth()
    {
        $this->_is_admin_login();
        $data['title']='PAM :: Teeth List';
        $data['js']='<script type="text/javascript" language="javascript" src="'.base_url().'js/jquery_1.7.1.js"></script>
                                 <script type="text/javascript" language="javascript" src="'.base_url().'js/jquery.dataTables.js"></script>';
        $data['css']='<link type="text/css" rel="stylesheet" href="'.base_url().'css/demo_table.css" />
                                  <link type="text/css" rel="stylesheet" href="'.base_url().'css/admin_style.css" />';
        $data['result']=$this->admin_model->teeth_list();
        $this->load->view('admin/teeth_list',$data);
    }

    /** * Change Admin Password
    *
    * @access public
    * @param none
    * @return array
    * Vaibhav Soni
    * 11 October 2012
    */
    public function changepassword()
    {
        $this->_is_admin_login();
        $data['title']='PAM :: Setting';
        $data['css']='<link type="text/css" rel="stylesheet" href="'.base_url().'css/demo_table.css" />
                                  <link type="text/css" rel="stylesheet" href="'.base_url().'css/admin_style.css" />';
        if(isset($_POST['save']))
        {
                $this->form_validation->set_rules('password1', 'Old Password', 'required');
                $this->form_validation->set_rules('password2', 'New Password', 'required');
                $this->form_validation->set_rules('password3', 'Confirmation Password', 'required');
                if ($this->form_validation->run() == FALSE)
                {
                        $this->load->view('admin/change_password',$data);
                }
                else
                {
                        $query = $this->db->get_where('admin_login', array('admin_login_id ' => 1));
                        $result = $query->row();
                        if((md5($_POST['password1']) == $result->password) && ($_POST['password2'] == $_POST['password3']))
                        {
                                $this->db->set('password', md5($_POST['password3']));
                                $this->db->where('admin_login_id ', 1);
                                $this->db->update('admin_login');
                                $this->session->set_flashdata('show_message', 'New Password has been successfully set!');
                        }
                        else
                        {
                                 $this->session->set_flashdata('show_message', 'There is a password mismatch, please type again');
                                 redirect('admin/changepassword');
                        }
                        redirect('admin');
                }

        }
        else
        $this->load->view('admin/change_password',$data);
    }

    /** * List Of Patient
    *
    * @access public
    * @param none
    * @return array
    * Vaibhav Soni
    * 16 October 2012
    */
    public function patient_list()
    {
        $this->_is_admin_login();
        $data['title']='PAM :: Patient List';
        $data['js']='<script type="text/javascript" language="javascript" src="'.base_url().'js/jquery_1.7.1.js"></script>
                                 <script type="text/javascript" language="javascript" src="'.base_url().'js/jquery.dataTables.js"></script>';
        $data['css']='<link type="text/css" rel="stylesheet" href="'.base_url().'css/demo_table.css" />
                                  <link type="text/css" rel="stylesheet" href="'.base_url().'css/admin_style.css" />';
        $data['result']=$this->admin_model->patient_list();
        $this->load->view('admin/patient_list',$data);
    }

    /** * List Of Patient
    *
    * @access public
    * @param none
    * @return array
    * Vaibhav Soni
    * 16 October 2012
    */
    public function patient_log()
    {
        $this->_is_admin_login();
        $patient_id = base64_decode($this->uri->segment(3));
        $data['title']='PAM :: Patient Log';
        $data['js']='<script type="text/javascript" language="javascript" src="'.base_url().'js/jquery_1.7.1.js"></script>
                                 <script type="text/javascript" language="javascript" src="'.base_url().'js/jquery.dataTables.js"></script>';
        $data['css']='<link type="text/css" rel="stylesheet" href="'.base_url().'css/demo_table.css" />
                                  <link type="text/css" rel="stylesheet" href="'.base_url().'css/admin_style.css" />';
        if($patient_id){
           $data['patient_data'] = $this->patients->patient_info(@$patient_id)->row_array();
           $data['guarantor_data'] = $this->patients->guarantor_info(@$patient_id)->row_array();
           $data['us_states'] = $this->patients->us_states();
           $data['result']=$this->admin_model->patient_log();
           $this->load->view('admin/patient_log',$data); 
        }
        else redirect('admin/patient-list');                          
    }

    /** * Details Of Patient
    *
    * @access public
    * @param none
    * @return array
    * Vaibhav Soni
    * 16 October 2012
    */
    public function patient_details()
    {
        $this->_is_admin_login();
        $data['title']='PAM :: Patient Details';
        $data['js']='<script type="text/javascript" language="javascript" src="'.base_url().'js/jquery_1.7.1.js"></script>
                                 <script type="text/javascript" language="javascript" src="'.base_url().'js/jquery.dataTables.js"></script>';
        $data['css']='<link type="text/css" rel="stylesheet" href="'.base_url().'css/demo_table.css" />
                                  <link type="text/css" rel="stylesheet" href="'.base_url().'css/admin_style.css" />';
        $data['result']=$this->admin_model->patient_details();
        $this->load->view('admin/patient_details',$data);
    }


    /** * List Of Patient
    *
    * @access public
    * @param none
    * @return array
    * Vaibhav Soni
    * 16 October 2012
    */
    public function appointment_list()
    {
        $this->_is_admin_login();
        $data['title']='PAM :: Patient Log';
        $data['js']='<script type="text/javascript" language="javascript" src="'.base_url().'js/jquery_1.7.1.js"></script>
                                 <script type="text/javascript" language="javascript" src="'.base_url().'js/jquery.dataTables.js"></script>';
        $data['css']='<link type="text/css" rel="stylesheet" href="'.base_url().'css/demo_table.css" />
                                  <link type="text/css" rel="stylesheet" href="'.base_url().'css/admin_style.css" />';
        $data['result']=$this->admin_model->get_appointment();
        $this->load->view('admin/appointment_list',$data);
    }

    function logout()
    {
        $this->session->sess_destroy();
        redirect('admin');
    }

    public function forgot_password()
    {
        $this->_is_admin_not_login();
        $data['title'] = 'PAM DENTAL - FORGOT PASSWORD';
        $data['page_title'] = 'FORGOT PASSWORD';

        if(isset($_POST['submit']))
        {
            $this->form_validation->set_rules('username', 'USERNAME', 'trim|required');

            if($this->form_validation->run() == FALSE)
                $this->load->view('admin/forgot_password', $data);
            else
            {
                $user_data = $this->admin_model->forgot_password();
                if($user_data)
                {
                    $email_content = '<html>
                                        <body>
                                        <p>Hello <font size=2><code>$first_name</code></font>,</p>
                                        <p>Your PAM login password has been reset successfully!</p>
                                        <p>Access PAM - PATIENT\'s PORTAL, using below details - </p>
                                        <p>USERNAME - <font color="#FF0000" size=2><code>$username</code></font></p>
                                        <p>PASSWORD - <font color="#FF0000" size=2><code>$password</code></font></p>
                                        <p>&nbsp;</p>
                                        <p>\'<strong>CHANGE PASSWORD</strong>\' feature coming up soon...</p>
                                        <p>&nbsp;</p>
                                        <hr/>
                                        <p>ADMIN!</p>
                                      </body>
                                      </html>';
                   $email_content = str_replace('$first_name', $user_data['first_name'], $email_content);
                   $email_content = str_replace('$username', $user_data['username'], $email_content);
                   $email_content = str_replace('$password', $user_data['password'], $email_content);

                   //SEND EMAIL
                   $admin_email_and_name = $this->emails->admin_email_and_name();
                   if(admin_email_and_name){
                       $this->email->from('noreply@pamdental.com', 'noreply');
                       $this->email->to($admin_email_and_name['name']); /*CHANGE THIS LATER*/
                       $this->email->to($this->emails->bcc_emails(3));
                       $this->email->subject('PAM - FORGOT PASSWORD');
                       $this->email->message($email_content);
                       $this->email->send();

                       $this->session->set_flashdata('login_error', 'Your new login details have been mailed to you, please check if mail has not been marked as a spam.');
                       redirect('admin');
                   }
               }
            else
            {
               $this->session->set_flashdata('login_error', 'No such user exists in our database.');
               redirect('admin');
            }
        }
    }
    else
        $this->load->view('admin/forgot_password', $data);
}

    //02/11/2012
    public function dentist_list()
    {
        $this->_is_admin_login();
        $data['title']='PAM :: Dentist List';
        $data['js']='<script type="text/javascript" language="javascript" src="'.base_url().'js/jquery_1.7.1.js"></script>
                                 <script type="text/javascript" language="javascript" src="'.base_url().'js/jquery.dataTables.js"></script>';
        $data['css']='<link type="text/css" rel="stylesheet" href="'.base_url().'css/demo_table.css" />
                                  <link type="text/css" rel="stylesheet" href="'.base_url().'css/admin_style.css" />';
        $data['result']=$this->admin_model->dentist_list();
        $this->load->view('admin/dentist_list',$data);
    }

    public function dentist_log()
    {
        $this->_is_admin_login();
        $data['title']='PAM :: Dentist Log';
        $data['js']='<script type="text/javascript" language="javascript" src="'.base_url().'js/jquery_1.7.1.js"></script>
                                 <script type="text/javascript" language="javascript" src="'.base_url().'js/jquery.dataTables.js"></script>';
        $data['css']='<link type="text/css" rel="stylesheet" href="'.base_url().'css/demo_table.css" />
                                  <link type="text/css" rel="stylesheet" href="'.base_url().'css/admin_style.css" />';
        $data['result']=$this->admin_model->dentist_log();
        $this->load->view('admin/dentist_log',$data);
    }

    public function frontoffice_list()
    {
        $this->_is_admin_login();
        $data['title']='PAM :: Front office Log';
        $data['js']='<script type="text/javascript" language="javascript" src="'.base_url().'js/jquery_1.7.1.js"></script>
                                 <script type="text/javascript" language="javascript" src="'.base_url().'js/jquery.dataTables.js"></script>';
        $data['css']='<link type="text/css" rel="stylesheet" href="'.base_url().'css/demo_table.css" />
                                  <link type="text/css" rel="stylesheet" href="'.base_url().'css/admin_style.css" />';
        $data['result']=$this->admin_model->frontoffice_list();
        $this->load->view('admin/front_office_list',$data);
    }

    public function frontoffice_log()
    {
        $this->_is_admin_login();
        $data['title']='PAM :: Front office Log';
        $data['js']='<script type="text/javascript" language="javascript" src="'.base_url().'js/jquery_1.7.1.js"></script>
                                 <script type="text/javascript" language="javascript" src="'.base_url().'js/jquery.dataTables.js"></script>';
        $data['css']='<link type="text/css" rel="stylesheet" href="'.base_url().'css/demo_table.css" />
                                  <link type="text/css" rel="stylesheet" href="'.base_url().'css/admin_style.css" />';
        $data['result']=$this->admin_model->frontoffice_log();
        $this->load->view('admin/frontoffice_log',$data);
    }

    /** * PATIENT BILLING HISTORY
     * @author Rohitashva Singh <rohitashvarathore@gmail.com>
     * @access public
     * @param none
     * 11/11/2012 1:16AM
     */
    public function patient_billing_history(){
        $this->_is_admin_login();
        $data['title']='PAM :: Patient Billing Archive';
        $data['js']='<script type="text/javascript" language="javascript" src="'.base_url().'js/jquery_1.7.1.js"></script>
                     <script type="text/javascript" language="javascript" src="'.base_url().'js/jquery.dataTables.js"></script>';
        $data['css']='<link type="text/css" rel="stylesheet" href="'.base_url().'css/demo_table.css" />
                      <link type="text/css" rel="stylesheet" href="'.base_url().'css/admin_style.css" />';
        $patient_id = base64_decode($this->uri->segment(3));
        if($patient_id){
            $data['result'] = $this->admin_model->patient_billing_history($patient_id, 1);
            //if($data['result'])
                $this->load->view('admin/patient_billing_history', $data);
            //else redirect('admin/patient-list');
        }
        else redirect('admin/patient-list');
    }

    /** * PATIENT BILLING DETAIL
     * @author Rohitashva Singh <rohitashvarathore@gmail.com>
     * @access public
     * @param none
     * 11/11/2012 2:13AM
     */
    public function billing_detail(){
        $this->_is_admin_login();
        $patient_checkup_id = base64_decode($this->uri->segment(3));
        $patient_id = base64_decode($this->uri->segment(4));
        $data['title']='PAM :: PATIENT BILLING DETAIL';
        $data['js']='<script type="text/javascript" language="javascript" src="'.base_url().'js/jquery_1.7.1.js"></script>
                     <script type="text/javascript" language="javascript" src="'.base_url().'js/jquery.dataTables.js"></script>';
        $data['css']='<link type="text/css" rel="stylesheet" href="'.base_url().'css/demo_table.css" />
                      <link type="text/css" rel="stylesheet" href="'.base_url().'css/admin_style.css" />';
        if($patient_id && $patient_checkup_id){
            $data['billing_detail'] = $this->admin_model->billing_detail($patient_id, $patient_checkup_id);
            $data['treatment_detail'] = $this->patients->get_checkup_for_pay($patient_id, $patient_checkup_id);
            $data['patient_address'] = $this->admin_model->patient_address($patient_id);
            $data['us_states'] = $this->patients->us_states();
            if($data['billing_detail'] && $data['patient_address'])
                $this->load->view('admin/patient_billing_detail', $data);
            else redirect('admin/patient-list');
        }
        else redirect('admin/patient-list');
    }

    /**
     * @author Rohitashva Singh <rohitashvarathore@gmail.com>
     * @param none
     * 12/11/2012 1:22AM
     */
    public function billing_history(){
        $this->_is_admin_login();
        $data['title']='PAM :: Billing Archive';
        $data['js']='<script type="text/javascript" language="javascript" src="'.base_url().'js/jquery_1.7.1.js"></script>
                     <script type="text/javascript" language="javascript" src="'.base_url().'js/jquery.dataTables.js"></script>';
        $data['css']='<link type="text/css" rel="stylesheet" href="'.base_url().'css/demo_table.css" />
                      <link type="text/css" rel="stylesheet" href="'.base_url().'css/admin_style.css" />';
        $data['result'] = $this->admin_model->billing_history();
        $this->load->view('admin/billing_history', $data);
    }

    /** PATIENT CHECKUP ARCHIVE
     * @author Rohitashva Singh <rohitashvarathore@gmail.com>
     * @param none
     * 13-11-2012 6:52PM (_____________HAPPY DIWALI______________[FIRECRACKERS ALL AROUND])
     */
    public function view_patient_checkup(){
        $this->_is_admin_login();
        $patient_id = base64_decode($this->uri->segment(3));
        if($patient_id){
            $data['title']='PAM :: View Checkup';

            $data['js']='<script type="text/javascript" language="javascript" src="'.base_url().'js/jquery_1.7.1.js"></script>
                         <script type="text/javascript" language="javascript" src="'.base_url().'js/jquery.dataTables.js"></script>';
            $data['css']='<style type="text/css" title="currentStyle">
                          @import "'.base_url().'css/demo_table.css";
                          @import "'.base_url().'css/admin_style.css";
                          </style>';
            $data['result'] = $this->frontoffice_model->patient_checkup_archive($patient_id);
            //if($data['result'])
                $this->load->view('admin/view_patient_checkup',$data);
            //else redirect('admin/patient-list');
        }
        else redirect('admin/patient-list');
    }

    /** PATIENT CHECKUP DETAIL
     * @author Rohitashva Singh <rohitashvarathore@gmail.com>
     * @param none
     * 13-11-2012 7:18PM (_____________HAPPY DIWALI______________[FIRECRACKERS BUZZING ALL AROUND])
     */
    public function view_patient_checkup_detail(){
        $this->_is_admin_login();
        $patient_checkup_id = base64_decode($this->uri->segment(3));
        $patient_id = base64_decode($this->uri->segment(4));
        if($patient_checkup_id && $patient_id){
            $data['title']='PAM :: View Checkup Detail';
            $data['js']='<script type="text/javascript" language="javascript" src="'.base_url().'js/jquery_1.7.1.js"></script>
                         <script type="text/javascript" language="javascript" src="'.base_url().'js/jquery.dataTables.js"></script>
                         <script type="text/javascript" src="'.base_url().'js/patient/jquery-1.4.4.min.js"></script>
                         <script type="text/javascript" src="'.base_url().'js/patient/jquery.reveal.js"></script>';
            $data['css']='<style type="text/css" title="currentStyle">
                          @import "'.base_url().'css/admin_style.css";
                          @import "'.base_url().'css/patient/reveal.css";
                          </style>';
            /** ---------------------DATA--------------------- */	   
            $data['get_checkup'] = $this->patients->get_checkup(@$patient_id, @$patient_checkup_id);
            $data['get_checkup_detail'] = $this->patients->get_checkup_detail(@$patient_id, @$patient_checkup_id);
            $data['patient_data'] = $this->patients->patient_info(@$patient_id)->row_array();
	    // ADDED 30-111-2012 6:45 PM
	    $data['guarantor_data'] = $this->patients->guarantor_info(@$patient_id)->row_array();
	    // -------------------------
            $data['us_states'] = $this->patients->us_states();
            $data['get_checkup_price'] = $this->patients->get_checkup_price(@$patient_id, $patient_checkup_id);
	    /** ---------------------------------------------- */
            if($data['get_checkup'] && $data['patient_data'] && $data['get_checkup_detail'] && $data['get_checkup_price']){
                $this->load->view('admin/view_patient_checkup_detail', $data);
            }
            else
                redirect ('admin/patient-list');
        }
        else
            redirect ('admin/patient-list');
    }

    /** Edit Front office Info
    *	vaibhav soni
    *	17-11-2012
    */
    public function frontoffice_edit()
    {
        $this->_is_admin_login();
        $data['title']='PAM :: Front office Edit';
        $data['js']='<script type="text/javascript" language="javascript" src="'.base_url().'js/jquery_1.7.1.js"></script>
                                 <script type="text/javascript" language="javascript" src="'.base_url().'js/jquery.dataTables.js"></script>';
        $data['css']='<link type="text/css" rel="stylesheet" href="'.base_url().'css/demo_table.css" />
                                  <link type="text/css" rel="stylesheet" href="'.base_url().'css/admin_style.css" />';
        $data['record']=$this->admin_model->frontoffice_list()->row();

        $this->form_validation->set_rules('first_name','First Name','required');
        $this->form_validation->set_rules('last_name','Last Name','required');
        $this->form_validation->set_rules('email','Email','required|valid_email');
        $this->form_validation->set_rules('username','Username','required');
        if(isset($_POST['password']) && $_POST['password']!='')
                $this->form_validation->set_rules('conf_password','Confirm Password','required|matches[password]');

        if($this->form_validation->run()==FALSE)
        {
           $this->load->view('admin/front_office_edit',$data);
        }
        else
        {
            $this->admin_model->update_frontoffice_detail();
            if(isset($_POST['password']) && $_POST['password']!='')
                $this->_send_email('frontoffice',$_POST);
            $this->session->set_flashdata('profile_updated', 'Profile Successfully updated.');
            redirect('admin/frontoffice_edit/'.$this->uri->segment(3));
        }

    }

    /** Edit Dentist Info
    *	vaibhav soni
    *	17-11-2012
    */
    public function dentist_edit()
    {
        $this->_is_admin_login();
        $data['title']='PAM :: Dentist Edit';
        $data['js']='<script type="text/javascript" language="javascript" src="'.base_url().'js/jquery_1.7.1.js"></script>
                                 <script type="text/javascript" language="javascript" src="'.base_url().'js/jquery.dataTables.js"></script>';
        $data['css']='<link type="text/css" rel="stylesheet" href="'.base_url().'css/demo_table.css" />
                                  <link type="text/css" rel="stylesheet" href="'.base_url().'css/admin_style.css" />';
        $data['record']=$this->admin_model->dentist_list()->row();

        $this->form_validation->set_rules('first_name','First Name','required');
        $this->form_validation->set_rules('last_name','Last Name','required');
        $this->form_validation->set_rules('clinic_name','Clinic Name','required');
        $this->form_validation->set_rules('email','Email','required|valid_email');
        $this->form_validation->set_rules('username','Username','required');
        $this->form_validation->set_rules('phone','Phone','required|validate_phone_number[phone]');
        $this->form_validation->set_rules('address_street','Street','required');
        $this->form_validation->set_rules('address_city','City','required');
        $this->form_validation->set_rules('address_zipcode','Zipcode','required');
        if(isset($_POST['password']) && $_POST['password']!='')
            $this->form_validation->set_rules('conf_password','Confirm Password','required|matches[password]');

        if($this->form_validation->run()==FALSE)
        {
           $this->load->view('admin/dentist_edit',$data);
        }
        else
        {
            $this->admin_model->update_dentist_detail();
            if(isset($_POST['password']) && $_POST['password']!='')
                $this->_send_email('dentist',$_POST);
            $this->session->set_flashdata('profile_updated', 'Profile Successfully updated.');
            redirect('admin/dentist_edit/'.$this->uri->segment(3));
        }

    }
	
    private function _send_email($to,$post)
    {
            $email_content = '<html>
                              <body>
                                            <p>Dear <font size=2><code>$name</code></font>,</p>
                                            <pYour "Sign In" details for PAM: $portal Portal are as under:</p>
                                            <p>Access PAM - PATIENT\'s PORTAL, using below details - </p>
                                            <p>USERNAME - <font color="#FF0000" size=2><code>$username</code></font></p>
                                            <p>PASSWORD - <font color="#FF0000" size=2><code>$password</code></font></p>
                                            <p>&nbsp;</p>
                                            <hr/>
                                            <p>Hope your experience with PAM DENTAL was up to your expectations. In case you have any ideas or suggestions, 
                                                    please feel free to give us your feedback.</p>
                                            <p>&nbsp;</p>
                                            <p>ADMIN</p>
                                            <p>PAM DENTAL</p>
                                            <p><b>THIS IS A SYSTEM GENERATED MAIL. REPLIES TO THIS MAIL ID WILL NOT BE RESPONDED.</b></p>
                                      </body>
                            </html>';
            switch($to){
                    case 'dentist':
                        $email_content = str_replace('$name', $post['first_name'].' '.$post['last_name'], $email_content);	
                        $email_content = str_replace('$portal', 'Dentist', $email_content);
                        $email_content = str_replace('$username', $post['username'], $email_content);
                        $email_content = str_replace('$password', $post['password'], $email_content);

                        $dentist_email_and_name = $this->emails->dentist_email_and_name();
                        if($dentist_email_and_name){
                            $this->email->from('noreply@pamdental.com', 'noreply');
                            $this->email->to($dentist_email_and_name['email']);
                            $this->email->bcc($this->emails->bcc_emails(3));
                            $this->email->subject('Password Reset Confirmation');
                            $this->email->message($email_content);
                            $this->email->send();
                        }	
                    	break;
                        
                    case 'frontoffice':
                        $email_content = str_replace('$name', $post['first_name'].' '.$post['last_name'], $email_content);	
                        $email_content = str_replace('$portal', 'Frontoffice', $email_content);
                        $email_content = str_replace('$username', $post['username'], $email_content);
                        $email_content = str_replace('$password', $post['password'], $email_content);

                        $frontoffice_email_and_name = $this->emails->frontoffice_email_and_name();
                        if($frontoffice_email_and_name){
                            $this->email->from('noreply@pamdental.com', 'noreply');
                            $this->email->to($frontoffice_email_and_name['email']);
                            $this->email->bcc($this->emails->bcc_emails(3));
                            $this->email->subject('Password Reset Confirmation');
                            $this->email->message($email_content);
                            $this->email->send();
                        }    	
                        break;
            }
            
    }
}

/* End of file admin.php */
/* Location: ./application/controllers/admin.php */