<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

/**
 * PAM DENTAL - Dentist Controller
 * @author Rohitashva Singh <rohitashvarathore@gmail.com>
 * @copyright 2012, Rohitashva Singh
 */
class Dentist extends CI_Controller {

    public function __construct()
    {
        parent::__construct();
        $this->load->model('dentists');
        $this->load->model('patients');
        $this->load->model('emails');
        $this->output->enable_profiler(FALSE);
    }

    public function index()
    {
        $this->_is_login();
        $data['title'] = 'PAM DENTAL - DENTIST ACCESS MANAGER';
        $data['page_title'] = 'DENTIST ACCESS MANAGER';
        $data['css'] = '<link href="'.base_url().'css/patient/tipTip.css" media="screen" rel="stylesheet" type="text/css" />';
        $data['js'] = '<script type="text/javascript" src="'.base_url().'js/patient/jquery-1.4.4.js"></script>
                       <script type="text/javascript" src="'.base_url().'js/patient/jquery.tipTip.js"></script>
                       <script type="text/javascript" src="'.base_url().'js/patient/jquery.tipTip.minified.js"></script>';
        if(isset($_POST['login']))
		{
            $this->form_validation->set_rules('username', 'User Name', 'trim|required');
            $this->form_validation->set_rules('password', 'Password', 'trim|required');

            if($this->form_validation->run() == FALSE)
                $this->load->view('dentist/dentist_login', $data);
            else
	    {
                $dentist_login_data = $this->dentists->dentist_login();
		if($dentist_login_data)
		{
                    $dentist_data = array(
                            'user_type' => 'dentist',
                            'user_id' => $dentist_login_data->dentist_login_id,
                             );
                    $this->session->set_userdata($dentist_data);
                    $this->dentists->update_last_login($dentist_login_data->dentist_login_id);
                    $this->dentists->dentist_log($dentist_login_data->dentist_login_id, 'Dentist logs into PAM.');
		    redirect('dentist/home');
                }
               else
		    {
			$this->session->set_flashdata('login_error', 'Username and Password do not match.');
			redirect('dentist');
		    }
            }
        }
        else
            $this->load->view('dentist/dentist_login', $data);
    }

    public function logout()
	{
        $this->session->userdata('user_id') ? $this->dentists->dentist_log($this->session->userdata('user_id'), 'Dentist logs out of PAM.') : '';
        $this->session->sess_destroy();
        redirect('dentist');
    }

    public function home()
	{
        $this->_is_not_login();
        $data['title'] = 'PAM DENTAL - DENTIST HOME PAGE';
        $data['page_title'] = 'DENTIST HOME PAGE';
        $data['js']='<script type="text/javascript" language="javascript" src="'.base_url().'js/jquery_1.7.1.js"></script>
                     <script type="text/javascript" language="javascript" src="'.base_url().'js/jquery.dataTables.js"></script>';
        $data['css']='<style type="text/css" title="currentStyle">
                        @import "'.base_url().'css/demo_table_jui.css";
                        @import "'.base_url().'css/redmond/jquery-ui-1.9.1.custom.css";
                    </style>';
	$data['patients'] = $this->dentists->get_patients();
        $this->load->view('dentist/dentist_home', $data);
    }

    private function _is_not_login(){ //Redirect to 'LOGIN PAGE' if user has not logged in already.
        if(($this->session->userdata('user_type')!='dentist'))
            redirect('dentist');
    }

    private function _is_login(){ //Redirect to 'HOME PAGE' if user has logged in already.
        if(($this->session->userdata('user_type')=='dentist')){
               redirect ('dentist/home');
        }
    }

    public function submit_application()
    {
        $this->_is_not_login();
        $data['title'] = 'PAM DENTAL - PATIENT APPLICATION';
        $data['page_title'] = 'APPLY TREATMENT';
        /**
         * 18-11-2012 8:25PM
         * @author Rohitashva Singh
         */
        $data['css'] = '<style type="text/css" title="currentStyle">
                        @import "'.base_url().'css/timepicker/style.css";
                        @import "'.base_url().'css/timepicker/ui/base/ui.core.css";
                        @import "'.base_url().'css/timepicker/ui/base/ui.theme.css";
                        @import "'.base_url().'css/timepicker/ui/base/ui.slider.css";
                        @import "'.base_url().'css/timepicker/jquery.timepicker.css";
                        </style>';
        $data['js'] = ' <script type="text/javascript" language="javascript" src="'.base_url().'js/jquery_1.7.1.js"></script>
                        <script type="text/javascript" src="'.base_url().'js/timepicker/jquery-1.3.2.min.js"></script>
                        <script type="text/javascript" src="'.base_url().'js/timepicker/ui.core.js"></script>
                        <script type="text/javascript" src="'.base_url().'js/timepicker/ui.slider.js"></script>
                        <script type="text/javascript" src="'.base_url().'js/timepicker/jquery.jtimepicker.js"></script>';
        /** ----------------------------- */
        $data['patient_id'] = $this->uri->segment(3);
        $data['teeth'] = $this->dentists->get_teeth();
        $data['ada_codes'] = $this->dentists->get_ada_codes();
		$data['error']= '';
		if(isset($_POST['submit']) || isset($_POST['submit_and_return']))
		{
            for($i=0;$i<$_POST['theValue'];$i++):
                    $this->form_validation->set_rules('teeth['.$i.']', 'Teeth', 'required');
                    $this->form_validation->set_rules('ada_codes['.$i.']', 'Ada Code', 'required');
                    $this->form_validation->set_rules('treatment['.$i.']', 'Treatment', 'required');
            endfor;
            if($this->form_validation->run() == FALSE)
                {
                    $data['error']= 'Please select all options';
                    $this->load->view('dentist/submit_patient_info', $data);
                }
                else
                {
                   $patient_checkup_id = $this->dentists->submit_patient_info($_POST);
                   $this->dentists->dentist_log($this->session->userdata('user_id'), 'Dentist recommends a treatment for a patient[#'.@$_POST['patient_id'].'].');
                   $this->_send_post_treatment_mail($_POST['patient_id'], $patient_checkup_id);
                   //Rohitashva Singh, 18-11-2012 9:59 PM
                   $this->session->set_flashdata('treatment_rec_msg', 'Treatment recommended.');
                    if(isset($_POST['submit_and_return']))
                        redirect('dentist/submit-application/'.$data['patient_id']);
                    else
                        redirect('dentist/treatment-archive');
                }
		}
		else
    	    $this->load->view('dentist/submit_patient_info', $data);
    }

    public function get_treatment()
    {
        $this->_is_not_login();
        $ada_code_id = $_POST['ada_id'];
        $result = $this->dentists->get_ada_treatment($ada_code_id);

        foreach($result as $row):
		$selected = ($_POST['treat_id']==$row->treat_id)? 'selected="selected"': '' ;
        echo "<option value='".$row->treat_id."' id='".$row->treat_id."' ".$selected.">".$row->description."</option>";
        endforeach;
    }

    public function get_set()
    {
        $this->_is_not_login();

        $set_id = $_POST['set_id'];
        $teeth = $this->dentists->get_teeth();
        $ada_codes = $this->dentists->get_ada_codes();
        echo '<table>';
		echo "<tr>";
        echo "<td>
                        <select name='teeth[]' id='teeth[]'>";
        echo "<option value='' select='selected'>";
        echo 'Please Select Teeth';
        echo "</option>";
                        foreach($teeth as $row) :
                        echo "<option value=".$row->tooth_id.">";
                        echo $row->tooth_id;
                        echo "</option>";
                        endforeach;
        echo "</td>";
        echo "<td>";
        echo "<select name='ada_codes[]' onchange='get_ada_treatment(this.value,".$set_id.");'>";
        echo "<option value='' select='selected'>".'Select ADA code'."</option>";
        foreach($ada_codes as $row) :
        echo "<option value= '".$row->ada_code_id."' >". $row->ada_code."</option>";
        endforeach;
        echo "</select>";
        echo "</td>";
        echo "<td>";
        echo "<select name='treatment[]' id='treatment_".$set_id."' style='width:220px;'>";
        echo "<option value='' select='selected'>". 'Please Select'."</option>";
        echo "</select></td>";
        //echo "<td><a href='#' onclick='add_more_teeth();'>".'Add More'."</a></td>";
        //echo "<td><a href='#' style='cursor:pointer' onclick='removeElement(".'tbl_translation'.$set_id");'> ".'Remove'."</a></td>";
        ?>
        <td><a style="cursor:pointer" href="#" onclick="removeElement('<?php echo 'tbl_translation'.$set_id; ?>')">Remove</a></td></tr></table>
        <?php
    }

    public function submit_patient_info()
    {
        $this->_is_not_login();
        $data['title'] = 'PAM DENTAL - PATIENT APPLICATION';
        $data['page_title'] = 'SUBMIT PATIENT INFO';
        $patient_checkup_id = $this->dentists->submit_patient_info($_POST);
        $this->dentists->dentist_log($this->session->userdata('user_id'), 'Dentist recommends a treatment for a patient[#'.@$_POST['patient_id'].'].');
        $this->_send_post_treatment_mail($_POST['patient_id'], $patient_checkup_id);
        redirect('dentist/treatment-archive');
    }

    /** * POST 'RECOMMEND TREATMENT' EMAIL TO PATIENT, DENTIST(CC), FRONT OFFICE (BCC) & ADMIN (BCC)
    * @access private
    * @param - 'patient_checkup_id', 'patient_id'
    * @return array
    * @author Rohitashva Singh <rohitashvarathore@gmail.com>
    * MODIFIED 8-12-2012 10:45 PM
    */
    private function _send_post_treatment_mail($patient_id, $patient_checkup_id){
        $this->_is_not_login();

        //$this->db->select('first_name, email');
        //$this->db->where('patient_id', $patient_id);
        //$patient_query = $this->db->get('patient_registration')->row_array();
        $frontoffice_email_and_name = $this->emails->frontoffice_email_and_name();
        $dentist_email_and_name = $this->emails->dentist_email_and_name();
        $bcc_emails = $this->emails->bcc_emails(1);//ADMIN

        if($frontoffice_email_and_name && $dentist_email_and_name){

            $data['get_checkup'] = $this->patients->get_checkup(@$patient_id, @$patient_checkup_id);
            $data['get_checkup_detail'] = $this->patients->get_checkup_detail(@$patient_id, @$patient_checkup_id);
            $data['patient_data'] = $this->patients->patient_info(@$patient_id)->row_array();
            // ADDED 30-111-2012 6:45 PM
            $data['guarantor_data'] = $this->patients->guarantor_info(@$patient_id)->row_array();
            // -------------------------
                $data['us_states'] = $this->patients->us_states();
                $data['get_checkup_price'] = $this->patients->get_checkup_price(@$patient_id, $patient_checkup_id);
            /** ---------------------------------------------- */
            if($data['get_checkup'] && $data['patient_data'] && $data['get_checkup_detail'] && $data['get_checkup_price'])
            {

                $email_content =   '<html>
                                    <body style="font-family: Verdana,Arial,Helvetica,sans-serif; font-size: 13px;">
                                    hi '.$frontoffice_email_and_name['first_name'].','.br(2).'
                                     A new treatment plan has been recommended for a Patient by Dentist. Details are provided below - '.br(2).'';
                $email_content.= $this->load->view('dentist/dentist_post_treatment_email', $data, True);
                $email_content.= br(3).'Login into your account here - '.base_url().'frontoffice'.nbs(2).'and review the said treatment plan.';
                $email_content.= br(2).'<p>In case you have any ideas or suggestions, please feel free to give us your feedback - <a href="mailto:admin@pamdental.com">admin@pamdental.com</a></p>';
                $email_content.= br(2).'<p>ADMIN<br/>PAM DENTAL</p>';
                $email_content.= br(2).'<b>'.'THIS IS A SYSTEM GENERATED MAIL. REPLIES TO THIS MAIL ID WILL NOT BE RESPONDED.'.'</b>';
                $email_content.= br(2).'</body></html>';
                $this->email->from('noreply@pamdental.com', 'noreply');
                $this->email->to($frontoffice_email_and_name['email']);
                $this->email->cc($dentist_email_and_name['email']);
                $this->email->bcc($bcc_emails);
                $this->email->subject('PAM DENTAL:: A new Treatment Recommended for Patient');
                $this->email->message($email_content);
                $this->email->send();
            }
        }
    }

    /**
     * modified 29-10-2012 10:45 AM
     * @author Rohitashva Singh <rohitashvarathore@gmail.com>
     * access public
    */
    public function treatment_archive()
    {
        $this->_is_not_login();
        $data['title'] = 'PAM DENTAL - TREATMENT ARCHIVE';
        $data['page_title'] = 'TREATMENT ARCHIVE - LIST VIEW';
        $data['js']='<script type="text/javascript" language="javascript" src="'.base_url().'js/jquery_1.7.1.js"></script>
                     <script type="text/javascript" language="javascript" src="'.base_url().'js/jquery.dataTables.js"></script>';
        $data['css']='<style type="text/css" title="currentStyle">
                        @import "'.base_url().'css/demo_table_jui.css";
                        @import "'.base_url().'css/redmond/jquery-ui-1.9.1.custom.css";
                        @import "'.base_url().'css/patient/reveal.css";
                    </style>';
        $data['patient_checkups'] = $this->dentists->patient_checkups();
        $this->load->view('dentist/treatment_archive', $data);
    }

    /**
     * modified 29-10-2012 12:30 PM
     * @author Rohitashva Singh <rohitashvarathore@gmail.com>
     * access public
    */
    public function view_treatment_archive()
    {
        $this->_is_not_login();
        $patient_checkup_id = base64_decode($this->uri->segment(3));
        $patient_id = base64_decode($this->uri->segment(4));
        if($patient_checkup_id && $patient_id){
            $data['title'] = 'PAM DENTAL - TREATMENT ARCHIVE';
            $data['page_title'] = 'TREATMENT ARCHIVE - DETAIL VIEW';
            $data['css'] = '<link href="'.base_url().'css/patient/reveal.css" media="screen" rel="stylesheet" type="text/css" />';
             $data['js'] = '<script type="text/javascript" src="'.base_url().'js/patient/jquery-1.4.4.min.js"></script>
                            <script type="text/javascript" src="'.base_url().'js/patient/jquery.reveal.js"></script>';
            /** ---------------------DATA--------------------- */	   
            $data['get_checkup'] = $this->patients->get_checkup(@$patient_id, @$patient_checkup_id);
            $data['get_checkup_detail'] = $this->patients->get_checkup_detail(@$patient_id, @$patient_checkup_id);
            $data['patient_data'] = $this->patients->patient_info(@$patient_id)->row_array();
            // ADDED 30-111-2012 6:45 PM
            $data['guarantor_data'] = $this->patients->guarantor_info(@$patient_id)->row_array();
            // -------------------------
                $data['us_states'] = $this->patients->us_states();
                $data['get_checkup_price'] = $this->patients->get_checkup_price(@$patient_id, $patient_checkup_id);
            /** ---------------------------------------------- */
            if($data['get_checkup'] && $data['patient_data'] && $data['get_checkup_detail'] && $data['get_checkup_price']){
                $this->dentists->dentist_log($this->session->userdata('user_id'), 'Dentist views treatment archive[Patient - #'.@$patient_id.'].');
                $this->load->view('dentist/view_treatment_archive', $data);
            }
            else
                redirect ('dentist/treatment-archive/');
        }
        else
            redirect ('dentist/treatment-archive/');
    }

    /** * PATIENT DETAIL
    *
    * @access public
    * @param none
    * @return array
    * @author Rohitashva Singh <rohitashvarathore@gmail.com>
    * 1 November 2012
    */
    public function patient_detail(){
        $this->_is_not_login();
        $patient_id = base64_decode($this->uri->segment(3));
        if($patient_id){
            $data['title'] = 'PAM DENTAL - PATIENT PROFILE';
            $data['page_title'] = 'PATIENT PROFILE';
            $data['js']='<script type="text/javascript" language="javascript" src="'.base_url().'js/jquery_1.7.1.js"></script>
                         <script type="text/javascript" src="'.base_url().'js/patient/jquery.tipTip.js"></script>
                         <script type="text/javascript" src="'.base_url().'js/patient/jquery.tipTip.minified.js"></script>';
            $data['css'] = '<link href="'.base_url().'css/patient/tipTip.css" media="screen" rel="stylesheet" type="text/css" />';
            $data['result'] = $this->dentists->patient_details($patient_id);
            $data['us_states'] = $this->patients->us_states();
            $this->dentists->dentist_log($this->session->userdata('user_id'), 'Dentist views profile of a patient[#'.@$patient_id.'].');
            $this->load->view('dentist/dentist_view_patient_profile', $data);
        }
        else
            redirect('dentist/home');
    }

	//forgot password
	//vaibhav soni
	//11-11-12
	public function forgot_password()
    {
        $this->_is_login();
        $data['title'] = 'PAM DENTAL - FORGOT PASSWORD';
        $data['page_title'] = 'FORGOT PASSWORD';
        if(isset($_POST['submit']))
        {
            $this->form_validation->set_rules('username', 'USERNAME', 'trim|required');

            if($this->form_validation->run() == FALSE)
                $this->load->view('frontoffice/frontoffice_forgot_password', $data);
            else{
                //echo $this->_generateRandomString();
                $user_data = $this->dentists->forgot_password();
                if($user_data){
                    //echo $user_data;
                    $email_content = '<html>
                                        <body>
                                        <p>Hello <font size=2><code>$first_name</code></font>,</p>
                                        <p>Your PAM login password has been reset successfully!</p>
                                        <p>Access PAM - PATIENT\'s PORTAL, using below details - </p>
                                        <p>USERNAME - <font color="#FF0000" size=2><code>$username</code></font></p>
                                        <p>PASSWORD - <font color="#FF0000" size=2><code>$password</code></font></p>
                                        <p>&nbsp;</p>
                                        <p>\'<strong>CHANGE PASSWORD</strong>\' feature coming up soon...</p>
                                        <p>&nbsp;</p>
                                        <hr/>
                                        <p>ADMIN!</p>
                                      </body>
                                      </html>';
                   $email_content = str_replace('$first_name', $user_data['first_name'], $email_content);
                   $email_content = str_replace('$username', $user_data['username'], $email_content);
                   $email_content = str_replace('$password', $user_data['password'], $email_content);

                   //SEND EMAIL
                   $this->email->from('noreply@pamdental.com', 'noreply');
                   $this->email->to('rohitashvarathore@gmail.com'); /*CHANGE THIS LATER*/
                   //$this->email->bcc('rohitashvarathore@gmail.com');
                   $this->email->subject('PAM DENTAL:: FORGOT PASSWORD');
                   $this->email->message($email_content);
                   $this->email->send();

                   $this->session->set_flashdata('login_error', 'Your new login details have been mailed to you, please check if mail has not been marked as a spam.');
                   redirect('dentist');
                   }
                else{
                   $this->session->set_flashdata('login_error', 'No such user exists in our database.');
                   redirect('dentist');
                }
            }
        }
        else
            $this->load->view('dentist/dentist_forgot_password', $data);
    }

    public function setting()
    {
        $this->_is_not_login();
        $data['title'] = 'PAM DENTAL - Setting';
        $data['page_title'] = 'DENTIST ACCESS MANAGER';
        $data['result']=$this->dentists->dentist_detail();

        $this->form_validation->set_rules('first_name','First Name','required');
        $this->form_validation->set_rules('last_name','Last Name','required');
        $this->form_validation->set_rules('email','E-mail','required|email');
        $this->form_validation->set_rules('username','Username','required');

        if(isset($_POST['password']) && $_POST['password']!='')
        $this->form_validation->set_rules('conf_password','Confirm Password','required|matches[password]');

        if($this->form_validation->run()==FALSE)
        {
                $this->load->view('dentist/dentist_setting',$data);
        }
        else
        {
                $this->dentists->update_dentist_detail();
                $this->session->set_flashdata('show_message', 'Dentist details has been updated successfully!');
                redirect('dentist/setting');
        }
    }}

/* End of file dentist.php */
/* Location: ./application/controllers/dentist.php */