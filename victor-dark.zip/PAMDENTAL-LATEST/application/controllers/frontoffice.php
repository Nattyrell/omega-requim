<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

/**
 * PAM DENTAL - Front Office Controller
 * @author Vaibhav Soni
 * @copyright 2012, Rohitashva Singh
 */
class Frontoffice extends CI_Controller {
    
    public function __construct() {
        parent::__construct();
        $this->load->model('frontoffice_model'); 
	    $this->load->model('admin/admin_model');
        $this->load->model('dentists');
        $this->load->model('patients');
        $this->load->model('emails');
    }
 
    public function index()
    {
        if($this->session->userdata('user_type')=='frontoffice')
        {
            $this->patient_list();
        }
        else
        {
            $this->load->view('frontoffice/frontoffice_login');
        }
    }
   
    public function login()
	{
            $this->_is_login();
            $data['title'] = 'PAM DENTAL - FRONTOFFICE ACCESS MANAGER';
            $data['page_title'] = 'FRONTOFFICE ACCESS MANAGER';

        if(isset($_POST['login']))
        {
            $this->form_validation->set_rules('username', 'User Name', 'trim|required');
            $this->form_validation->set_rules('password', 'Password', 'trim|required');
            
            if($this->form_validation->run() == FALSE)
                $this->load->view('frontoffice/frontoffice_login', $data);
            else
			{
                $frontoffice_login_data = $this->frontoffice_model->frontoffice_login();
                if($frontoffice_login_data)
                {
                    $frontoffice_data = array(
                            'user_type' => 'frontoffice',
                            'user_id' => $frontoffice_login_data->front_office_login_id ,
                            'email' => $frontoffice_login_data->email,
                             );
                    $this->session->set_userdata($frontoffice_data);
                    $this->frontoffice_model->update_last_login($frontoffice_login_data->front_office_login_id );
                    $this->frontoffice_model->front_office_log($frontoffice_login_data->front_office_login_id, 'Frontoffice logs into PAM.');
                    redirect('frontoffice/appointment');
                }
                else
                {
                    $this->session->set_flashdata('login_error', 'Username and Password do not match.');
                    redirect('frontoffice');
                }
            }
        }
        else
            $this->load->view('frontoffice/frontoffice_login', $data);
   }
	
	//Redirect to 'LOGIN PAGE' if user has not logged in already.
    private function _is_not_login()
    { 
        if(($this->session->userdata('user_type')!='frontoffice'))
        redirect('frontoffice');
    }
	
    //Redirect to 'HOME PAGE' if user has logged in already.
    private function _is_login()
    { 
        if(($this->session->userdata('user_type')=='frontoffice')){           
            redirect ('frontoffice/appointment');
        }
    }


   /** * Review An Appointment Page
            *
            * @access public 
            * @param none 
            * @shows calender view
            * Vaibhav Soni
            * 23 October 2012
    */
    public function appointment()
    {
        $this->_is_not_login();
        $data['title'] = 'PAM DENTAL - REVIEW APPOINTMENTS';
        $data['page_title'] = 'FRONTOFFICE ACCESS MANAGER';
        $data['css'] = '<link href="'.base_url().'calendar/libs/css/smoothness/jquery-ui-1.8.11.custom.css" media="screen" rel="stylesheet" type="text/css" />
                        <link href="'.base_url().'calendar/libs/jquery.weekcalendar.css" media="screen" rel="stylesheet" type="text/css" />
                        <link href="'.base_url().'calendar/skins/default.css" media="screen" rel="stylesheet" type="text/css" />
                        <link href="'.base_url().'calendar/skins/gcalendar.css" media="screen" rel="stylesheet" type="text/css" />';
        $data['js'] = '<script type="text/javascript" src="'.base_url().'js/patient/jquery-1.4.4.js"></script>
                   <script type="text/javascript" src="'.base_url().'calendar/libs/jquery-ui-1.8.11.custom.min.js"></script>
                   <script type="text/javascript" src="'.base_url().'calendar/libs/jquery-ui-i18n.js"></script>
                    <script type="text/javascript" src="'.base_url().'calendar/libs/date.js"></script>
                    <script type="text/javascript" src="'.base_url().'calendar/libs/jquery.weekcalendar.js"></script>';
        $this->load->view('frontoffice/frontoffice_appointment', $data);			   	
    }


    /** * Get All Appointments
            *
            * @access public 
            * @param none 
            * @return JSON array
            * Vaibhav Soni
            * 23 October 2012
    */		
    public function get_appointment()
    {
        $this->_is_not_login();
        $this->db->select('s.*, concat(p.first_name, " ", p.last_name) as patient_name, p.email',false);
        $this->db->from('schedule s');
        $this->db->join('patient_registration p', 'p.patient_id = s.patient_id', 'left'); // this joins the user table to topics
        $this->db->where('s.schedule_status !=','Canceled');
        $query = $this->db->get();
        if($query->num_rows())
        {
            foreach($query->result_array() as $row):
            $data[] = $row;
            endforeach;
            foreach($data as $key=>$app)
                {
                        $visit_date = strtotime($app['visit_date']);
                        $year = date('Y', $visit_date);
                        $month = date('n', $visit_date);
                        $day = date('j', $visit_date);
                        $data[$key]['year'] = (int)($year);
                        $data[$key]['month'] = (int)($month);
                        $data[$key]['day'] = (int)($day);
                }

                $dat['appointments'] = $data;	
                foreach($dat['appointments'] as $app):
                                $visit_date = strtotime($app['visit_date']);
                                $st = strtotime($app['start_time']);
                                $et = strtotime($app['end_time']);
                                $year = date('Y', $visit_date);
                                $month = date('n', $visit_date);
                                $day = date('j', $visit_date);
                                $sh = date('H', $st);
                                $eh = date('H', $et);
                                $sm = date('i', $st);
                                $em = date('i', $et);
                                $ss = date('s', $st);
                                $es = date('s', $et);

                                $arr[]=array( 
                                  'id'   => $app['schedule_id'], 
                                  'title'=> ($app['schedule_status'] == 'Pending')? $app['patient_name'].' '.'<a href="#" onclick="review('.$app['schedule_id'].');"><b>Review</b></a>' : $app['patient_name'], 
                                  'start'=> date('c',mktime($sh,$sm,$ss,$month,$day,$year)), 
                                  'end'  => date('c',mktime($eh,$em,$es,$month,$day,$year)),
                                  'patient_id' => $app['patient_id'],
                                  'visit_type' => $app['visit_type'],
                                  'visit_note' => $app['visit_note'],
                                  'patient_email' => $app['email'],
                                  'visit_date' => $app['visit_date'],
                                  'start_time' => $app['start_time'],
                                  'end_time' => $app['end_time'],
                                  'patient_name' => $app['patient_name'],
								  'status' => $app['schedule_status']
                                ); 
                        endforeach;
        }
                else
                {
                         $arr[]=array( 
                      'id'   => 0, 
                      'title'=> 0, 
                      'start'=> 0, 
                      'end'  => 0
                    ); 
                }	
         echo '{"events":'.json_encode($arr).'}'; 	
    }
	
    /** * Update Reviewed Appointments
            *
            * @access public 
            * @param none 
            * @return JSON array
            * Vaibhav Soni
            * 23 October 2012
    */		
    public function review_status()
    {
        $this->_is_not_login();
        /** Front Office Log for appointment review
         *  @author Rohitashva Singh
         *  5 November 2012
         */
        $this->frontoffice_model->front_office_log($this->session->userdata('user_id'), 'Frontoffice reviews an appointment.');
        /* * */
        $this->db->set('schedule_status',$_POST['status']);
        $this->db->where('schedule_id', $_POST['schedule_id']);
        $this->db->update('schedule');
        $this->_send_appointment_email($_POST);
        echo 'Appointment '.$_POST['status'].' successfully';
    }
	
    private function _send_appointment_email($post)
    {
        if($post['status']=='Canceled')
        {
                $subject = 'PAM DENTAL:: Appointment cancelled.';
                $content = '<html>
                                                <body style="font-family: Verdana,Arial,Helvetica,sans-serif; font-size: 13px;">
                                                        <p>Hello $user,</p>
                                                        <p>Unfortunately, the appointment you requested on $date, $start - $end, could not be approved.</p>
                                                        <p>below is the reason</p>
                                                        <p>$note</p>
                                                        <p>You are hereby requested to pick some other time slot for an appointment.</p> 
                                                        <p>Please do try and bear with us, for any inconvinence.</p>
                                                <p>In case you have any ideas or suggestions, please feel free to give us your feedback - <a href="mailto:admin@pamdental.com">admin@pamdental.com</a></p>
                                                <p>ADMIN<br/>PAM DENTAL</p>
                                                <b>THIS IS A SYSTEM GENERATED MAIL. REPLIES TO THIS MAIL ID WILL NOT BE RESPONDED.</b>        
                                                </body>
                                                </html>';
                $content = str_replace('$user', $post['patient_name'], $content);
                $content = str_replace('$date', date('F j, Y', strtotime($post['visit_date'])), $content);
                $content = str_replace('$start', date('h:i A', strtotime($post['start_time'])), $content); 	
                $content = str_replace('$end', date('h:i A', strtotime($post['end_time'])), $content); 	
                $content = str_replace('$note', $post['note'], $content); 			
        }
        else
        {
            $subject = 'Appointment approved';
            $content = '<html>
                                            <body style="font-family: Verdana,Arial,Helvetica,sans-serif; font-size: 13px;">
                                                    <p>Hello $user,</p>
                                                    <p>the appointment you requested on $date, $start - $end has been approved.</p>

                                                    <p>Please proceed with your visit.</p>
                                            <p>In case you have any ideas or suggestions, please feel free to give us your feedback - <a href="mailto:admin@pamdental.com">admin@pamdental.com</a></p>
                                            <p>ADMIN<br/>PAM DENTAL</p>
                                            <b>THIS IS A SYSTEM GENERATED MAIL. REPLIES TO THIS MAIL ID WILL NOT BE RESPONDED.</b>         
                                            </body>
                                            </html>';
            $content = str_replace('$user', $post['patient_name'], $content);
            $content = str_replace('$date', date('F j, Y', strtotime($post['visit_date'])), $content);
            $content = str_replace('$start', date('h:i A', strtotime($post['start_time'])), $content);     
            $content = str_replace('$end', date('h:i A', strtotime($post['end_time'])), $content); 	
        }

        $frontoffice_email_and_name = $this->emails->frontoffice_email_and_name();
        
        if($frontoffice_email_and_name){
        
            $this->email->from('noreply@pamdental.com', 'noreply');
            $this->email->to($post['patient_email']);//change to patient email:- $post['patient_email']
            $this->email->cc($frontoffice_email_and_name['email']);
            $this->email->bcc($this->emails->bcc_emails(2));
            $this->email->subject($subject);
            $this->email->message($content);
            $this->email->send();
        }

    }
	
    public function logout()
    {
        $this->session->userdata('user_id') ? $this->frontoffice_model->front_office_log($this->session->userdata('user_id'), 'Frontoffice logs out of PAM.') : '';
        $this->session->sess_destroy();
        redirect('frontoffice');
    }

    /** * List Of Patient
            *
            * @access public 
            * @param none 
            * @return array 
            * Vaibhav Soni
            * 16 October 2012
    */
    public function patient_list()
    {
        $this->_is_not_login();
        $data['title'] = 'PAM DENTAL - Patient List';
        $data['page_title'] = 'FRONTOFFICE ACCESS MANAGER';

        $data['js']='<script type="text/javascript" language="javascript" src="'.base_url().'js/jquery_1.7.1.js"></script>
                     <script type="text/javascript" language="javascript" src="'.base_url().'js/jquery.dataTables.js"></script>';
        $data['css']='<style type="text/css" title="currentStyle">
                        @import "'.base_url().'css/demo_table_jui.css";
                        @import "'.base_url().'css/redmond/jquery-ui-1.9.1.custom.css";
                      </style>';
        $data['result']=$this->admin_model->patient_list();
        //die('hello');
        $this->load->view('frontoffice/frontoffice_patient_list',$data);
    }

    /** * Details Of Patient
            *
            * @access public 
            * @param none 
            * @return array 
            * Vaibhav Soni
            * 16 October 2012
    */
    public function patient_details()
    {
        $this->_is_not_login();
        $data['title'] = 'PAM DENTAL - Patient Details';
        $data['page_title'] = 'FRONTOFFICE ACCESS MANAGER';
        $data['js']='<script type="text/javascript" language="javascript" src="'.base_url().'js/jquery_1.7.1.js"></script>
                                 <script type="text/javascript" language="javascript" src="'.base_url().'js/jquery.dataTables.js"></script>';
        $data['css']='<link type="text/css" rel="stylesheet" href="'.base_url().'css/demo_table.css" />';
        $data['result']=$this->admin_model->patient_details();
        $this->load->view('frontoffice/frontoffice_patient_details',$data);
    }
	
    public function setting()
    {
        $this->_is_not_login();
        $data['title'] = 'PAM DENTAL - Setting';
        $data['page_title'] = 'FRONTOFFICE ACCESS MANAGER';
        $data['result']=$this->frontoffice_model->frontoffice_detail();

        $this->form_validation->set_rules('first_name','First Name','required');
        $this->form_validation->set_rules('last_name','Last Name','required');
        $this->form_validation->set_rules('email','E-mail','required|email');
        $this->form_validation->set_rules('username','Username','required');
        
        if(isset($_POST['password']) && $_POST['password']!='')
        $this->form_validation->set_rules('conf_password','Confirm Password','required|matches[password]');

        if($this->form_validation->run()==FALSE)
        {
                $this->load->view('frontoffice/frontoffice_setting',$data);
        }
        else
        {
                $this->frontoffice_model->update_frontoffice_detail();
                $this->session->set_flashdata('show_message', 'Frontoffice details has been updated successfully!');
                redirect('frontoffice/setting');
        }
    }

    public function forgot_password()
    {
        $this->_is_login();
        $data['title'] = 'PAM DENTAL - FORGOT PASSWORD';
        $data['page_title'] = 'FORGOT PASSWORD';
        if(isset($_POST['submit']))
        {
            $this->form_validation->set_rules('username', 'USERNAME', 'trim|required');

            if($this->form_validation->run() == FALSE)
                $this->load->view('frontoffice/frontoffice_forgot_password', $data);
            else{
                //echo $this->_generateRandomString();
                $user_data = $this->frontoffice_model->forgot_password();
                if($user_data){
                    //echo $user_data;
                    $email_content = '<html>
                                        <body>
                                        <p>Hello <font size=2><code>$first_name</code></font>,</p>
                                        <p>Your PAM login password has been reset successfully!</p>
                                        <p>Access PAM - PATIENT\'s PORTAL, using below details - </p>
                                        <p>USERNAME - <font color="#FF0000" size=2><code>$username</code></font></p>
                                        <p>PASSWORD - <font color="#FF0000" size=2><code>$password</code></font></p>
                                        <p>&nbsp;</p>
                                        <p>\'<strong>CHANGE PASSWORD</strong>\' feature coming up soon...</p>
                                        <p>&nbsp;</p>
                                        <p>ADMIN!</p>
                                      </body>
                                      </html>';
                   $email_content = str_replace('$first_name', $user_data['first_name'], $email_content);
                   $email_content = str_replace('$username', $user_data['username'], $email_content);
                   $email_content = str_replace('$password', $user_data['password'], $email_content); 

                   //SEND EMAIL
                   $this->email->from('noreply@pamdental.com', 'noreply');
                   $this->email->to('rohitashvarathore@gmail.com'); /*CHANGE THIS LATER*/
                   // $this->email->bcc('rohitashvarathore@gmail.com');
                   $this->email->subject('PAM DENTAL:: FORGOT PASSWORD');
                   $this->email->message($email_content);
                   $this->email->send();

                   $this->session->set_flashdata('login_error', 'Your new login details have been mailed to you, please check if mail has not been marked as a spam.');
                   redirect('frontoffice');
                   }
                else{
                   $this->session->set_flashdata('login_error', 'No such user exists in our database.');
                   redirect('frontoffice');
                }
            }
        }
        else
            $this->load->view('frontoffice/frontoffice_forgot_password', $data);
    }
    
    /** * Review Checkups Page
        *
        * @access public 
        * @param none 
        * @shows list of pending checkups
        * @author Rohitashva Singh <rohitashvarathore@gmail.com>
        * 3 Novembeb 2012
    */
    public function review_checkups(){
        $this->_is_not_login();
        $data['title'] = 'PAM DENTAL - REVIEW CHECKUPS';
        $data['page_title'] = 'FRONTOFFICE ACCESS MANAGER';

        $data['js']='<script type="text/javascript" language="javascript" src="'.base_url().'js/jquery_1.7.1.js"></script>
                     <script type="text/javascript" language="javascript" src="'.base_url().'js/jquery.dataTables.js"></script>';
        $data['css']='<style type="text/css" title="currentStyle">
                        @import "'.base_url().'css/demo_table_jui.css";
                        @import "'.base_url().'css/redmond/jquery-ui-1.9.1.custom.css";
                      </style>';
        $data['result'] = $this->frontoffice_model->review_checkups();
        $this->load->view('frontoffice/frontoffice_review_checkups',$data);
    }
    
    /** * View Checkup Detail Page
    * @access public
    * @param none
    * @shows patient checkup details
    * @author Rohitashva Singh <rohitashvarathore@gmail.com>
    * 4 Novembeb 2012
    */
    public function view_checkup_detail(){
        $this->_is_not_login();
        $patient_checkup_id = base64_decode($this->uri->segment(3));
        $patient_id = base64_decode($this->uri->segment(4));
        if($patient_checkup_id && $patient_id){
            $this->frontoffice_model->front_office_log($this->session->userdata('user_id'), 'Frontoffice views checkup detail of patient[#'.$patient_id.'].');
            $data['title'] = 'PAM DENTAL - VIEW CHECKUP DETAIL';
            $data['page_title'] = 'FRONTOFFICE ACCESS MANAGER';
            $data['css'] = '<link href="'.base_url().'css/patient/reveal.css" media="screen" rel="stylesheet" type="text/css" />';
            $data['js'] = '<script type="text/javascript" src="'.base_url().'js/patient/jquery-1.4.4.min.js"></script>
                           <script type="text/javascript" src="'.base_url().'js/patient/jquery.reveal.js"></script>';
			   
	    /** ---------------------DATA--------------------- */	   
            $data['get_checkup'] = $this->patients->get_checkup(@$patient_id, @$patient_checkup_id);
            $data['get_checkup_detail'] = $this->patients->get_checkup_detail(@$patient_id, @$patient_checkup_id);
            $data['patient_data'] = $this->patients->patient_info(@$patient_id)->row_array();
	    // ADDED 30-111-2012 6:45 PM
	    $data['guarantor_data'] = $this->patients->guarantor_info(@$patient_id)->row_array();
	    // -------------------------
            $data['us_states'] = $this->patients->us_states();
            $data['get_checkup_price'] = $this->patients->get_checkup_price(@$patient_id, $patient_checkup_id);
	    /** ---------------------------------------------- */
        if($data['get_checkup'] && $data['patient_data'] && $data['get_checkup_detail'] && $data['get_checkup_price']){
            $this->load->view('frontoffice/frontoffice_view_checkup_detail', $data);
        }
        else
            redirect ('frontoffice/review-checkups');
        }
        else
            redirect ('frontoffice/review-checkups');
    }
    
    /** * Refresh Checkups Table
            *
            * @access public 
            * @param none 
            * @shows list of pending checkups on ajax call
            * @author Rohitashva Singh <rohitashvarathore@gmail.com>
            * 4 November 2012
    */
    public function refresh_checkups(){
        $this->_is_not_login();
        /** Front Office Log for checkup review
         *  @author Rohitashva Singh
         */
        $this->frontoffice_model->front_office_log($this->session->userdata('user_id'), 'Frontoffice reviews a checkup.');
        /* * */
        $this->db->set('frontoffice_notes', $_POST['note']);
        $this->db->set('status', $_POST['status']);
		$this->db->where('patient_checkup_id', $_POST['patient_checkup_id']);
		$this->db->update('patient_checkup');
        $data['result'] = $this->frontoffice_model->review_checkups();
        $this->load->view('frontoffice/frontoffice_refresh_checkups',$data);
    }
    
    /** Patient Checkup Archive
    * @access public 
    * @param none 
    * @shows list of checkups
    * @author Rohitashva Singh <rohitashvarathore@gmail.com>
    * 5 November 2012
    */
    public function patient_checkup_archive(){
        $this->_is_not_login();
        $patient_id = base64_decode($this->uri->segment(3));
        if($patient_id){
            $data['title'] = 'PAM DENTAL - CHECKUP ARCHIVE';
            $data['page_title'] = 'FRONTOFFICE ACCESS MANAGER';

            $data['js']='<script type="text/javascript" language="javascript" src="'.base_url().'js/jquery_1.7.1.js"></script>
                         <script type="text/javascript" language="javascript" src="'.base_url().'js/jquery.dataTables.js"></script>';
            $data['css']='<style type="text/css" title="currentStyle">
                          @import "'.base_url().'css/demo_table_jui.css";
                          @import "'.base_url().'css/redmond/jquery-ui-1.9.1.custom.css";
                          </style>';
            $data['result'] = $this->frontoffice_model->patient_checkup_archive($patient_id);
            //if($data['result'])
                $this->load->view('frontoffice/frontoffice_patient_checkup_archive',$data);
            //else redirect('frontoffice/patient-list');
        }
        else redirect('frontoffice/patient-list');
    }
    
    /** PATIENT BILLING HISTORY
     * @param none
     * @access public
     * @author Rohitashva Singh <rohitashvarathore@gmail.com>
     * 13-11-2012 12:59 AM (DIWALI)........WISH A HAPPY DIWALI.........
     */
    public function patient_billing_history(){
        $this->_is_not_login();
        $data['title'] = 'PAM DENTAL - PATIENT BILLING HISTORY';
        $data['page_title'] = 'FRONTOFFICE ACCESS MANAGER';
        $data['js']='<script type="text/javascript" language="javascript" src="'.base_url().'js/jquery_1.7.1.js"></script>
                     <script type="text/javascript" language="javascript" src="'.base_url().'js/jquery.dataTables.js"></script>';
        $data['css']='<style type="text/css" title="currentStyle">
                        @import "'.base_url().'css/demo_table_jui.css";
                        @import "'.base_url().'css/redmond/jquery-ui-1.9.1.custom.css";
                      </style>';
        $patient_id = base64_decode($this->uri->segment(3));
        if($patient_id){
            $data['result'] = $this->admin_model->patient_billing_history($patient_id, 1);
            //echo '<pre>';
            //print_r($data['result']);
            //echo '</pre>';
            $this->load->view('frontoffice/patient_billing_history', $data);
        }
        else redirect('frontoffice/patient-list');
    }
    
    /** BILLING DETAIL
     * @param none
     * @access public
     * @author Rohitashva Singh <rohitashvarathore@gmail.com>
     * 13-11-2012 12:59 AM (DIWALI)........WISH A HAPPY DIWALI.........
     */
    public function patient_billing_detail(){
        $this->_is_not_login();
        $data['title'] = 'PAM DENTAL - BILLING DETAIL';
        $data['page_title'] = 'FRONTOFFICE ACCESS MANAGER';
        $data['js']='<script type="text/javascript" language="javascript" src="'.base_url().'js/jquery_1.7.1.js"></script>
                     <script type="text/javascript" language="javascript" src="'.base_url().'js/jquery.dataTables.js"></script>';
        $data['css']='<style type="text/css" title="currentStyle">
                        @import "'.base_url().'css/demo_table_jui.css";
                        @import "'.base_url().'css/redmond/jquery-ui-1.9.1.custom.css";
                      </style>';
        $patient_checkup_id = base64_decode($this->uri->segment(3));
        $patient_id = base64_decode($this->uri->segment(4));
        if($patient_id && $patient_checkup_id){
            $data['billing_detail'] = $this->admin_model->billing_detail($patient_id, $patient_checkup_id);
            $data['treatment_detail'] = $this->patients->get_checkup_for_pay($patient_id, $patient_checkup_id);
            $data['patient_address'] = $this->admin_model->patient_address($patient_id);
            $data['us_states'] = $this->patients->us_states();
            if($data['billing_detail'] && $data['patient_address'])
                $this->load->view('frontoffice/patient_billing_detail', $data);
            else redirect('frontoffice/patient-billing-history/'.$patient_id);
        }
        else redirect('frontoffice/patient-list');
    }
	
	//vaibhav soni
	//18-11-2012
	public function update_appointment()
	{
            $sql = 'SELECT `schedule_id` FROM schedule WHERE `visit_date` = "'.$_POST['visit_date'].'" AND schedule_status != "Canceled" AND
                                    ("'.date('H:i:s',strtotime($_POST['start_time'])).'" BETWEEN `start_time` AND SUBTIME(`end_time`,"00:00:01")
                                    OR "'.date('H:i:s',strtotime($_POST['end_time'])).'" BETWEEN AddTime(`start_time`,"00:00:01") AND `end_time`);';
            $query = $this->db->query($sql);

            if($query->num_rows())
                    echo 0;
            else
            {
                    $this->db->set('visit_date',$_POST['visit_date']);
                    $this->db->set('start_time',$_POST['start_time']);
                    $this->db->set('end_time',$_POST['end_time']);
                    $this->db->where('schedule_id',$_POST['schedule_id']);
                    $this->db->update('schedule');
                    $this->_send_update_appointment_email($_POST);
                    echo 1;
            }
	}
	
	
	private function _send_update_appointment_email($post)
	{
            $subject = 'PAM DENTAL:: Appointment Rescheduled';
            $content = '<html>
                        	<body style="font-family: Verdana,Arial,Helvetica,sans-serif; font-size: 13px;">
                           	    <p>Hello '.$post['patient_name'].',</p>
                            	<p>Your appointment for '.$post['visit_type'].', has been rescheduled. Details are as under -</p> 
								<table border="0" cellpadding="5" width="500">
									  <tbody>
											<tr>
											  <td nowrap="nowrap" valign="top"><strong>Visit Date:</strong></td>
											  <td nowrap="nowrap" valign="top">'.date('F j, Y', strtotime($post['visit_date'])).'</td>
											</tr>
											<tr>
											  <td nowrap="nowrap" valign="top"><strong>Visit Time:</strong></td>
											  <td nowrap="nowrap" valign="top">'.date('h:i A', strtotime($post['start_time'])).' - '.date('h:i A', strtotime($post['end_time'])).'</td>
											</tr>
											<tr>
											  <td nowrap="nowrap" valign="top"><strong>Visit Note:</strong></td>
											  <td nowrap="nowrap" valign="top">'.$post['visit_note'].'</td>
											</tr>
									  </tbody>
									</table>
								<p>In case you have any ideas or suggestions, please feel free to give us your feedback - <a href="mailto:admin@pamdental.com">admin@pamdental.com</a></p>
								<p>&nbsp;</p>
								<p>ADMIN</p>
								<p>PAM DENTAL</p>
								<p><b>THIS IS A SYSTEM GENERATED MAIL. REPLIES TO THIS MAIL ID WILL NOT BE RESPONDED.</b></p>
                       		</body>
                         </html>';

                         
        //$frontoffice_email_and_name = $this->emails->frontoffice_email_and_name();
        //if(frontoffice_email_and_name){
           $this->email->from('noreply@pamdental.com', 'noreply');
           $this->email->to($post['patient_email']);//change to patient email:- $post['patient_email']
           //$this->email->cc($frontoffice_email_and_name['email']);
           $this->email->bcc($this->emails->bcc_emails(2));
           $this->email->subject($subject);
           $this->email->message($content);
           $this->email->send(); 
        //}                 
    }
     /** Scheduled Appointment
     * @param none
     * @access public
     * @author vaibhav soni
     * 18-11-2012
     */
    public function scheduled_appointments()
    {
        $this->_is_not_login();
        $data['title'] = 'PAM DENTAL - FRONTOFFICE Scheduled Appointments';
        $data['page_title'] = 'PATIENT Scheduled Appointments';
        $data['js']='<script type="text/javascript" language="javascript" src="'.base_url().'js/jquery_1.7.1.js"></script>
                     <script type="text/javascript" language="javascript" src="'.base_url().'js/jquery.dataTables.js"></script>';
        $data['css']='<style type="text/css" title="currentStyle">
                        @import "'.base_url().'css/demo_table_jui.css";
                        @import "'.base_url().'css/redmond/jquery-ui-1.9.1.custom.css";
                      </style>';
        $data['result'] = $this->frontoffice_model->scheduled_appointment();
        $this->load->view('frontoffice/frontoffice_scheduled_appointment', $data);
    }
    
    /** REVIEW PATIENT TREATMENT PLAN
     * @param none
     * @access public
     * @author Rohitashva Singh <rohitashvarathore@gmail.com>
     * 29-11-2012 2:14 AM
     */
    public function review_treatment_plan(){
        $this->_is_not_login();
        $data['title'] = 'PAM DENTAL - REVIEW PATIENT TREATMENT PLAN';
        $data['page_title'] = 'PAM DENTAL - REVIEW PATIENT TREATMENT PLAN';
        $data['js']='<script type="text/javascript" language="javascript" src="'.base_url().'js/jquery_1.7.1.js"></script>
                     <script type="text/javascript" src="'.base_url().'js/timepicker/jquery-1.3.2.min.js"></script>
                     <script type="text/javascript" language="javascript" src="'.base_url().'js/jquery.dataTables.js"></script>
                     <script type="text/javascript" src="'.base_url().'js/timepicker/ui.core.js"></script>
                     <script type="text/javascript" src="'.base_url().'js/timepicker/ui.slider.js"></script>
                     <script type="text/javascript" src="'.base_url().'js/timepicker/jquery.jtimepicker.js"></script>';
        $data['css']='<style type="text/css" title="currentStyle">
                        @import "'.base_url().'css/demo_table_jui.css";
                        @import "'.base_url().'css/redmond/jquery-ui-1.9.1.custom.css";
                        @import "'.base_url().'css/timepicker/style.css";
                        @import "'.base_url().'css/timepicker/ui/base/ui.core.css";
                        @import "'.base_url().'css/timepicker/ui/base/ui.theme.css";
                        @import "'.base_url().'css/timepicker/ui/base/ui.slider.css";
                        @import "'.base_url().'css/timepicker/jquery.timepicker.css";
                      </style>';
        $patient_checkup_id = base64_decode($this->uri->segment(3));
        $patient_id = base64_decode($this->uri->segment(4));
        if($patient_id && $patient_checkup_id){
            $data['get_checkup'] = $this->patients->get_checkup(@$patient_id, @$patient_checkup_id);
            $data['get_checkup_detail'] = $this->patients->get_checkup_detail(@$patient_id, @$patient_checkup_id);
            $data['patient_data'] = $this->patients->patient_info(@$patient_id)->row_array();
            $data['us_states'] = $this->patients->us_states();
            if($data['get_checkup'] && $data['patient_data'] && $data['get_checkup_detail']){
                if(isset($_POST['submit'])){
                    //echo '<pre>';
                    //print_r(@$_POST);
                    //echo '</pre>';
                    $this->form_validation->set_rules('patint_ins_deduct', 'Patient Insurance Deduction', 'required|numeric|callback_check_patint_ins_deduct['.$this->uri->segment(4).']');
                    if($this->form_validation->run() == FALSE)
                        $this->load->view('frontoffice/review_treatment_plan', $data);
                    else{
                            $this->frontoffice_model->front_office_log($this->session->userdata('user_id'), 'Frontoffice reviews a treatment plan for a Patient[PATIENT UIN: '.$data['patient_data']['patient_uin'].'].');
                            $this->frontoffice_model->review_treatment_plan($patient_id);
                            $this->_send_reviewed_treatment_email($patient_checkup_id, $patient_id);    /*SEND EMAIL*/
                            redirect('frontoffice/review-checkups');
                    }
                }
                else $this->load->view('frontoffice/review_treatment_plan', $data);
            }
            else
                redirect ('frontoffice/review-checkups');
        }
        else redirect ('frontoffice/review-checkups');
    }
    
     /**
     * @param int $field DATA FIELD
     * @param int $id PATIENT ID ENCRYPTED
     * @access public
     * @author Rohitashva Singh <rohitashvarathore@gmail.com>
     * 29-11-2012 2:14 AM
     */

   public function check_patint_ins_deduct($field, $id){
       $this->_is_not_login();
       $patient_id = base64_decode($id);
       $this->db->select('p_total_insurance');
       $this->db->where('patient_id', $patient_id);
       $query = $this->db->get('patient_registration')->row_array();
       if($query){
            if($query['p_total_insurance']-$field<0.00){
                $this->form_validation->set_message('check_patint_ins_deduct', 'The %s value can not be greater than Remaining Patient Insurance.');
                return FALSE;
            }
            else return TRUE;
       }
       $this->form_validation->set_message('check_patint_ins_deduct', 'Error.');
       return FALSE;
   }

    /** CONFIRMATION EMAIL TO PATIENT, ONCE A TREATMENT PLAN IS REVIEWED BY FRONT OFFICE
     * @param int $patient_checkup_id
     * @param int $patient_id
     * @return none
     * @author Rohitashva Singh <rohitashvarathore@gmail.com>
     * 14-12-2012 9:18 PM
     */
    private function _send_reviewed_treatment_email($patient_checkup_id, $patient_id){
        if($patient_checkup_id && $patient_id){
            /** ---------------------DATA--------------------- */
                $data['get_checkup'] = $this->patients->get_checkup(@$patient_id, @$patient_checkup_id);
                $data['get_checkup_detail'] = $this->patients->get_checkup_detail(@$patient_id, @$patient_checkup_id);
                $data['patient_data'] = $this->patients->patient_info(@$patient_id)->row_array();
            // ADDED 30-111-2012 6:45 PM
            $data['guarantor_data'] = $this->patients->guarantor_info(@$patient_id)->row_array();
            // -------------------------
                $data['us_states'] = $this->patients->us_states();
                $data['get_checkup_price'] = $this->patients->get_checkup_price(@$patient_id, $patient_checkup_id);
            /** ---------------------------------------------- */
            if($data['get_checkup'] && $data['patient_data'] && $data['get_checkup_detail'] && $data['get_checkup_price']){
                $patient_query = $this->emails->patient_email_and_name($patient_id);
                $bcc_emails = $this->emails->bcc_emails(1);

                if($patient_query){
                    /*SEND EMAIL*/
                    $email_content = '<html>
                                      <body style="font-family: Verdana,Arial,Helvetica,sans-serif; font-size: 13px;">
                                      Hi '.$patient_query['first_name'].','.br(2).'
                                      A new Treatment Plan has been okayed for you by our Front Office manager, recommended by Dentist. Below are the details - '.br(1).'';
                    $email_content.= $this->load->view('frontoffice/frontoffice_reviewed_treatment_email', $data, True);
                    $email_content.= br(2).'<p>You are hereby requested to log into PAM DENTAL Patient portal here - '.base_url().', pay for the said treatment plan and subsequently get an appointment for the same. </p>';
                    $email_content.= br(5).'<p>In case you have any ideas or suggestions, please feel free to give us your feedback - <a href="mailto:admin@pamdental.com">admin@pamdental.com</a></p>';
                    $email_content.= br(2).'<p>ADMIN<br/>PAM DENTAL</p>';
                    $email_content.= br(2).'<b>'.'THIS IS A SYSTEM GENERATED MAIL. REPLIES TO THIS MAIL ID WILL NOT BE RESPONDED.'.'</b>';
                    $email_content.= br(2).'</body></html>';
                    $this->email->from('noreply@pamdental.com', 'noreply');
                    $this->email->to($patient_query['email']);
                    $this->email->bcc($bcc_emails);
                    $this->email->subject('PAM DENTAL:: A new Treatment Plan okayed for you');
                    $this->email->message($email_content);
                    $this->email->send();
                }
            }
        }
    }
	
}
/* End of file frontoffice.php */
/* Location: ./application/controllers/frontoffice.php */