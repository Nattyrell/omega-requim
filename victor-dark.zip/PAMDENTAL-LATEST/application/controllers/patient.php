<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

/**
 * PAM DENTAL - Patient Controller
 * @author Rohitashva Singh
 * @copyright 2012, Rohitashva Singh
 */
class Patient extends CI_Controller {
    
    public function __construct() {
        parent::__construct();
        $this->load->model('patients'); 
        $this->load->model('frontoffice_model');
        $this->load->model('admin/admin_model');
        $this->load->model('emails');
        $this->output->enable_profiler(FALSE);
    }
    
    public function index()
    {
        $this->_is_login();
        $data['title'] = 'PAM DENTAL - PATIENT ACCESS MANAGER';
        $data['page_title'] = 'PATIENT ACCESS MANAGER';
        $data['js']='<script type="text/javascript" language="javascript" src="'.base_url().'js/jquery_1.7.1.js"></script>
                     <script type="text/javascript" language="javascript" src="'.base_url().'js/jquery.min.js"></script>
                     <script type="text/javascript" language="javascript" src="'.base_url().'js/jquery.colorbox.js"></script>';
        $data['css']='<style type="text/css" title="currentStyle">
                        @import "'.base_url().'css/demo_table_jui.css";
                        @import "'.base_url().'css/redmond/jquery-ui-1.9.1.custom.css";
                        @import "'.base_url().'css/colorbox.css";
                      </style>';
        if(isset($_POST['login']))
        {
            $this->form_validation->set_rules('username', 'User Name', 'trim|required');
            $this->form_validation->set_rules('password', 'Password', 'trim|required');
            
            if($this->form_validation->run() == FALSE)
                $this->load->view('patient/patient_login', $data);
            else
            {
                $patient_login_data = $this->patients->patient_login();
                if($patient_login_data){
                    $patient_data = array(
                            'user_type' => 'patient',
                            'login_id' => $patient_login_data->patient_login_id,
                            'username' => $patient_login_data->username,
                            'password' => @$_POST['password']
                             );
                    $this->session->set_userdata($patient_data);

                    if($patient_login_data->is_registered == 'N')
                        redirect('patient/patient-registration-form');
                    else if($patient_login_data->is_registered == 'Y')
                        redirect('patient/login');
                }
                else{
                    $this->session->set_flashdata('login_error', 'Username and Password do not match.');
                    redirect('patient');
		        }
            }
        }
        else
            $this->load->view('patient/patient_login', $data);
   }
    
   public function login()
   {
        //$this->_is_login();
        $data['title'] = 'PAM DENTAL - PATIENT ACCESS MANAGER';
        $data['page_title'] = 'PATIENT ACCESS MANAGER';
        $data['css'] = '<link href="'.base_url().'css/patient/tipTip.css" media="screen" rel="stylesheet" type="text/css" />';
        $data['js'] = '<script type="text/javascript" src="'.base_url().'js/patient/jquery-1.4.4.js"></script>
                       <script type="text/javascript" src="'.base_url().'js/patient/jquery.tipTip.js"></script>
                       <script type="text/javascript" src="'.base_url().'js/patient/jquery.tipTip.minified.js"></script>';
        if(isset($_POST['login']))
        {
            $this->form_validation->set_rules('p_uin', 'PATIENT UIN', 'trim|required');
            
            if($this->form_validation->run() == FALSE)
                $this->load->view('patient/patient_login_part_2', $data);
            else
            {
                $patient_login_data = $this->patients->patient_login_part_2();
				
                if($patient_login_data)
                {
                    $patient_data = array(
                            'user_type' => 'patient',
                            'patient_id' => $patient_login_data->patient_id,
                            'name' => $patient_login_data->first_name.' '.$patient_login_data->last_name,
                             );
                    $this->session->set_userdata($patient_data);
					
                    $this->patients->update_last_login($patient_login_data->patient_login_id);
                    $this->patients->patient_log($patient_login_data->patient_id, 'Patient logs into PAM.');

                        redirect('patient/home');
                }
                else{
                    $this->session->set_flashdata('login_error', 'Username, Password and Patient UIN do not match.');
                    redirect('patient/login');
		}
            }
        }
        else
            $this->load->view('patient/patient_login_part_2', $data);
   
   }
   public function patient_sign_up()
   {
        $this->_is_login();
        $data['title'] = 'PAM DENTAL - PATIENT SIGN UP';
        $data['page_title'] = 'PATIENT SIGN UP';
        $data['css'] = '<link href="'.base_url().'css/patient/tipTip.css" media="screen" rel="stylesheet" type="text/css" />';
        $data['js'] = '<script type="text/javascript" src="'.base_url().'js/patient/jquery-1.4.4.js"></script>
                       <script type="text/javascript" src="'.base_url().'js/patient/jquery.tipTip.js"></script>
                       <script type="text/javascript" src="'.base_url().'js/patient/jquery.tipTip.minified.js"></script>';
        if(isset($_POST['submit'])){
            $this->form_validation->set_rules('first-name', 'First Name', 'trim|required|alpha');
            $this->form_validation->set_rules('last-name', 'Last Name', 'trim|required|alpha');
            $this->form_validation->set_rules('middle-initial', 'Middle Initial', 'trim|alpha|max_length[1]');
            $this->form_validation->set_rules('email', 'Email', 'trim|required|valid_email');
            $this->form_validation->set_rules('username', 'User ID', 'trim|required|min_length[6]|is_unique[patient_login.username]');
            $this->form_validation->set_rules('password', 'Password', 'trim|required|min_length[6]');
            $this->form_validation->set_rules('confirm-password', 'Confirm Password', 'trim|required|min_length[6]|matches[password]');
            
            if($this->form_validation->run() == FALSE){
                $this->load->view('patient/patient_sign_up', $data);
            }
            else
            {
                /**
                 * MODIFIED 21-11-2012 4:42PM
                 */
                //$this->session->set_userdata('name', $_POST['first-name'].nbs(1).$_POST['last-name']); //Rohitashva Singh 14-11-2012 2:56PM
                $new_patient_data = $this->patients->new_patient_signup();
                if($new_patient_data):
                    $patient_data = array(
                                'user_type' => 'patient',
                                'login_id' => $new_patient_data['patient_login_id'],
                                'name' => $new_patient_data['name'],
								'username' => @$_POST['username'],
                            	'password' => @$_POST['password']
                                 );
                    $this->session->set_userdata($patient_data);
                    $this->patients->patient_log($new_patient_data['patient_login_id'], 'A new patient signs up with PAM DENTAL.');
                    $this->patients->patient_log($new_patient_data['patient_login_id'], 'Patient logs into PAM.');
                    redirect('patient/patient-registration-form');
                endif;
                /** --------------------------------------------------------------- */
            }
        }
        else
            $this->load->view('patient/patient_sign_up', $data);
    }
    
    public function logout(){
        $this->session->userdata('patient_id') ? $this->patients->patient_log($this->session->userdata('patient_id'), 'Patient logs out of PAM.') : '';
        $this->session->sess_destroy();
        redirect('patient');
    }
    
    public function patient_registration_form(){
        $this->_is_not_login_redirect_home();
        $data['title'] = 'PAM DENTAL - PATIENT REGISTRATION FORM';
        $data['page_title'] = 'PATIENT REGISTRATION FORM';
        $data['css'] = '<link href="'.base_url().'css/patient/tipTip.css" media="screen" rel="stylesheet" type="text/css" />
                        <link rel="stylesheet" href="'.base_url().'css/patient/jquery.ui.all.css">';
        $data['js'] = '<script src="'.base_url().'js/patient/jquery-1.8.2.js"></script>
                       <script type="text/javascript" src="'.base_url().'js/patient/jquery.tipTip.js"></script>
                       <script type="text/javascript" src="'.base_url().'js/patient/jquery.tipTip.minified.js"></script>
                       <script src="'.base_url().'js/patient/jquery.ui.core.js"></script>
                       <script src="'.base_url().'js/patient/jquery.ui.widget.js"></script>
                       <script src="'.base_url().'js/patient/jquery.ui.datepicker.js"></script>';
        $data['patient_status'] = $this->patients->patient_status();
        $data['patient_relationship_insured'] = $this->patients->patient_relationship_insured();
        $data['patient_health_conditions'] = $this->patients->patient_health_conditions();
        $data['patient_other_medicines_or_neutricuticals'] = $this->patients->patient_other_medicines_or_neutricuticals();
        $data['us_states'] = $this->patients->us_states();
        if(isset($_POST['submit'])){
            //echo '<pre>';
            //print_r($_POST);
            //echo '</pre>';
            //exit;
                    //@Patient Information
            $this->form_validation->set_rules('sex', 'Sex', '');
            $this->form_validation->set_rules('status', 'Status', 'callback_status_check');
            $this->form_validation->set_rules('ssn', 'Social Security #', 'trim');
            $this->form_validation->set_rules('dln', 'Drivers Lic.#', 'trim');
            $this->form_validation->set_rules('dob', 'Birth Date', 'trim');
            $this->form_validation->set_rules('phone-home', 'Phone (Home)', 'trim|validate_phone_number[phone-home]');
            $this->form_validation->set_rules('phone-work', 'Phone (Work)', 'trim|validate_phone_number[phone-work]');
            $this->form_validation->set_rules('phone-cell', 'Phone (Cell)', 'trim|validate_phone_number[phone-cell]');
            $this->form_validation->set_rules('email', 'Email ', 'trim|required|valid_email');
            $this->form_validation->set_rules('street', 'Street Address ', 'trim');
            $this->form_validation->set_rules('apartment-number', 'Apartment #', 'trim');
            $this->form_validation->set_rules('city', 'City', 'trim');
            $this->form_validation->set_rules('state', 'State', '');
            
                    //@HEALTH CONDITIONS
            $this->form_validation->set_rules('patient-health-condition[]', 'Health condition', '');
            
                    //@OTHER MEDICINES OR NEUTIRCUTICALS
            $this->form_validation->set_rules('patient_other_medicines_or_neutricuticals[]', 'Other Medicines OR Neutricuticals', '');
                        
            if($this->form_validation->run() == FALSE)
                $this->load->view('patient/patient_registration_form', $data);
            else{
                //$this->patients->insert_patient_registration_data();
                
                /**
                 * MODIFIED 29-11-2012 12:47 PM
                 * @author Rohitashva Singh <rohitashvarathore@gmail.com>
                 */
                    $patient_id = $this->patients->insert_patient_registration_data();
                    $this->session->set_userdata('patient_id', $patient_id);
                /* -------------------------------------------------------------- */
                redirect ('patient/home');
            }
        }
        else
            $this->load->view('patient/patient_registration_form', $data);
    }
    
    public function status_check(){
        if(@$_POST['martial-status-other']!='' && !(@$_POST['status'] ==4)){
            $this->form_validation->set_message('status_check', 'Please select checkbox for Other above');
            return FALSE;
        }
        else
            return TRUE;
    }
    
    public function phone_check($field){
        if(!preg_match('/[a-zA-Z]/', $field)){
            return TRUE;
        }
        else{
            $this->form_validation->set_message('phone_check', 'Please enter valid phone number.');
            return FALSE;
        }
    }
    
     /* MODIFIED 1-12-2012 4:22 PM
     * @author Rohitashva Singh <rohitashvarathore@gmail.com>
     * @access public
     * @param none
     */
    public function home(){
        $this->_is_not_login_redirect_registration_form();
        $data['title'] = 'PAM DENTAL - PATIENT HOME PAGE';
        $data['page_title'] = 'PATIENT HOME PAGE';
        $data['js']='<script type="text/javascript" language="javascript" src="'.base_url().'js/jquery_1.7.1.js"></script>
		     <script type="text/javascript" language="javascript" src="'.base_url().'js/jquery.min.js"></script>
                     <script type="text/javascript" language="javascript" src="'.base_url().'js/jquery.dataTables.js"></script>
		     <script type="text/javascript" language="javascript" src="'.base_url().'js/jquery.colorbox.js"></script>';
        $data['css']='<style type="text/css" title="currentStyle">
                        @import "'.base_url().'css/demo_table_jui.css";
                        @import "'.base_url().'css/redmond/jquery-ui-1.9.1.custom.css";
                        @import "'.base_url().'css/patient/patient_personal_info.css";
			            @import "'.base_url().'css/colorbox.css";
                      </style>';
        $data['patient_info'] = $this->patients->patient_info($this->session->userdata('patient_id'));
        /** ADDED 1-12-2012 Rohitashva Singh */
        $query = $this->db->select('patient_login_id')->from('patient_registration')->where('patient_id', $this->session->userdata('patient_id'))->get()->row_array();
        $patient_login_id = $query['patient_login_id'];
        if($this->patients->is_patient_registered['is_primary'] == 'Y')
            $data['current_checkups'] = $this->patients->current_checkups($patient_login_id, 0);
        else
            $data['current_checkups'] = $this->patients->current_checkups($this->session->userdata('patient_id'), 1);
        /* -------------------------------- */
        $data['us_states'] = $this->patients->us_states();
        $this->load->view('patient/patient_home', $data);
    }

    private function _is_not_login_redirect_home(){ //Redirect to 'Home Page' in case Patient has already filled 'Registration Form'
        if(($this->session->userdata('user_type')!='patient'))
            redirect('patient');
        else if(@$this->patients->is_patient_registered['is_registered']=='Y')
               redirect ('patient/home');
    }
    
    private function _is_not_login_redirect_registration_form(){ //Redirect to 'Patient Registration Form' in case Patient has not filled it already
        if(($this->session->userdata('user_type')!='patient'))
            redirect('patient');
        else if(@$this->patients->is_patient_registered['is_registered']=='N')
               redirect ('patient/patient-registration-form');
    }
    
    private function _is_login()
	{
        if(($this->session->userdata('user_type')=='patient'))
		{
           if(@$this->patients->is_patient_registered['is_registered']=='N')
               redirect ('patient/patient-registration-form');
           else if(@$this->patients->is_patient_registered['is_registered']=='Y')
               redirect ('patient/home');
        }
    }
    
    public function forgot_password(){
        $this->_is_login();
        $data['title'] = 'PAM DENTAL - FORGOT PASSWORD';
        $data['page_title'] = 'FORGOT PASSWORD';
        $data['css'] = '<link href="'.base_url().'css/patient/tipTip.css" media="screen" rel="stylesheet" type="text/css" />';
        $data['js'] = '<script type="text/javascript" src="'.base_url().'js/patient/jquery-1.4.4.js"></script>
                       <script type="text/javascript" src="'.base_url().'js/patient/jquery.tipTip.js"></script>
                       <script type="text/javascript" src="'.base_url().'js/patient/jquery.tipTip.minified.js"></script>';
        if(isset($_POST['submit'])){
            //echo '<pre>';
            //print_r($_POST);
            //echo '</pre>';
            //exit;
            $this->form_validation->set_rules('username', 'USERNAME', 'trim|required');
            
            if($this->form_validation->run() == FALSE)
                $this->load->view('patient/patient_forgot_password', $data);
            else
            {
                $user_data = $this->patients->forgot_password();
                if($user_data){
                        $email_content = '<html>
                                            <body style="font-family: Verdana,Arial,Helvetica,sans-serif; font-size: 13px;"> 
                                            <p>Hello <font size=2><code>$first_name</code></font>,</p>
                                            <p>Your PAM login password has been reset successfully.</p>
                                            <p>Access PAM - PATIENT\'s PORTAL, using below details - </p>
                                            <p>USERNAME - <font color="#FF0000" size=2><code>$username</code></font></p>
                                            <p>PASSWORD - <font color="#FF0000" size=2><code>$password</code></font></p>
                                            <p>PAM UIN - <font color="#FF0000" size=2><code>$uin</code></font></p>
                                            <p>&nbsp;</p>
                                            <p>In case you have any ideas or suggestions, please feel free to give us your feedback - <a href="mailto:admin@pamdental.com">admin@pamdental.com</a></p>
                                            <hr/>
                                            <p>ADMIN<br/>PAM DENTAL</p>
                                          </body>
                                          </html>';
                       $email_content = str_replace('$first_name', $user_data['first_name'], $email_content);
                       $email_content = str_replace('$username', $user_data['username'], $email_content);
                       $email_content = str_replace('$password', $user_data['password'], $email_content);
                       $email_content = str_replace('$uin', $user_data['patient_uin'], $email_content);
                       
                       //SEND EMAIL
                       $this->email->from('noreply@pamdental.com', 'noreply');
                       $this->email->to($user_data['email']);
                       $this->email->bcc($this->emails->bcc_emails(3));
                       $this->email->subject('PAM DENTAL:: FORGOT PASSWORD');
                       $this->email->message($email_content);
                       $this->email->send();

                       $this->session->set_flashdata('login_error', 'Your new login details have been mailed to you, please check if mail has not been marked as a spam.');
                       redirect('patient/');
                   }
                else
                {
                   $this->session->set_flashdata('login_error', 'No such user exists in our database.');
                   redirect('patient/');
                }
            }
        }
        else
            $this->load->view('patient/patient_forgot_password', $data);
    }

    public function appointment()
    {
        $this->_is_not_login_redirect_registration_form();
            $data['title'] = 'PAM DENTAL - BOOK AN APPOINTMENT';
            $data['page_title'] = 'PATIENT APPOINTMENT PAGE';
            $data['css'] = '<link href="'.base_url().'calendar/libs/css/smoothness/jquery-ui-1.8.11.custom.css" media="screen" rel="stylesheet" type="text/css" />
                            <link href="'.base_url().'calendar/libs/jquery.weekcalendar.css" media="screen" rel="stylesheet" type="text/css" />
                            <link href="'.base_url().'calendar/skins/default.css" media="screen" rel="stylesheet" type="text/css" />
                            <link href="'.base_url().'calendar/skins/gcalendar.css" media="screen" rel="stylesheet" type="text/css" />';
            $data['js'] = '<script type="text/javascript" src="'.base_url().'js/patient/jquery-1.4.4.js"></script>
                   		   <script type="text/javascript" src="'.base_url().'calendar/libs/jquery-ui-1.8.11.custom.min.js"></script>
                   		   <script type="text/javascript" src="'.base_url().'calendar/libs/jquery-ui-i18n.js"></script>
                           <script type="text/javascript" src="'.base_url().'calendar/libs/date.js"></script>
                           <script type="text/javascript" src="'.base_url().'calendar/libs/jquery.weekcalendar.js"></script>';
            $this->load->view('patient/patient_appointment', $data);			   	

    }
    /** ADD APPOINTMENT
     * @author Vaibhav Soni <vaibhav0812@gmail.com>
     * @param none
     * MODIFIED 8-12-2012 2:37 AM by - Rohitashva Singh <rohitashvarathore@gmail.com>
     */ 
    public function add_appointment()
    {
        $this->_is_not_login_redirect_registration_form();
	    $sql = 'SELECT `schedule_id` FROM schedule WHERE `visit_date` = "'.$_POST['visit_date'].'" AND schedule_status != "Canceled" AND
				    (
					    (("'.date('H:i:s',strtotime($_POST['start_time'])).'" BETWEEN `start_time` AND SUBTIME(`end_time`,"00:00:01")
					    OR "'.date('H:i:s',strtotime($_POST['end_time'])).'" BETWEEN AddTime(`start_time`,"00:00:01") AND `end_time`))
					    OR((AddTime(`start_time`,"00:00:01") BETWEEN "'.date('H:i:s',strtotime($_POST['start_time'])).'" AND "'.date('H:i:s',strtotime($_POST['end_time'])).'")
					    OR  SUBTIME(`end_time`,"00:00:01") BETWEEN "'.date('H:i:s',strtotime($_POST['start_time'])).'" AND "'.date('H:i:s',strtotime($_POST['end_time'])).'")
				    )
				    ;';
	    $query = $this->db->query($sql);


                    if($query->num_rows())
                        echo 0;
                    else
                    {
                            $this->db->set('schedule_status', 'PENDING');
                            $this->db->set('visit_date',$_POST['visit_date']);
                            $this->db->set('start_time',$_POST['start_time']);
                            $this->db->set('end_time',$_POST['end_time']);
                            $this->db->set('patient_id',$_POST['patient_id']);
                            $this->db->set('visit_type',$_POST['visit_type']);
                            $this->db->set('visit_note',$_POST['visit_note']);
                            $this->db->set('added_date',date('Y-m-d H:i:s'));
                            /* ADDED 8-12-2012 2:37 */
                                if(@$_POST['checkup_id']):
                                $this->db->set('patient_checkup_id',@$_POST['checkup_id']);
                                endif;
                            /* -------------------- */
                            $this->db->insert('schedule');
			                $return_id = $this->db->insert_id();
                            /* MODIFIED 10-12-2012 11:09 PM - UPDATE patient_checkup table */
                             if(@$_POST['checkup_id']):
                              $this->db->set('appointment_taken', 'Y');
                              $this->db->where('patient_checkup_id', @$_POST['checkup_id']);
                              $this->db->update('patient_checkup');
                             endif;
                            /* ----------------------------------------------------------  */
                            $this->_send_appointment_email($_POST, 0);
                            //echo $this->db->insert_id();
                            echo $return_id;
                    }
    }

    private function _send_appointment_email($post, $flag)
    {
        $frontoffice_email_and_name = $this->emails->frontoffice_email_and_name();
        $patient_email_and_name = $this->emails->patient_email_and_name($post['patient_id']); 
        if($frontoffice_email_and_name && $patient_email_and_name) {
            switch($flag){
                case 0:
                    $content = '<html>
                        <body style="font-family: Verdana,Arial,Helvetica,sans-serif; font-size: 13px;">
                        <p> Hi $front,</p><br/>
                        <p> Patient has asked for an appointment. Below are the details:</p>
                        <table border="0" cellpadding="5" width="500">
                          <tbody>
                                <tr>
                                  <td nowrap="nowrap" valign="top" width="20%"><strong>Patient Name:</strong></td>
                                  <td nowrap="nowrap" valign="top">'.$this->session->userdata('name').'</td>
                                </tr>
                                <tr>
                                  <td nowrap="nowrap" valign="top"> <strong>Visit Type:</strong></td>
                                  <td nowrap="nowrap" valign="top">'.$post['visit_type'].'</td>
                                </tr>
                                <tr>
                                  <td nowrap="nowrap" valign="top"><strong>Visit Date:</strong></td>
                                  <td nowrap="nowrap" valign="top">'.date('F j, Y', strtotime($post['visit_date'])).'</td>
                                </tr>
                                <tr>
                                  <td nowrap="nowrap" valign="top"><strong>Visit Time:</strong></td>
                                  <td nowrap="nowrap" valign="top">'.date('h:i A', strtotime($post['start_time'])).' - '.date('h:i A', strtotime($post['end_time'])).'</td>
                                </tr>
                                <tr>
                                  <td nowrap="nowrap" valign="top"><strong>Visit Note:</strong></td>
                                  <td nowrap="nowrap" valign="top">'.$post['visit_note'].'</td>
                                </tr>
                          </tbody>
                        </table>
                        <p>In case you have any ideas or suggestions, please feel free to give us your feedback - <a href="mailto:admin@pamdental.com">admin@pamdental.com</a></p>
                        <hr/>
                        <p>ADMIN<br/>PAM DENTAL</p>
                        <b>THIS IS A SYSTEM GENERATED MAIL. REPLIES TO THIS MAIL ID WILL NOT BE RESPONDED.</b>
                        </body>
                        </html>';
                        break;
                    
                    case 1:
                        $content = '<html>
                            <body style="font-family: Verdana,Arial,Helvetica,sans-serif; font-size: 13px;">
                            <p> Hi $front,</p><br/>
                            <p> Patient has carried out an amendment in appointment requested previously. Below are the appointment details:</p>
                            <table border="0" cellpadding="5" width="500">
                              <tbody>
                                    <tr>
                                      <td nowrap="nowrap" valign="top" width="20%"><strong>Patient Name:</strong></td>
                                      <td nowrap="nowrap" valign="top">'.$this->session->userdata('name').'</td>
                                    </tr>
                                    <tr>
                                      <td nowrap="nowrap" valign="top"> <strong>Visit Type:</strong></td>
                                      <td nowrap="nowrap" valign="top">'.$post['visit_type'].'</td>
                                    </tr>
                                    <tr>
                                      <td nowrap="nowrap" valign="top"><strong>Visit Date:</strong></td>
                                      <td nowrap="nowrap" valign="top">'.date('F j, Y', strtotime($post['visit_date'])).'</td>
                                    </tr>
                                    <tr>
                                      <td nowrap="nowrap" valign="top"><strong>Visit Time:</strong></td>
                                      <td nowrap="nowrap" valign="top">'.date('h:i A', strtotime($post['start_time'])).' - '.date('h:i A', strtotime($post['end_time'])).'</td>
                                    </tr>
                                    <tr>
                                      <td nowrap="nowrap" valign="top"><strong>Visit Note:</strong></td>
                                      <td nowrap="nowrap" valign="top">'.$post['visit_note'].'</td>
                                    </tr>
                              </tbody>
                            </table>
                            <p>In case you have any ideas or suggestions, please feel free to give us your feedback - <a href="mailto:admin@pamdental.com">admin@pamdental.com</a></p>
                            <hr/>
                            <p>ADMIN<br/>PAM DENTAL</p>
                            <b>THIS IS A SYSTEM GENERATED MAIL. REPLIES TO THIS MAIL ID WILL NOT BE RESPONDED.</b>
                            </body>
                            </html>';
                            break;
                            
                    case 1:
                        $content = '<html>
                            <body style="font-family: Verdana,Arial,Helvetica,sans-serif; font-size: 13px;">
                            <p> Hi $front,</p><br/>
                            <p> Patient has carried out an amendment in appointment requested previously. Below are the appointment details:</p>
                            <table border="0" cellpadding="5" width="500">
                              <tbody>
                                    <tr>
                                      <td nowrap="nowrap" valign="top" width="20%"><strong>Patient Name:</strong></td>
                                      <td nowrap="nowrap" valign="top">'.$this->session->userdata('name').'</td>
                                    </tr>
                                    <tr>
                                      <td nowrap="nowrap" valign="top"> <strong>Visit Type:</strong></td>
                                      <td nowrap="nowrap" valign="top">'.$post['visit_type'].'</td>
                                    </tr>
                                    <tr>
                                      <td nowrap="nowrap" valign="top"><strong>Visit Date:</strong></td>
                                      <td nowrap="nowrap" valign="top">'.date('F j, Y', strtotime($post['visit_date'])).'</td>
                                    </tr>
                                    <tr>
                                      <td nowrap="nowrap" valign="top"><strong>Visit Time:</strong></td>
                                      <td nowrap="nowrap" valign="top">'.date('h:i A', strtotime($post['start_time'])).' - '.date('h:i A', strtotime($post['end_time'])).'</td>
                                    </tr>
                                    <tr>
                                      <td nowrap="nowrap" valign="top"><strong>Visit Note:</strong></td>
                                      <td nowrap="nowrap" valign="top">'.$post['visit_note'].'</td>
                                    </tr>
                              </tbody>
                            </table>
                            <p>In case you have any ideas or suggestions, please feel free to give us your feedback - <a href="mailto:admin@pamdental.com">admin@pamdental.com</a></p>
                            <hr/>
                            <p>ADMIN<br/>PAM DENTAL</p>
                            <b>THIS IS A SYSTEM GENERATED MAIL. REPLIES TO THIS MAIL ID WILL NOT BE RESPONDED.</b>
                            </body>
                            </html>';
                            break;            
            }
            
            $content = str_replace('$front', $frontoffice_email_and_name['first_name'], $content);
            $this->email->from('noreply@pamdental.com', 'noreply');
            $this->email->to($frontoffice_email_and_name['email']);
            $this->email->cc($patient_email_and_name['email']);
            $this->email->bcc($this->emails->bcc_emails(3)); 
            $this->email->subject('PAM DENTAL:: Patient Appointment');
            $this->email->message($content);
            $this->email->send(); 
        }          
    }
    
    public function update_appointment()
    {
            $this->_is_not_login_redirect_registration_form();
        	
            $this->db->set('start_time',$_POST['start_time']);
            $this->db->set('end_time',$_POST['end_time']);
            $this->db->set('visit_type',$_POST['visit_type']);
            $this->db->set('visit_note',$_POST['visit_note']);
            $this->db->where('schedule_id',$_POST['schedule_id']);
            $this->db->update('schedule');
            
            $this->_send_appointment_email($_POST, 1);
            
            echo 'Appointment updated successfully.';
    }

    public function delete_appointment()
    {
        $this->_is_not_login_redirect_registration_form();
        $this->db->where('schedule_id',$_POST['schedule_id']);
        $this->db->delete('schedule'); 
        echo 'Appointment deleted successfully.';
    }

    public function get_appointment()
    {
       	$this->_is_not_login_redirect_registration_form();
        $this->db->select('s.*, concat(p.first_name, " ", p.last_name) as patient_name',false);
        $this->db->from('schedule s');
        $this->db->join('patient_registration p', 'p.patient_id = s.patient_id', 'left'); // this joins the user table to topics
        $this->db->where('s.schedule_status !=','Canceled');
        $query = $this->db->get();
        if($query->num_rows())
        {
            foreach($query->result_array() as $row):
                         $data[] = $row;
            endforeach;
                    foreach($data as $key=>$app)
            {
                $visit_date = strtotime($app['visit_date']);
                $year = date('Y', $visit_date);
                $month = date('n', $visit_date);
                $day = date('j', $visit_date);
                $data[$key]['year'] = (int)($year);
                $data[$key]['month'] = (int)($month);
                $data[$key]['day'] = (int)($day);
            }

            $dat['appointments'] = $data;	
            foreach($dat['appointments'] as $app):
            $visit_date = strtotime($app['visit_date']);
            $st = strtotime($app['start_time']);
            $et = strtotime($app['end_time']);
            $year = date('Y', $visit_date);
            $month = date('n', $visit_date);
            $day = date('j', $visit_date);
            $sh = date('H', $st);
            $eh = date('H', $et);
            $sm = date('i', $st);
            $em = date('i', $et);
            $ss = date('s', $st);
            $es = date('s', $et);

            $arr[]=array( 
              'id'   => $app['schedule_id'], 
              'title'=> ($app['patient_id'] == $this->session->userdata('patient_id'))?$app['patient_name']: 'BUSY', 
              'start'=> date('c',mktime($sh,$sm,$ss,$month,$day,$year)), 
              'end'  => date('c',mktime($eh,$em,$es,$month,$day,$year)),
              'patient_id' => $app['patient_id'],
                          'visit_type' => $app['visit_type'],
                          'visit_note' => $app['visit_note']
            ); 
            endforeach;
        }
        else
        {
                 $arr[]=array( 
              'id'   => 0, 
              'title'=> 0, 
              'start'=> 0, 
              'end'  => 0
            ); 
        }
        echo '{"events":'.json_encode($arr).'}'; 	
    }

    /**
     * MODIFIED 1-12-2012 5:57 PM
     * @author Rohitashva Singh <rohitashvarathore@gmail.com>
     * @param none
     */    
    public function view_checkup(){
       $this->_is_not_login_redirect_registration_form();
       $patient_checkup_id = base64_decode($this->uri->segment(3));
       $patient_id = base64_decode($this->uri->segment(4));
       if($patient_checkup_id && $patient_id){
           $data['title'] = 'PAM DENTAL - VIEW CHECKUP';
           $data['page_title'] = 'VIEW CHECKUP';
           $data['css'] = '<link href="'.base_url().'css/patient/reveal.css" media="screen" rel="stylesheet" type="text/css" />';
           $data['js'] = '<script type="text/javascript" src="'.base_url().'js/patient/jquery-1.4.4.min.js"></script>
                          <script type="text/javascript" src="'.base_url().'js/patient/jquery.reveal.js"></script>';
           /** ---------------------DATA--------------------- */	   
            $data['get_checkup'] = $this->patients->get_checkup(@$patient_id, @$patient_checkup_id);
            $data['get_checkup_detail'] = $this->patients->get_checkup_detail(@$patient_id, @$patient_checkup_id);
            $data['patient_data'] = $this->patients->patient_info(@$patient_id)->row_array();
            // ADDED 30-111-2012 6:45 PM
            $data['guarantor_data'] = $this->patients->guarantor_info(@$patient_id)->row_array();
            // -------------------------
                $data['us_states'] = $this->patients->us_states();
                $data['get_checkup_price'] = $this->patients->get_checkup_price(@$patient_id, $patient_checkup_id);
            /** ---------------------------------------------- */
            if($data['get_checkup'] && $data['patient_data'] && $data['get_checkup_detail'] && $data['get_checkup_price'])
               $this->load->view('patient/patient_view_checkup', $data);
           else
               redirect('patient/treatment-archive');
       }
       else redirect('patient/treatment-archive');
   }
   
   //02/11/2012
   //vaibhav
   public function profile_pdf()
   {
        $this->_is_not_login_redirect_registration_form();
        $this->load->helper('profile_pdf');
        $this->load->library('parser');
        $pdf['result'] = $this->patients->patient_details($this->session->userdata('patient_id'));
        $pdf['us_states'] = $this->patients->us_states()->result_array();
        $html = $this->parser->parse('patient/patient_profile_pdf.php', $pdf, true);
        $pdf_name = str_replace(' ', '_', $this->session->userdata('name'));
        //die($html);
        //echo $html;
        pdf_create($html,$pdf_name,true); 	
   }
   
   /** * Treatment Archive Page
    * @access public
    * @param none 
    * @author Rohitashva Singh <rohitashvarathore@gmail.com>
    * 6 November 2012
    */
   
   public function treatment_archive(){
       $this->_is_not_login_redirect_registration_form();
       $patient_id = $this->session->userdata('patient_id');
       if($patient_id){
            $data['title'] = 'PAM DENTAL - TREATMENT ARCHIVE';
            $data['page_title'] = 'TREATMENT ARCHIVE';
            $data['js']='<script type="text/javascript" language="javascript" src="'.base_url().'js/jquery_1.7.1.js"></script>
                         <script type="text/javascript" language="javascript" src="'.base_url().'js/jquery.dataTables.js"></script>';
            $data['css']='<style type="text/css" title="currentStyle">
                        @import "'.base_url().'css/demo_table_jui.css";
                        @import "'.base_url().'css/redmond/jquery-ui-1.9.1.custom.css";
                    </style>';
            /** MODIFIED 1-12-2012 Rohitashva Singh */
            //$data['result'] = $this->frontoffice_model->patient_checkup_archive($patient_id);
            $query = $this->db->select('patient_login_id')->from('patient_registration')->where('patient_id', $this->session->userdata('patient_id'))->get()->row_array();
            $patient_login_id = $query['patient_login_id'];
            if($this->patients->is_patient_registered['is_primary'] == 'Y')
                $data['result'] = $this->patients->patient_checkup_archive($patient_login_id, 0);
            else
                $data['result'] = $this->patients->patient_checkup_archive($this->session->userdata('patient_id'), 1);
            /* -------------------------------- */
            //if($data['result'])
               $this->load->view('patient/patient_treatment_archive', $data);
            //else redirect('patient/home');
       }
       else redirect('patient/home');
   }
   
   /** * PAY FOR TREATMENT (PAYPAL PRO)
    * @author Rohitashva Singh <jrohitashvarathore@gmail.com>
    * @param none 
    * @access public
    * MODIFIED 7-12-2012 10:13 PM
    */
   public function pay_for_treatment()
   {
       $this->_is_not_login_redirect_registration_form();
       $patient_checkup_id = base64_decode($this->uri->segment(3));
       $patient_id = base64_decode($this->uri->segment(4));
       if($patient_checkup_id && $patient_id)
	{
           $data['title'] = 'PAM DENTAL - PAY FOR YOUR TREATMENT';
           $data['page_title'] = 'PAY FOR YOUR TREATMENT';
           $data['css'] = '<link href="'.base_url().'css/patient/reveal.css" media="screen" rel="stylesheet" type="text/css" />';
           $data['js'] = '<script type="text/javascript" src="'.base_url().'js/patient/jquery-1.4.4.min.js"></script>
                          <script type="text/javascript" src="'.base_url().'js/patient/jquery.reveal.js"></script>';
           $data['get_checkup_for_pay'] = $this->patients->get_checkup_for_pay($patient_id, $patient_checkup_id);
           $data['get_checkup_price_for_pay'] = $this->patients->get_checkup_price($patient_id, $patient_checkup_id);
            if(isset($_POST['submit']))
            {
                $this->session->set_userdata(array('patient_checkup_id' => $patient_checkup_id,'total_amount'=>$_POST['total'], 'treat_ids'=> $_POST['treat']));
                /* SEND PAYMENT RECIEPT
                 */
                redirect('patient/proceed_with_payment/'.$this->uri->segment(3).'/'.$this->uri->segment(4));
            }
            if($data['get_checkup_for_pay'] && $data['get_checkup_price_for_pay'])
               $this->load->view('patient/patient_pay_for_treatment', $data);
            else redirect('patient/home');
       }
       else redirect('patient/home');
   }
   
    /** * AJAX CALL FOR TREATMENT DETAIL
    * @author Rohitashva Singh <jrohitashvarathore@gmail.com>
    * @param int $treat_id 
    * @access public
    * 8 November 2012
    */
   public function treatment_detail(){
       $this->db->select('price, treatment_insurance, treatment_deductable, pros, cons');
       $this->db->where('treat_id', $_POST['treat_id']);
       $this->db->from('treatment_options');
       $query = $this->db->get()->row_array();
       if($query){
           echo json_encode($query);
       }
   }
   
    /** * Patient Edit Profile
    * @access public
    * @param none 
    * @author Vaibhav Soni
    * 6 November 2012
    */
    public function patient_registration_form_edit()
    {
        $this->_is_not_login_redirect_registration_form();
        $data['title'] = 'PAM DENTAL - EDIT PATIENT REGISTRATION FORM';
        $data['page_title'] = 'EDIT PATIENT REGISTRATION FORM';
        $data['css'] = '<link href="'.base_url().'css/patient/tipTip.css" media="screen" rel="stylesheet" type="text/css" />
                        <link rel="stylesheet" href="'.base_url().'css/patient/jquery.ui.all.css">';
        $data['js'] = '<script src="'.base_url().'js/patient/jquery-1.8.2.js"></script>
                       <script type="text/javascript" src="'.base_url().'js/patient/jquery.tipTip.js"></script>
                       <script type="text/javascript" src="'.base_url().'js/patient/jquery.tipTip.minified.js"></script>
                       <script src="'.base_url().'js/patient/jquery.ui.core.js"></script>
                       <script src="'.base_url().'js/patient/jquery.ui.widget.js"></script>
                       <script src="'.base_url().'js/patient/jquery.ui.datepicker.js"></script>';
        $data['patient_status'] = $this->patients->patient_status();
        $data['patient_relationship_insured'] = $this->patients->patient_relationship_insured();
        $data['patient_health_conditions'] = $this->patients->patient_health_conditions();
        $data['patient_other_medicines_or_neutricuticals'] = $this->patients->patient_other_medicines_or_neutricuticals();
        $data['us_states'] = $this->patients->us_states();
		$data['result'] = $this->patients->patient_details($this->session->userdata('patient_id'));
        if(isset($_POST['submit']))
        {
            //@Patient Information
            $this->form_validation->set_rules('sex', 'Sex', '');
            $this->form_validation->set_rules('status', 'Status', 'callback_status_check');
            $this->form_validation->set_rules('ssn', 'Social Security #', 'trim');
            $this->form_validation->set_rules('dln', 'Drivers Lic.#', 'trim');
            $this->form_validation->set_rules('dob', 'Birth Date', 'trim');
            $this->form_validation->set_rules('phone-home', 'Phone (Home)', 'trim|validate_phone_number[phone-home]');
            $this->form_validation->set_rules('phone-work', 'Phone (Work)', 'trim|validate_phone_number[phone-work]');
            $this->form_validation->set_rules('phone-cell', 'Phone (Cell)', 'trim|validate_phone_number[phone-cell]');
            $this->form_validation->set_rules('email', 'Email ', 'trim|required|valid_email');
            $this->form_validation->set_rules('street', 'Street Address ', 'trim');
            $this->form_validation->set_rules('apartment-number', 'Apartment #', 'trim');
            $this->form_validation->set_rules('city', 'City', 'trim');
            $this->form_validation->set_rules('state', 'State', '');
            
                    //@HEALTH CONDITIONS
            $this->form_validation->set_rules('patient-health-condition[]', 'Health condition', '');
            
                    //@OTHER MEDICINES OR NEUTIRCUTICALS
            $this->form_validation->set_rules('patient_other_medicines_or_neutricuticals[]', 'Other Medicines OR Neutricuticals', '');
                        
            if($this->form_validation->run() == FALSE)
                $this->load->view('patient/patient_registration_form_edit', $data);
            else
                {
                    //echo '<pre>';
                    //print_r($_POST);
                    //echo '</pre>';
                    $this->patients->update_patient_registration_data();
                    $this->session->set_flashdata('profile_updated', 'Profile successfully updated.');
                    redirect ('patient/patient-registration-form-edit');
                }
        }
        else
            $this->load->view('patient/patient_registration_form_edit', $data);
     }
	
    /** PAYPAL PRO PAYMENT
     * @author Vaibhav Soni
     * MODIFIED 7-12-2012 10:10 PM
     */
    public function proceed_with_payment()
    {
        $this->_is_not_login_redirect_registration_form();
        $data['title'] = 'PAM DENTAL - EDIT PATIENT REGISTRATION FORM';
        $data['page_title'] = 'EDIT PATIENT REGISTRATION FORM';
        $data['css'] = '<link href="'.base_url().'css/patient/tipTip.css" media="screen" rel="stylesheet" type="text/css" />
			<link rel="stylesheet" href="'.base_url().'css/patient/jquery.ui.all.css">';
        $data['js'] = '<script src="'.base_url().'js/patient/jquery-1.8.2.js"></script>
		       <script type="text/javascript" src="'.base_url().'js/patient/jquery.tipTip.js"></script>
		       <script type="text/javascript" src="'.base_url().'js/patient/jquery.tipTip.minified.js"></script>
		       <script src="'.base_url().'js/patient/jquery.ui.core.js"></script>
		       <script src="'.base_url().'js/patient/jquery.ui.widget.js"></script>
		      <script src="'.base_url().'js/patient/jquery.ui.datepicker.js"></script>';
        $data['us_states'] = $this->patients->us_states();	
        $data['result'] = $this->patients->patient_details($this->session->userdata('patient_id'));
        $patient_checkup_id = base64_decode($this->uri->segment(3));
        $patient_id = base64_decode($this->uri->segment(4));
        if($patient_checkup_id && $patient_id)
        {
            if(isset($_POST['submit']))
            {
                $this->form_validation->set_rules('first_name', 'First Name', 'trim|required');
                $this->form_validation->set_rules('last_name', 'Last name', 'trim|required');
                $this->form_validation->set_rules('card_type', 'Card Type', 'required');
                $this->form_validation->set_rules('card_number', 'Card Number', 'trim|required');
                $this->form_validation->set_rules('expDateMonth', 'Exp. Month', 'required');
                $this->form_validation->set_rules('expDateYear', 'Exp. Year', 'required');
                $this->form_validation->set_rules('card_verification_number', 'Card Varification Number', 'trim|required');
                $this->form_validation->set_rules('address1', 'Billing Address1', 'trim|required');
                $this->form_validation->set_rules('city', 'Billing City', 'trim|required');
                $this->form_validation->set_rules('state', 'Billing State', 'required');
                $this->form_validation->set_rules('zip', 'Zip Code', 'trim|required');
                $this->form_validation->set_rules('amount', 'Amount', 'trim|required');

                if($this->form_validation->run() == FALSE)
                $this->load->view('patient/patient_proceed_with_payment', $data);
                else
                {

                    // Set request-specific fields.
                    $paymentType = urlencode('Sale');	// or 'Authorization'
                    $firstName = urlencode($_POST['first_name']);
                    $lastName = urlencode($_POST['last_name']);
                    $creditCardType = urlencode($_POST['card_type']);
                    $creditCardNumber = urlencode($_POST['card_number']);
                    $expDateMonth = $_POST['expDateMonth'];
                    // Month must be padded with leading zero
                    $padDateMonth = urlencode(str_pad($expDateMonth, 2, '0', STR_PAD_LEFT));

                    $expDateYear = urlencode($_POST['expDateYear']);
                    $cvv2Number = urlencode($_POST['card_verification_number']);
                    $address1 = urlencode($_POST['address1']);
                    $address2 = urlencode($_POST['address2']);
                    $city = urlencode($_POST['city']);
                    $state = urlencode($_POST['state']);
                    $zip = urlencode($_POST['zip']);
                    $country = urlencode($_POST['country']);	// US or other valid country code
                    $amount = urlencode($_POST['amount']);
                    $currencyID = urlencode('USD');	// or other currency ('GBP', 'EUR', 'JPY', 'CAD', 'AUD')

                    // Add request-specific fields to the request string.
                    $nvpStr =	"&PAYMENTACTION=$paymentType&AMT=$amount&CREDITCARDTYPE=$creditCardType&ACCT=$creditCardNumber".
                    "&EXPDATE=$padDateMonth$expDateYear&CVV2=$cvv2Number&FIRSTNAME=$firstName&LASTNAME=$lastName".
                    "&STREET=$address1&CITY=$city&STATE=$state&ZIP=$zip&COUNTRYCODE=$country&CURRENCYCODE=$currencyID";

                    // Execute the API operation; see the PPHttpPost function above.
                    $httpParsedResponseAr = $this->PPHttpPost('DoDirectPayment', $nvpStr);

                    if("SUCCESS" == strtoupper($httpParsedResponseAr["ACK"]) || "SUCCESSWITHWARNING" == strtoupper($httpParsedResponseAr["ACK"]))
                    {
                        /** MODIFIED 10-12-2012 Rohitashva Singh - NEW PARAMETER $patient_id added to insert_billing_details() */
                            //$this->patients->insert_billing_details($httpParsedResponseAr);
                            $this->patients->insert_billing_details($httpParsedResponseAr, $patient_id);
                        /** -------------------------------------------------------------------------------------------------- */
                        $this->session->set_flashdata('show_message', 'Payment was successful. Payment receipt has been mailed.');
                        /** MODIFIED 14-12-2012 8:21 PM - REPLACED $this->session->userdata('patient_id') with $patient_id BELOW - */
                            //$this->patients->patient_log($this->session->userdata('patient_id'), 'Successful payment for treatment. Transaction ID: '.$httpParsedResponseAr['TRANSACTIONID'].'');
                            $this->patients->patient_log($patient_id, 'Successful payment for treatment. Transaction ID: '.$httpParsedResponseAr['TRANSACTIONID'].'');
                        /** ------------------------------------------------------------------------------------------------------ */

                        /** MODIFIED 14-12-2012 8:27 PM - SECOND PARAMETER $patient_id BELOW - */
                            //$this->_mail_payment_reciept($this->session->userdata('patient_checkup_id'));
                            $this->_mail_payment_reciept($this->session->userdata('patient_checkup_id'), $patient_id);
                        /** ------------------------------------------------------------------ */
                        //redirect('patient/home');
                        redirect('patient/appointment/'.base64_encode($this->session->userdata('patient_checkup_id')));
                    }
                    else
                    {
                        //exit('DoDirectPayment failed: ' .print_r($httpParsedResponseAr, true));
                        $errorMsg0 = str_replace('%20', ' ', $httpParsedResponseAr['L_LONGMESSAGE0']);
                        $errorMsg0 = str_replace('%2e', '.', $errorMsg0);
                        $errorMsg1 = str_replace('%20', ' ', $httpParsedResponseAr['L_LONGMESSAGE1']);
                        $errorMsg1 = str_replace('%2e', '.', $errorMsg1);
                        $this->session->set_flashdata('pay_error0', $errorMsg0);
                        $this->session->set_flashdata('pay_error1', $errorMsg1);
                        $this->patients->patient_log($this->session->userdata('patient_id'), 'Unsuccessful payment for treatment.');
                        redirect('patient/proceed-with-payment');
                    }
                }
            }
            else
                $this->load->view('patient/patient_proceed_with_payment', $data);
        }
	    else redirect('patient/home');
    }
    	
    /**
    * Send HTTP POST Request
    *
    * @param	string	The API method name
    * @param	string	The POST Message fields in &name=value pair format
    * @return	array	Parsed HTTP Response body  352391039
    */
   function PPHttpPost($methodName_, $nvpStr_){
        $this->_is_not_login_redirect_registration_form();
        global $environment;
        $environment = 'sandbox';       // or 'beta-sandbox' or 'live'
        // Set up your API credentials, PayPal end point, and API version.
        $API_UserName = urlencode('aidang_1352706858_biz_api1.gmail.com');
        $API_Password = urlencode('1352706914');
        $API_Signature = urlencode('APP2Hv.mLUc64h0UBxByfaNumQu6AooUSGwk4Ix80vYy3OvhfsBytqAs');
        $API_Endpoint = "https://api-3t.paypal.com/nvp";
        if("sandbox" === $environment || "beta-sandbox" === $environment) {
            $API_Endpoint = "https://api-3t.$environment.paypal.com/nvp";
        }
        $version = urlencode('51.0');

        // Set the curl parameters.
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $API_Endpoint);
        curl_setopt($ch, CURLOPT_VERBOSE, 1);

        // Turn off the server and peer verification (TrustManager Concept).
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, FALSE);

        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_POST, 1);

        // Set the API operation, version, and API signature in the request.
        $nvpreq = "METHOD=$methodName_&VERSION=$version&PWD=$API_Password&USER=$API_UserName&SIGNATURE=$API_Signature$nvpStr_";

        // Set the request as a POST FIELD for curl.
        curl_setopt($ch, CURLOPT_POSTFIELDS, $nvpreq);

        // Get response from the server.
        $httpResponse = curl_exec($ch);

        if(!$httpResponse) {
            exit("$methodName_ failed: ".curl_error($ch).'('.curl_errno($ch).')');
        }

        // Extract the response details.
        $httpResponseAr = explode("&", $httpResponse);

        $httpParsedResponseAr = array();
        foreach ($httpResponseAr as $i => $value) {
            $tmpAr = explode("=", $value);
            if(sizeof($tmpAr) > 1) {
                $httpParsedResponseAr[$tmpAr[0]] = $tmpAr[1];
            }
        }

        if((0 == sizeof($httpParsedResponseAr)) || !array_key_exists('ACK', $httpParsedResponseAr)) {
            exit("Invalid HTTP Response for POST request($nvpreq) to $API_Endpoint.");
        }

        return $httpParsedResponseAr;
    }
    
    /** * MAIL PAYMENT RECIEPT
     * @author Rohitashva Singh <rohitashvarathore@gmail.com>
     * @access private
     * @param int $patient_checkup_id
     * MODIFIED 14-12-2012 8:29 PM
     */
    private function _mail_payment_reciept($patient_checkup_id, $patient_id){
        //$patient_id = $this->session->userdata('patient_id');
        if($patient_id && $patient_checkup_id){
            $data['billing_detail'] = $this->admin_model->billing_detail($patient_id, $patient_checkup_id);
            $data['treatment_detail'] = $this->patients->get_checkup_for_pay($patient_id, $patient_checkup_id);
            $data['patient_address'] = $this->admin_model->patient_address($patient_id);
            $data['us_states'] = $this->patients->us_states();
            if($data['billing_detail'] && $data['treatment_detail'] && $data['patient_address']){
                /*SEND EMAIL*/
                $patient_query = $this->emails->patient_email_and_name($patient_id);
        
                $bcc_emails = $this->emails->bcc_emails(1); //ONLY ADMIN
                
                if($patient_query){
                    $email_content = '<html>
                                      <body style="font-family: Verdana,Arial,Helvetica,sans-serif; font-size: 13px;">
                                      Hi '.$patient_query['first_name'].','.br(2).'
                                      Your payment for the treatment was successful. Below is the payment receipt - '.br(1).'';
                    $email_content.= $this->load->view('patient/mail_successful_payment', $data, True);
                    $email_content.= br(5).'<p>In case you have any ideas or suggestions, please feel free to give us your feedback - <a href="mailto:admin@pamdental.com">admin@pamdental.com</a></p>';
                    $email_content.= br(2).'<p>ADMIN<br/>PAM DENTAL</p>';
                    $email_content.= br(2).'<b>'.'THIS IS A SYSTEM GENERATED MAIL. REPLIES TO THIS MAIL ID WILL NOT BE RESPONDED.'.'</b>';
                    $email_content.= br(2).'</body></html>';
                    $this->email->from('noreply@pamdental.com', 'noreply');
                    $this->email->to($patient_query['email']);
                    $this->email->bcc($bcc_emails);
                    $this->email->subject('PAM DENTAL:: Successful Payment - Payment Receipt:'.$data['billing_detail']['transaction_id']);
                    $this->email->message($email_content);
                    $this->email->send();
                }
            }
        }
    }
    
    /** PATIENT BILLING HISTORY
     * @param none
     * @access public
     * @author Rohitashva Singh <rohitashvarathore@gmail.com>
     * MODIFIED 10-12-2012
     */
    public function billing_history(){
        $this->_is_not_login_redirect_registration_form();
        $data['title'] = 'PAM DENTAL - PATIENT BILLING HISTORY';
        $data['page_title'] = 'PATIENT BILLING HISTORY';
        $data['js']='<script type="text/javascript" language="javascript" src="'.base_url().'js/jquery_1.7.1.js"></script>
                     <script type="text/javascript" language="javascript" src="'.base_url().'js/jquery.dataTables.js"></script>';
        $data['css']='<style type="text/css" title="currentStyle">
                        @import "'.base_url().'css/demo_table_jui.css";
                        @import "'.base_url().'css/redmond/jquery-ui-1.9.1.custom.css";
                      </style>';
        $patient_id = $this->session->userdata('patient_id');
        /** MODIFIED 10-12-2012 Rohitashva Singh */
        //$data['result'] = $this->admin_model->patient_billing_history($patient_id);
        $query = $this->db->select('patient_login_id')->from('patient_registration')->where('patient_id', $this->session->userdata('patient_id'))->get()->row_array();
        $patient_login_id = $query['patient_login_id'];
        if($this->patients->is_patient_registered['is_primary'] == 'Y')
            $data['result'] = $this->admin_model->patient_billing_history($patient_login_id, 0);
        else
            $data['result'] = $this->admin_model->patient_billing_history($patient_id, 1);
        /** ------------------------------------ */
        //echo '<pre>';
        //print_r($data['result']);
        //echo '</pre>';
        $this->load->view('patient/patient_billing_history', $data);
    }
    
    /** BILLING DETAIL
     * @param none
     * @access public
     * @author Rohitashva Singh <rohitashvarathore@gmail.com>
     * MODIFIED 10-12-2012
     */
    public function billing_detail(){
        $this->_is_not_login_redirect_registration_form();
        $data['title'] = 'PAM DENTAL - BILLING DETAIL';
        $data['page_title'] = 'PAM DENTAL - BILLING DETAIL';
        $data['js']='<script type="text/javascript" language="javascript" src="'.base_url().'js/jquery_1.7.1.js"></script>
                     <script type="text/javascript" language="javascript" src="'.base_url().'js/jquery.dataTables.js"></script>';
        $data['css']='<style type="text/css" title="currentStyle">
                        @import "'.base_url().'css/demo_table_jui.css";
                        @import "'.base_url().'css/redmond/jquery-ui-1.9.1.custom.css";
                      </style>';
        $patient_checkup_id = base64_decode($this->uri->segment(3));
        $patient_id = base64_decode($this->uri->segment(4));
        //$patient_id = $this->session->userdata('patient_id');
        if($patient_checkup_id && $patient_id){
            $data['billing_detail'] = $this->admin_model->billing_detail($patient_id, $patient_checkup_id);
            $data['treatment_detail'] = $this->patients->get_checkup_for_pay($patient_id, $patient_checkup_id);
            $data['patient_address'] = $this->admin_model->patient_address($patient_id);
            $data['us_states'] = $this->patients->us_states();
            if($data['billing_detail'] && $data['patient_address'])
                $this->load->view('patient/patient_billing_detail', $data);
            else redirect('patient/billing-history');
        }
        else redirect('patient/billing-history');
    }
	
    /** Scheduled Appointment
     * @param none
     * @access public
     * @author vaibhav soni
     * 18-11-2012
     */
    public function scheduled_appointments()
    {
        $this->_is_not_login_redirect_registration_form();
        $data['title'] = 'PAM DENTAL - PATIENT Scheduled Appointments';
        $data['page_title'] = 'PATIENT Scheduled Appointments';
        $data['js']='<script type="text/javascript" language="javascript" src="'.base_url().'js/jquery_1.7.1.js"></script>
                 <script type="text/javascript" language="javascript" src="'.base_url().'js/jquery.dataTables.js"></script>';
        $data['css']='<style type="text/css" title="currentStyle">
                @import "'.base_url().'css/demo_table_jui.css";
                @import "'.base_url().'css/redmond/jquery-ui-1.9.1.custom.css";
                  </style>';
        /* MODIFIED 2-12-2012 8:20 PM */
        //$data['result'] = $this->patients->scheduled_appointment($this->session->userdata('patient_id'));
        $query = $this->db->select('patient_login_id')->from('patient_registration')->where('patient_id', $this->session->userdata('patient_id'))->get()->row_array();
        $patient_login_id = $query['patient_login_id'];
        if($this->patients->is_patient_registered['is_primary'] == 'Y')
            $data['result'] = $this->patients->scheduled_appointment($patient_login_id, 0);
        else
            $data['result'] = $this->patients->scheduled_appointment($this->session->userdata('patient_id'), 1);
        /* -------------------------- */
        $this->load->view('patient/patient_scheduled_appointment', $data);
    }
	
    /** MODIFIED 29-11-2012 2:41 PM BY Rohitashva Singh <rohitashvarathore@gmail.com>
     * @author Vaibhav Soni <vaibhav0812@gmail.com>
     */    
    public function secondry_patient_registration_form()
    {
        $this->_is_not_login_redirect_registration_form();
        $this->db->select('is_primary');
        $this->db->where('patient_id', $this->session->userdata('patient_id'));
        $query = $this->db->get('patient_registration')->row_array();
        if($query && @$query['is_primary'] == 'Y'){
            $data['title'] = 'PAM DENTAL - PATIENT REGISTRATION FORM';
            $data['page_title'] = 'PATIENT REGISTRATION FORM';
            $data['css'] = '<link href="'.base_url().'css/patient/tipTip.css" media="screen" rel="stylesheet" type="text/css" />
                            <link rel="stylesheet" href="'.base_url().'css/patient/jquery.ui.all.css">';
            $data['js'] = '<script src="'.base_url().'js/patient/jquery-1.8.2.js"></script>
                           <script type="text/javascript" src="'.base_url().'js/patient/jquery.tipTip.js"></script>
                           <script type="text/javascript" src="'.base_url().'js/patient/jquery.tipTip.minified.js"></script>
                           <script src="'.base_url().'js/patient/jquery.ui.core.js"></script>
                           <script src="'.base_url().'js/patient/jquery.ui.widget.js"></script>
                           <script src="'.base_url().'js/patient/jquery.ui.datepicker.js"></script>';
            $data['patient_status'] = $this->patients->patient_status();
            $data['patient_relationship_insured'] = $this->patients->patient_relationship_insured();
            $data['patient_health_conditions'] = $this->patients->patient_health_conditions();
            $data['patient_other_medicines_or_neutricuticals'] = $this->patients->patient_other_medicines_or_neutricuticals();
            $data['us_states'] = $this->patients->us_states();
            if(isset($_POST['submit'])){
                //echo '<pre>';
                //print_r($_POST);
                //echo '</pre>';
                //@Patient Information
                $this->form_validation->set_rules('first-name', 'First Name', 'required');
                $this->form_validation->set_rules('last-name', 'Last Name', 'required');
                $this->form_validation->set_rules('middle-initial', 'Middle Initial', 'required');
                $this->form_validation->set_rules('sex', 'Sex', '');
                $this->form_validation->set_rules('status', 'Status', 'callback_status_check');
                $this->form_validation->set_rules('ssn', 'Social Security #', 'trim');
                $this->form_validation->set_rules('dln', 'Drivers Lic.#', 'trim');
                $this->form_validation->set_rules('dob', 'Birth Date', 'trim');
                $this->form_validation->set_rules('phone-home', 'Phone (Home)', 'trim|validate_phone_number[phone-home]');
                $this->form_validation->set_rules('phone-work', 'Phone (Work)', 'trim|validate_phone_number[phone-work]');
                $this->form_validation->set_rules('phone-cell', 'Phone (Cell)', 'trim|validate_phone_number[phone-cell]');
                $this->form_validation->set_rules('email', 'Email ', 'trim|required|valid_email');
                $this->form_validation->set_rules('street', 'Street Address ', 'trim');
                $this->form_validation->set_rules('apartment-number', 'Apartment #', 'trim');
                $this->form_validation->set_rules('city', 'City', 'trim');
                $this->form_validation->set_rules('state', 'State', '');

                        //@HEALTH CONDITIONS
                $this->form_validation->set_rules('patient-health-condition[]', 'Health condition', '');

                        //@OTHER MEDICINES OR NEUTIRCUTICALS
                $this->form_validation->set_rules('patient_other_medicines_or_neutricuticals[]', 'Other Medicines OR Neutricuticals', '');

                if($this->form_validation->run() == FALSE)
                    $this->load->view('patient/secondry_patient_registration_form', $data);
                else{
                    //echo '<pre>';
                    //print_r($_POST);
                    //echo '</pre>';
                    $this->patients->insert_patient_registration_data();
                    redirect ('patient/home');
                }
            }
            else
                $this->load->view('patient/secondry_patient_registration_form', $data);
        }
        else redirect('patient/home');
    }
    
    /**  User Agreement - New Patient Sign-Up
    * @param  none
    * @author Rohitashva Singh <rohitashvarathore@gmail.com>
    * CREATED - 19-12-2012 2:26 PM
    */
    public function user_agreement(){
        $this->_is_login();
        $data['title'] = 'PAM DENTAL - CONSENT FOR INTERNET COMMUNICATIONS';
        $data['page_title'] = 'CONSENT FOR INTERNET COMMUNICATIONS';
        $data['js']='<script type="text/javascript" language="javascript" src="'.base_url().'js/jquery_1.7.1.js"></script>
                     <script type="text/javascript" language="javascript" src="'.base_url().'js/jquery.min.js"></script>
                     <script type="text/javascript" language="javascript" src="'.base_url().'js/jquery.colorbox.js"></script>';
        $data['css']='<style type="text/css" title="currentStyle">
                        @import "'.base_url().'css/demo_table_jui.css";
                        @import "'.base_url().'css/redmond/jquery-ui-1.9.1.custom.css";
                        @import "'.base_url().'css/colorbox.css";
                      </style>';
        if(isset($_POST['user_agreement_agree'])){
            redirect('patient/patient-sign-up');
        }              
        $this->load->view('patient/patient_user_agreement');               
    }
    
    /**  User Agreement - Secondary Patient Sign-Up
    * @param  none
    * @author Rohitashva Singh <rohitashvarathore@gmail.com>
    * CREATED - 19-12-2012 3:51 PM
    */
    public function user_agreement_primary(){
        $this->_is_not_login_redirect_registration_form();
        $data['title'] = 'PAM DENTAL - CONSENT FOR INTERNET COMMUNICATIONS';
        $data['page_title'] = 'CONSENT FOR INTERNET COMMUNICATIONS';
        $data['js']='<script type="text/javascript" language="javascript" src="'.base_url().'js/jquery_1.7.1.js"></script>
                     <script type="text/javascript" language="javascript" src="'.base_url().'js/jquery.min.js"></script>
                     <script type="text/javascript" language="javascript" src="'.base_url().'js/jquery.colorbox.js"></script>';
        $data['css']='<style type="text/css" title="currentStyle">
                        @import "'.base_url().'css/demo_table_jui.css";
                        @import "'.base_url().'css/redmond/jquery-ui-1.9.1.custom.css";
                        @import "'.base_url().'css/colorbox.css";
                      </style>';
        if(isset($_POST['user_agreement_agree'])){
            redirect('patient/secondry-patient-registration-form');
        }              
        $this->load->view('patient/patient_user_agreement_primary');               
    }
    
    /** 23-12-2012
    * @author Rohitashva Singh <rohitashvarathore@gmail.com>
    * @param none
    */
    public function patient_event(){
        $this->load->library('selson');
        $this->selson->fetch_derail();
        echo 'Success .....';
    }
}

/* End of file patient.php */
/* Location: ./application/controllers/patient.php */