<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

/**
 * PAM DENTAL - ADMIN Model
 * @author Rohitashva Singh <rohitashvarathore@gmail.com>
 * @copyright 2012
 */
class Admin_Model extends CI_Model
{
    function Admin_Model()
    {
            parent::__construct();	
    }

    public function login()
    {
            $query = $this->db->get_where('admin_login',array('username'=>$_POST['username'],'password' => md5($_POST['password'])));
            return ($query->num_rows==1)? $query->row() : false;
    }

    public function ada_list()
    {
            $record=$this->db->get('ada_codes');
            return ($record->num_rows)? $record : false;
    }

    public function ada_detail()
    {
            $record=$this->db->get_where('ada_codes',array('ada_code_id' => base64_decode($this->uri->segment(3))));
            return ($record->num_rows)? $record->row() : false;
    }

    public function add_ada_code()
    {
            $this->db->set('ada_code', $_POST['ada_code']);
            $this->db->set('description', $_POST['description']);
            $query=$this->db->insert('ada_codes');
            return ($query)? $query : false;
    }

    public function edit_ada_code()
    {

            $this->db->set('description', $_POST['description']);
            $this->db->where('ada_code_id', base64_decode($this->uri->segment(3)));
            $query=$this->db->update('ada_codes');
            return ($query)? $query : false;
    }

    public function ada_treatment_list()
    {
            $sql ='SELECT t.* 
                       FROM treatment_options as t 
                       LEFT JOIN ada_code_treatment_options as atr
                       ON atr.treat_id = t.treat_id
                       WHERE atr.ada_code_id = "'.base64_decode($this->uri->segment(3)).'"
                       ';
            $record=$this->db->query($sql);
            return ($record->num_rows)? $record : false;
    }

    public function ada_add_treatment()
    {
            $this->db->set('description', $_POST['description']);
            $this->db->set('price', $_POST['price']);
            $this->db->set('treatment_insurance', $_POST['treatment_insurance']);
            $this->db->set('treatment_deductable', $_POST['treatment_deductable']);
            $this->db->set('pros', $_POST['pros']);
            $this->db->set('cons', $_POST['cons']);
            $query=$this->db->insert('treatment_options');
            $treat_id = $this->db->insert_id();
            if($treat_id)
            {
                    $this->db->set('ada_code_id', base64_decode($this->uri->segment(3)));
                    $this->db->set('treat_id', $treat_id);
                    $query=$this->db->insert('ada_code_treatment_options');
                    return true;
            }
            else
                    return false;
    }

    public function ada_edit_treatment()
    {
            $this->db->set('description', $_POST['description']);
            $this->db->set('price', $_POST['price']);
            $this->db->set('treatment_insurance', $_POST['treatment_insurance']);
            $this->db->set('treatment_deductable', $_POST['treatment_deductable']);
            $this->db->set('pros', $_POST['pros']);
            $this->db->set('cons', $_POST['cons']);
            $this->db->where('treat_id', base64_decode($_POST['treat_id']));
            $query=$this->db->update('treatment_options');
            return ($query)? $query : false;
    }

    public function ada_treatment_details()
    {
            $sql ='SELECT t.* 
                       FROM treatment_options as t 
                       LEFT JOIN ada_code_treatment_options as atr
                       ON atr.treat_id = t.treat_id
                       WHERE atr.treat_id = "'.base64_decode($this->uri->segment(4)).'" LIMIT 1
                       ';
            $record=$this->db->query($sql);
            return ($record->num_rows)? $record->row() : false;
    }

    public function teeth_list()
    {
            $record=$this->db->get('teeth');
            return ($record->num_rows)? $record : false;
    }

    public function patient_list()
    {
            $sql ='SELECT CONCAT(first_name," ",middle_initial," ",last_name) as name, email, patient_uin, patient_id
                       FROM patient_registration';
            $record=$this->db->query($sql);
            return ($record->num_rows)? $record : false;
    }

    public function patient_log()
    {
            $record=$this->db->order_by('datetime', 'DESC')->get_where('patient_log',array('patient_id' => base64_decode($this->uri->segment(3))));
            return ($record->num_rows)? $record : false;
    }

    public function patient_details()
    {
        $sql ='SELECT p.*,pl.patient_login_id,pl.username, pl.password, pl.is_registered FROM patient_registration as p
                               LEFT JOIN patient_login as pl
                               ON pl.patient_login_id = p.patient_login_id
               WHERE patient_id = "'.base64_decode($this->uri->segment(3)).'"';
        $record=$this->db->query($sql);
        return ($record->num_rows)? $record->row() : false;
    }

    public function get_appointment()
    {
            $this->db->select('s.*, concat(p.first_name, " ", p.last_name) as patient_name',false);
            $this->db->from('schedule s');
            $this->db->join('patient_registration p', 'p.patient_id = s.patient_id', 'left'); // this joins the user table to topics
            $record = $this->db->get();
            return ($record->num_rows)? $record : false;
    }

    public function forgot_password()
    {
        $this->db->select('username, first_name, email');
        $this->db->where('username', @$_POST['username']);
        $query = $this->db->get('admin_login')->row_array();

        if($query)
         {
              $new_password = $this->_generateRandomString();
              $this->db->set('password', md5($new_password));
              $this->db->where('username', @$_POST['username']);
              $this->db->update('admin_login');
              $query['password'] = $new_password;
              return $query;
         }
        else return FALSE;
    }

    private function _generateRandomString($length = 10)
    {
        $characters = '0123456789abcdefghijklmnopqrstuvwxyz_ABCDEFGHIJKLMNOPQRSTUVWXYZ';
        $randomString = '';
        for ($i = 0; $i < $length; $i++) 
        {
            $randomString .= $characters[rand(0, strlen($characters) - 1)];
        }
        return $randomString;
    }

    //02/11/2012
    public function dentist_list()
    {
            $sql ='SELECT *, CONCAT(first_name," ",middle_initial," ",last_name) as name
                   FROM dentist_login';
            $record=$this->db->query($sql);
            return ($record->num_rows)? $record : false;
    }

    public function dentist_log()
    {
        $this->db->order_by('datetime', 'DESC');
        $record=$this->db->get('dentist_log');
        return ($record->num_rows)? $record : false;
    }

    public function frontoffice_list()
    {
            $sql ='SELECT *, CONCAT(first_name," ",middle_initial," ",last_name) as name
                   FROM front_office_login';
            $record=$this->db->query($sql);
            return ($record->num_rows)? $record : false;
    }

    public function frontoffice_log()
    {
        $this->db->order_by('datetime', 'DESC');
        $record=$this->db->get('front_office_log');
        return ($record->num_rows)? $record : false;
    }
    
    /** *
     * @author Rohitashva Singh <rohitashvarathore@gmail.com>
     * @param intiger $patient_id
     * MODIFIED 8-12-2012 2:57 AM
     */
    public function patient_billing_history($id, $flag){
        switch($flag){
            case 0:
                $string = '  SELECT
                                    p.`patient_id`
                                  , p.`patient_uin`
                                  , b.`patient_checkup_id`
                                  , CONCAT(p.`first_name`, \' \', p.`middle_initial`, \' \', p.`last_name`) AS `name`
                                  , b.`total_amount_paid`
                                  , DATE_FORMAT(b.`billing_date`, \'%Y-%m-%d\') AS `date`
                                  , DATE_FORMAT(b.`billing_date`, \'%h:%i %p\') AS `time`
                                  , b.`transaction_id`
                                  , c.`treatment_uin`
                             FROM billing AS b
                             INNER JOIN patient_registration AS p
                                    ON (b.`patient_id` = p.`patient_id`)
                             INNER JOIN patient_checkup AS c
                                    ON (b.`patient_checkup_id` = c.`patient_checkup_id`)
                             WHERE (p.`patient_login_id` ='.$id.')
                             ORDER BY `date` DESC, `time` DESC;';
                break;

            case 1:
                $string = '  SELECT
                                    p.`patient_id`
                                  , p.`patient_uin`
                                  , b.`patient_checkup_id`
                                  , CONCAT(p.`first_name`, \' \', p.`middle_initial`, \' \', p.`last_name`) AS `name`
                                  , b.`total_amount_paid`
                                  , DATE_FORMAT(b.`billing_date`, \'%Y-%m-%d\') AS `date`
                                  , DATE_FORMAT(b.`billing_date`, \'%h:%i %p\') AS `time`
                                  , b.`transaction_id`
                                  , c.`treatment_uin`
                             FROM billing AS b
                             INNER JOIN patient_registration AS p
                                    ON (b.`patient_id` = p.`patient_id`)
                             INNER JOIN patient_checkup AS c
                                    ON (b.`patient_checkup_id` = c.`patient_checkup_id`)
                             WHERE (p.`patient_id` ='.$id.')
                             ORDER BY `date` DESC, `time` DESC;';
                break;
        }

        $query = $this->db->query($string);
        return $query->result_array();
    }
    
    /** *
     * @author Rohitashva Singh <rohitashvarathore@gmail.com>
     * @param type $patient_id PATIENT LOGIN ID
     * @param intiger $patient_checkup_id PATIENT CHECKUP ID
     * 11/11/2012 2:28AM
     */
    public function billing_detail($patient_id, $patient_checkup_id){
        $string = '  SELECT
                            CONCAT(p.`first_name`, \' \', p.`middle_initial`, \' \', p.`last_name`) AS `name`
                          , p.`patient_id`
                          , p.`patient_uin`
                          , b.`total_amount_paid`
                          , DATE_FORMAT(b.`billing_date`, \'%Y-%m-%d\') AS `date`
                          , DATE_FORMAT(b.`billing_date`, \'%h:%i %p\') AS `time`
                          , b.`transaction_id`
                          , b.`patient_checkup_id`
                          , b.`treat_ids`
                     FROM
                         billing AS b
                     INNER JOIN patient_registration AS p
                         ON (b.`patient_id` = p.`patient_id`)
                     WHERE (p.`patient_id` ='.$patient_id.'
                         AND b.`patient_checkup_id` ='.$patient_checkup_id.');';
        $query = $this->db->query($string);
        return $query->row_array();
    }
    
    /** *
     * @author Rohitashva Singh <rohitashvarathore@gmail.com>
     * 11-11-2012 3:11AM
     */
    public function patient_address($patient_id){
        $this->db->select('p_address_apartment_number, p_address_street, p_address_city, p_address_state_id, p_address_zipcode');
        $this->db->from('patient_data');
        $this->db->where('patient_id', $patient_id);
        $query = $this->db->get();
        return $query->row_array();
    }
    
    /** *
     * @param array $treat_ids
     * @author Rohitashva Singh <rohitashvarathore@gmail.com>
     * 11-11-2012 9:31PM
     */
    public function billing_treatment_options($treat_ids){
        $treatment_options = array();
        foreach($treat_ids as $key => $val):
            $this->db->select('description, price, treatment_insurance, treatment_deductable');
            $this->db->from('treatment_options');
            $this->db->where('treat_id', $val);
            $query = $this->db->get()->row_array();
            if($query){
                $treatment_options['description'][] = $query['description'];
                $treatment_options['price'][] = $query['price'];
                $treatment_options['treatment_insurance'][] = $query['treatment_insurance'];
                $treatment_options['treatment_deductible'][] = $query['treatment_deductable'];
            }
        endforeach;
        return $treatment_options;
    }
    
    /** *
     * @author Rohitashva Singh <rohitashvarathore@gmail.com>
     * @param int $checkup_id
     * 11-11-2012 11:29PM
     */
    public function billing_teeth_and_ada($patient_checkup_id){
        $string = 'SELECT
                            t.`description` AS `tooth_desc`
                          , a.`description` AS `ada_code_des`
                     FROM
                         patient_checkup_relation AS r
                         INNER JOIN patient_checkup AS c 
                             ON (r.`patient_checkup_id` = c.`patient_checkup_id`)
                         INNER JOIN teeth AS t 
                             ON (r.`tooth_id` = t.`tooth_id`)
                         INNER JOIN ada_codes AS a
                             ON (r.`ada_code_id` = a.`ada_code_id`)
                         INNER JOIN patient_registration AS p 
                             ON (c.`patient_id` = p.`patient_id`)
                     WHERE (c.`patient_checkup_id` ='.$patient_checkup_id.');';
        $query = $this->db->query($string);
        return $query->result_array();
    }
    
        /** *
     * @author Rohitashva Singh <rohitashvarathore@gmail.com>
     * @param none
     * 12/11/2012 1:25AM
     */
    public function billing_history(){
        $string = '  SELECT
                            p.`patient_id`,
							 p.`patient_uin`
                          , b.`patient_checkup_id`
                          , CONCAT(p.`first_name`, \' \', p.`middle_initial`, \' \', p.`last_name`) AS `name`
                          , b.`total_amount_paid`
                          , DATE_FORMAT(b.`billing_date`, \'%Y-%m-%d\') AS `date`
                          , DATE_FORMAT(b.`billing_date`, \'%h:%i %p\') AS `time`
                          , b.`transaction_id`
                     FROM
                         billing AS b
                         INNER JOIN patient_registration AS p 
                         ON (b.`patient_id` = p.`patient_id`)
                     WHERE (1=1)
                     ORDER BY `date` DESC, `time` DESC;';
        $query = $this->db->query($string);
        return $query->result_array();
    }
	
	//**Vaibhav Soni
	//17-11-2012
	
	public function update_frontoffice_detail()
	{
        $this->db->set('first_name', @$_POST['first_name']);
		$this->db->set('middle_initial', @$_POST['middle_initial']);
		$this->db->set('last_name', @$_POST['last_name']);
		$this->db->set('email', @$_POST['email']);
		$this->db->set('username', @$_POST['username']);
		if(isset($_POST['password']) && $_POST['password']!='')
			$this->db->set('password',  md5(@$_POST['password']));
		$this->db->update('front_office_login');
    }

	//**Vaibhav Soni
	//17-11-2012
	public function update_dentist_detail()
	{
        $this->db->set('first_name', @$_POST['first_name']);
		$this->db->set('middle_initial', @$_POST['middle_initial']);
		$this->db->set('last_name', @$_POST['last_name']);
		$this->db->set('clinic_name', @$_POST['clinic_name']);
		$this->db->set('email', @$_POST['email']);
		$this->db->set('username', @$_POST['username']);
		$this->db->set('address_street', @$_POST['address_street']);
		$this->db->set('address_apartment_number', @$_POST['address_apartment_number']);
		$this->db->set('address_city', @$_POST['address_city']);
		$this->db->set('address_state', @$_POST['address_state']);
		$this->db->set('address_zipcode', @$_POST['address_zipcode']);
		$this->db->set('phone', @$_POST['phone']);
		
		if(isset($_POST['password']) && $_POST['password']!='')
			$this->db->set('password', md5(@$_POST['password']));
        
		$this->db->update('dentist_login');
    }
}
/* End of file admin_model.php */
/* Location: ./application/model/admin_model.php */
