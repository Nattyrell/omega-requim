<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

/**
 * PAM DENTAL - patients Model
 *
 * @author Rohitashva Singh
 */
class Dentists extends CI_Model{
    
    public $dentist_data = array();    
    public function __construct() 
	{
        parent::__construct();
        if($this->session->userdata('user_type') == 'dentist'){
            $this->db->select('first_name, last_name, middle_initial, email');
            $this->db->where('dentist_login_id', $this->session->userdata('user_id'));
            $query = $this->db->get('dentist_login');
            $this->dentist_data = $query->row_array();
            return $this->dentist_data;
        }
    }
    
	public function dentist_login()
	{
        $this->db->select('dentist_login_id, username, password');
        $this->db->where('username', @$_POST['username']);
        $this->db->where('password', md5(@$_POST['password']));
        $query = $this->db->get('dentist_login');
        return $query->row();
    }
    
    public function update_last_login($id)
	{
        $this->db->set('last_login', date('Y-m-d H:i:s'));
        $this->db->where('dentist_login_id', $id);
        $this->db->update('dentist_login');
    }
	
    public function get_patients()
    {
        $query = $this->db->get('patient_registration');
        return $query->result();
    }

    public function get_teeth()
    {
        $query = $this->db->get('teeth');
        return $query->result();
    }
	
    public function get_ada_codes()
    {
        $this->db->select('ada_code_id, ada_code');
        $query = $this->db->get('ada_codes');
        return $query->result();
    }
    
	public function get_ada_treatment($ada_code_id)
    {
        $sql = 'SELECT treat_id,description FROM treatment_options WHERE treat_id IN (SELECT treat_id FROM ada_code_treatment_options WHERE ada_code_id = '.$ada_code_id.');';
        $query = $this->db->query($sql);
        return $query->result();
    }
    
    /** * MODIFIED
     * 
     * @author Rohitashva Singh <rohitashvarathore@gmail.com>
     * @param int $patient_data
     * @return int $patient_checkup_id
     * 18-11-2012 6:40 PM
     */
    public function submit_patient_info($patient_data)
    {
        $this->db->set('patient_id', @$patient_data['patient_id']);
        /**
         * 18-11-2012 9:55 PM
         */
        //$this->db->set('patient_description', ''); //REMOVE LATER
        $this->db->set('treatment_pros', nl2br(@$patient_data['treatment_pros']));
        $this->db->set('treatment_cons', nl2br(@$patient_data['treatment_cons']));
        $this->db->set('treatment_time', @$patient_data['hourcombo'].':'.@$patient_data['mincombo']);
        /**--------------- */
        $this->db->set('notes', nl2br(@$patient_data['notes']));
        $this->db->set('date', date('Y-m-d H:i:s'));

        $this->db->insert('patient_checkup');
        $patient_checkup_id = $this->db->insert_id();

        foreach($_POST['teeth'] as $key => $val) :
            $this->db->set('patient_checkup_id', @$patient_checkup_id);
            $this->db->set('tooth_id', @$val);
            $this->db->set('ada_code_id', @$_POST['ada_codes'][$key]);
            $this->db->set('treat_id', @$_POST['treatment'][$key]);
            $this->db->insert('patient_checkup_relation');
            /** INSERT `treat_id` INTO service_price (NEW CODE)
             * Modified 6-12-2012 9:10 PM
             * @author Rohitashva Singh <jrohitashvarathore@gmail.com>
             */
	    $patient_checkup_relation_id = $this->db->insert_id();
            //$this->db->set('treat_id', @$_POST['treatment'][$key]);
	    $this->db->set('patient_checkup_relation_id', $patient_checkup_relation_id);
            $this->db->insert('service_price');
            /** ------------------------------------- */
        endforeach;
	
	/** UNIQUE TREATMENT PLAN (CHECKUP) UIN
	 * @author Rohitashva Singh <rohitashvarathore@gmail.com>
	 * 2-12-2012 6:43 PM
	*/
	    $treatment_uin = 'T'.sprintf('%04d', $patient_checkup_id);
	    $this->db->set('treatment_uin', $treatment_uin);
	    $this->db->where('patient_checkup_id', $patient_checkup_id);
	    $this->db->update('patient_checkup');
	/* ------------------------------------ */
        
        return $patient_checkup_id;
    }
	
    public function get_patient_treatment_archive($patient_id)
    {
        $sql = 'SELECT a.*,b.*,c.description AS tooth_description,d.description AS ada_description,e.description AS treatment_description 
                        FROM patient_checkup AS a JOIN patient_checkup_relation AS b ON a.patient_checkup_id=b.patient_checkup_id 
                        JOIN teeth AS c ON b.tooth_id=c.tooth_id JOIN ada_codes AS d ON b.ada_code_id= d.ada_code_id 
                        JOIN treatment_options AS e ON b.treat_id = e.treat_id WHERE patient_id ='.$patient_id;
        $query = $this->db->query($sql);
        return $query->result();
    }
	
    public function get_patient_health_condition($patient_id)
    {
        $query = $this->db->query('SELECT p_health_condition FROM patient_registration WHERE patient_id ='.$patient_id.'');
        $health_condition = $query->row();
        $health_condition = unserialize($health_condition->p_health_condition);
        $p_health_condition = array();
        foreach($health_condition as $key => $val):
        $query = $this->db->query('SELECT description FROM health_conditions WHERE health_con_id ='.$val.'');
        $p_health_condition[] = $query->row()->description;
        endforeach;
        return $p_health_condition;
    }
    
    /** *
     * modified 18-11-2012 3:17 AM
     * @author Rohitashva Singh <rohitashvarathore@gmail.com>
     * access public
    */
    public function patient_checkups()
    {
        $query_string = 'SELECT
			      c.`patient_checkup_id`
                            , c.`patient_id`
			    , p.`patient_uin`
                            , CONCAT(p.`first_name`, \' \', p.`last_name`, \' \') AS `name`
                            , p.`first_name`
                            , p.`last_name`
                            , p.`middle_initial`
                            , DATE_FORMAT(`date`, \'%h:%i %p\') AS `time`
                            , DATE_FORMAT(`date`, \'%Y-%m-%d\') AS `date`
                            , c.`status`
			    , c.`treatment_uin`
                        FROM
                            patient_registration AS p
                            INNER JOIN patient_checkup AS c 
                                ON (p.`patient_id` = c.`patient_id`)
                        ORDER BY `date` DESC,`time` DESC;';
        $query = $this->db->query($query_string);
        return $query->result();
    }
    
    public function get_patient($patient_id)
	{
        $query = $this->db->get_where('patient_data', array('patient_id' => $patient_id));
        return $query->row_array();
    }
    
    public function select_health_con($str)
	{
        $this->db->select('description');
        $this->db->where_in('health_con_id', $str);
        $query = $this->db->get('health_conditions');;
        return $query->result_array();
    }
    
    public function select_other_medicines($str)
	{
        $this->db->select('description');
        $this->db->where_in('other_medicine_id', $str);
        $query = $this->db->get('other_medicines_or_neutricuticals');;
        return $query->result_array();
    }
    
    public function patient_details($patient_id)
    {
        $sql ='SELECT p.*, pl.patient_login_id,pl.username, pl.password, pl.is_registered, DATE_FORMAT(p.`registration_date`, \'%Y-%m-%d, %h:%i%p\') AS `registration_date`
                FROM patient_registration as p
                LEFT JOIN patient_login as pl
                ON p.patient_login_id = pl.patient_login_id 
                WHERE (p.patient_id = '.$patient_id.')';
        $record = $this->db->query($sql);
        return $record->row();
    }
    
    public function dentist_log($dentist_login_id, $activity)
	{
        $this->db->set('dentist_login_id', $dentist_login_id);
        $this->db->set('datetime', date('Y-m-d H:i:s'));
        $this->db->set('ip_address', $_SERVER['REMOTE_ADDR']);
        $this->db->set('http_user_agent', $_SERVER['HTTP_USER_AGENT']);
        $this->db->set('activity', $activity);
        $this->db->insert('dentist_log');
    }
	
	 public function forgot_password()
	 {
        $this->db->select('username, first_name, email');
        $this->db->where('username', @$_POST['username']);
        $query = $this->db->get('dentist_login')->row_array();
        
        if($query)
	{
	    $new_password = $this->_generateRandomString();
	    $this->db->set('password', md5($new_password));
	    $this->db->where('username', @$_POST['username']);
	    $this->db->update('dentist_login');
	    $query['password'] = $new_password;
	    return $query;
	}
        else return FALSE;
    }
	
	private function _generateRandomString($length = 10)
	{
    	$characters = '0123456789abcdefghijklmnopqrstuvwxyz_ABCDEFGHIJKLMNOPQRSTUVWXYZ';
    	$randomString = '';
        for ($i = 0; $i < $length; $i++) 
		{
    	    $randomString .= $characters[rand(0, strlen($characters) - 1)];
    	}
    	return $randomString;
    }

	public function dentist_detail()
	{
        $query = $this->db->get('dentist_login');
        return $query->row();
    }
    
	public function update_dentist_detail()
	{
        $this->db->set('first_name', @$_POST['first_name']);
		$this->db->set('middle_initial', @$_POST['middle_initial']);
		$this->db->set('last_name', @$_POST['last_name']);
		$this->db->set('email', @$_POST['email']);
		$this->db->set('username', @$_POST['username']);
		if(isset($_POST['password']) && $_POST['password']!='')
			$this->db->set('password', @$_POST['password']);
        
		$this->db->update('dentist_login');
    }
}

/* End of file dentists.php */
/* Location: ./application/models/dentists.php */
