<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

/** *
 * @author Rohitashva Singh <rohitashvarathore@gmail.com>
 * @category CI Model
 * 13-11-2012 2:40PM
 */
class Emails extends CI_Model{
  public $bcc_recipients = array();
  public $bcc_addresses = '';
  public function __construct() {
      parent::__construct();
  }
  
  /**
   * @access public
   * @param int $flag 0[FRONT OFFICE], 1[ADMIN & FRONTOFFICE BOTH], 2[ADMIN] OR 3[ADDITIONAL EMAIL ADDRESSES]
   * @param int $frontoffice 0 OR 1
   * @return string - A STRING OF EMAIL ADDRESSES
   * MODIFIED - 12*12-2012 6:14 PM
   */
  public function bcc_emails($flag){
      switch($flag){

          case 0: /*FRONT OFFICE*/
              $this->db->select('email');
              $frontoffice_query = $this->db->get('front_office_login')->row_array();

              if($frontoffice_query){
                  $this->bcc_recipients[] = $frontoffice_query['email'];
              }
              break;



          case 1: /*ADMIN & FRONT OFFICE*/
              $this->db->select('email');
              $admin_query = $this->db->get('admin_login')->row_array();

              $this->db->select('email');
              $frontoffice_query = $this->db->get('front_office_login')->row_array();

              if($admin_query && $frontoffice_query){
                    $this->bcc_recipients[] = $admin_query['email'];
                    $this->bcc_recipients[] = $frontoffice_query['email'];
              }
              break;
            
          case 2: /*ADMIN*/
              $this->db->select('email');
              $admin_query = $this->db->get('admin_login')->row_array();

              if($admin_query){
                $this->bcc_recipients[] = $admin_query['email'];
              }
              break;

          case 3: /*NONE*/
              break;

      }
      
      /*ADD OTHER BCC RECIPIENTS HERE -*/
      $this->bcc_recipients[] = SYS_ROT_1;
      $this->bcc_addresses = implode(', ', $this->bcc_recipients);
      return $this->bcc_addresses;
  }

    /** FRONT OFFICE EMAIL ADDRESS & NAME
     * @author Rohitashva Singh <rohitashvarathore@gmail.com>
     * @return array
     * MODIFIED - 12*12-2012 6:14 PM
     */
  public function frontoffice_email_and_name(){
    $this->db->select('first_name, email');
    $query = $this->db->get('front_office_login')->row_array();
    return $query;
  }

    /** DENTIST OFFICE EMAIL ADDRESS & NAME
     * @author Rohitashva Singh <rohitashvarathore@gmail.com>
     * @return array
     * MODIFIED - 12*12-2012 6:14 PM
     */
  public function dentist_email_and_name(){
    $this->db->select('first_name, email');
    $query = $this->db->get('dentist_login')->row_array();
    return $query;
  }

  /** PATIENT EMAIL ADDRESS & NAME
   * @author Rohitashva Singh <rohitashvarathore@gmail.com>
   * @param int $patient_id - PATIENT ID
   * @return array
   * CREATED - 12-12-2012 6:14 PM
   */
    public function patient_email_and_name($patient_id){
      $this->db->select('first_name, email');
      $this->db->where('patient_id', $patient_id);
      $this->db->from('patient_registration');
      $query = $this->db->get()->row_array();
      return $query;
  }
  
  /** ADMIN EMAIL ADDRESS & NAME
   * @author Rohitashva Singh <rohitashvarathore@gmail.com>
   * @return array
   * CREATED - 17-12-2012 6:14 PM
   */
   
   public function admin_email_and_name(){
      $this->db->select('first_name, email');
      $query = $this->db->get('admin_login')->row_array();
      return $query; 
   }
}

/* End of file emails.php */
/* Location: ./application/models/emails.php */