<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

/**
 * PAM DENTAL - Front Office Model
 * @author Rohitashva Singh <rohitashvarathore@gmail.com>
 * @copyright 2012
 */
class Frontoffice_model extends CI_Model{
    /** * New variable added - $checkups_pending
    * @access public
    * Rohitashva Singh
    * 3 november 2012
    */
   public $checkups_pending = array();
   
   public function __construct() 
	{
        parent::__construct();
        
        /** * New query added - A count of checkups pending
                *
                * @access public 
                * Rohitashva Singh
                * 3 november 2012
        */
        if($this->session->userdata('user_type') == 'frontoffice'){
            $query = $this->db->query('SELECT COUNT(`patient_checkup_id`)AS `checkups_pending` FROM patient_checkup WHERE `status` = \'Pending\';');
            $this->checkups_pending = $query->row_array();
            return $this->checkups_pending;
            }
        }
    
    public function frontoffice_login()
	{
        $this->db->select('front_office_login_id, username, password, email');
        $this->db->where('username', @$_POST['username']);
        $this->db->where('password', md5(@$_POST['password']));
        $query = $this->db->get('front_office_login');
        return $query->row();
    }
	
	public function frontoffice_detail()
	{
        $query = $this->db->get('front_office_login');
        return $query->row();
    }
    
	public function update_frontoffice_detail()
	{
        $this->db->set('first_name', @$_POST['first_name']);
		$this->db->set('middle_initial', @$_POST['middle_initial']);
		$this->db->set('last_name', @$_POST['last_name']);
		$this->db->set('email', @$_POST['email']);
		$this->db->set('username', @$_POST['username']);
		if(isset($_POST['password']) && $_POST['password']!='')
			$this->db->set('password', @$_POST['password']);
        
		$this->db->update('front_office_login');
    }

    public function update_last_login($id)
	{
        $this->db->set('last_login', date('Y-m-d H:i:s'));
        $this->db->where('front_office_login_id ', $id);
        $this->db->update('front_office_login');
    }
	
	 public function front_office_log($frontoffice_login_id, $activity)
	 {
            $this->db->set('front_office_login_id', $frontoffice_login_id);
            $this->db->set('datetime', date('Y-m-d H:i:s'));
            $this->db->set('ip_address', $_SERVER['REMOTE_ADDR']);
            $this->db->set('http_user_agent', $_SERVER['HTTP_USER_AGENT']);
            $this->db->set('activity', $activity);
            $this->db->insert('front_office_log');
        }
	
	 public function forgot_password()
	 {
        $this->db->select('username, first_name, email');
        $this->db->where('username', @$_POST['username']);
        $query = $this->db->get('front_office_login')->row_array();
        
        if($query)
		{
        	$new_password = $this->_generateRandomString();
        	$this->db->set('password', md5($new_password));
        	$this->db->where('username', @$_POST['username']);
        	$this->db->update('front_office_login');
        	$query['password'] = $new_password;
        	return $query;
        }
        else return FALSE;
    }
	
	private function _generateRandomString($length = 10)
	{
    	$characters = '0123456789abcdefghijklmnopqrstuvwxyz_ABCDEFGHIJKLMNOPQRSTUVWXYZ';
    	$randomString = '';
        for ($i = 0; $i < $length; $i++) 
		{
    	    $randomString .= $characters[rand(0, strlen($characters) - 1)];
    	}
    	return $randomString;
    }
    
    /** * Review Checkups Page
            *
            * @access public 
            * @param none 
            * @shows list of pending checkups
            * @author Rohitashva Singh <rohitashvarathore@gmail.com>
            * 23 October 2012
    */
    public function review_checkups(){
        $query_string = 'SELECT
                                CONCAT(p.`first_name`, \' \', p.`last_name`, \' \') AS `name`, p.`patient_uin`, c.`patient_id`, c.`patient_checkup_id`, DATE_FORMAT(c.`date`, \'%h:%i%p\') AS `time`, DATE_FORMAT(c.`date`, \'%Y-%m-%d\') AS `date`, c.`status`, c.`treatment_uin`
                         FROM
                                patient_checkup AS c
                         INNER JOIN patient_registration AS p ON c.`patient_id` = p.`patient_id`
                         WHERE (`status` =\'Pending\')
                         ORDER BY `date` DESC, `time` DESC;';
        $query = $this->db->query($query_string);
        return $query->result_array();
    }
    
    public function patient_checkup_archive($patient_id){
        $query_string = 'SELECT
                                p.`patient_id`
                              , p.`first_name`
                              , p.`last_name`
                              , p.`middle_initial`
                              , c.`patient_checkup_id`
                              , c.`patient_description`
                              , DATE_FORMAT(c.`date`, \'%Y-%m-%d\') AS `date`
                              , DATE_FORMAT(c.`date`, \'%h:%i %p\') AS `time`
                              , c.`status`
			      , c.`treatment_uin`
                          FROM
                              patient_registration AS p
                          INNER JOIN patient_checkup AS c 
                              ON (p.`patient_id` = c.`patient_id`)
                          WHERE (c.`patient_id` ='.$patient_id.')
                          ORDER BY `date` DESC, `status` ASC, `time` ASC;';
        $query = $this->db->query($query_string);
        return $query->result_array();
    }

    //Vaibhav Soni
    //18-11-2012
    public function scheduled_appointment()
    {
       $patient_id = $this->session->userdata('user_id');
       $this->db->select('s.*, concat(p.first_name, " ", p.last_name) as name, p.email',false);
       $this->db->from('schedule s');
       $this->db->join('patient_registration p', 'p.patient_id = s.patient_id', 'left'); // this joins the user table to topics
       $this->db->where('s.schedule_status !=','Canceled');
       $this->db->order_by("s.added_date", "desc"); 
       $query = $this->db->get();
       return $query->result_array();
    }
    
    /** REVIEW PATIENT TREATMENT PLAN (MODEL FUNCTION)
     * @param int $patient_id
     * @access public
     * @author Rohitashva Singh <rohitashvarathore@gmail.com>
     * @return none
     * 29-11-2012 3:03 AM
     */
    public function review_treatment_plan($patient_id){
        /**
         * UPDATE service_price
         * MODIFIED 16-12-2012 4:18 PM
         * @param int $patient_id
         * @return none
         * @author Rohitashva Singh <rohitashvarathore@gmail.com>
         */
        //foreach($_POST['treat_id'] AS $key=>$val):
        //    $this->db->set('ins_covered_per', $_POST['ins_covered_per'][$key]);
        //    $this->db->set('annual_deductible', $_POST['annual_deductible'][$key]);
        //    $this->db->set('patient_fee', $_POST['patient_fee'][$key]);
        //    $this->db->where('treat_id', $val);
        //    $this->db->update('service_price');
        //endforeach;
	    foreach($_POST['patient_checkup_relation_id'] AS $key=>$val):
            $this->db->set('ins_covered_per', $_POST['ins_covered_per'][$key]);
            $this->db->set('annual_deductible', $_POST['annual_deductible'][$key]);
            $this->db->set('t_price', $_POST['t_price'][$key]);
            $this->db->set('e_insurance_coverage', $_POST['e_insurance_coverage'][$key]);
            $this->db->set('patient_fee', $_POST['patient_fee'][$key]);
            $this->db->where('patient_checkup_relation_id', $val);
            $this->db->update('service_price');
        endforeach;
        /** --------------------- */
        
        /**
         * UPDATE patient_checkup
         */
            $string =  'SELECT SUM(a.`patient_fee`) AS `patient_grand_total`
                        FROM all_patient_treatments AS a
                        WHERE (a.`patient_id` = '.$patient_id.' AND a.`patient_checkup_id` = '.$_POST['patient_checkup_id'].');';
            $query = $this->db->query($string)->row_array();

            $this->db->set('status', 'Approved');
            $this->db->set('frontoffice_notes', nl2br($_POST['notes']));
            $this->db->set('treatment_time', $_POST['hourcombo'].':'.$_POST['mincombo']);
            if($query && @$query['patient_grand_total']>0.00)
                $this->db->set('paid_for', 'Y');
            $this->db->set('paid_for', 'Y');
            $this->db->where('patient_checkup_id', $_POST['patient_checkup_id']);
            $this->db->update('patient_checkup');

        /* ---------------------- */
        
        /**
         * UPDATE patient_registration
         */
            $this->db->select('p_total_insurance');
            $this->db->where('patient_id', $patient_id);
            $query = $this->db->get('patient_registration')->row_array();
            $p_total_insurance = $query['p_total_insurance']-$_POST['patint_ins_deduct'];
            $this->db->set('p_total_insurance', $p_total_insurance);
            $this->db->where('patient_id', $patient_id);
            $this->db->update('patient_registration');
        /* ------------------------- */
    }
    
    /**
    * FETCH PATIENT ID FROM SCHEDULE ID
    * @author  Rohitashva Singh <rohitashvarathore@gmail.com>
    * @param int $schedule_id
    */
    function reschedule_appointment_patient_id($schedule_id){
        $this->db->select('patient_id');
        $this->db->from('schedule');
        $this->db->where('schedule_id', $schedule_id);
        $query = $this->db->get()->row_array();
        return $query;
    }
}

/* End of file frontoffice_model.php */
/* Location: ./application/models/frontoffice_model.php */