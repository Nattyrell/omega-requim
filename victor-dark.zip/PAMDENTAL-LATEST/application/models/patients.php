<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

/**
 * PAM DENTAL - Patients Model
 * @author Rohitashva Singh
 */
class Patients extends CI_Model{
    
    public $is_patient_registered = array();    
    public function __construct() {
        parent::__construct();
        if($this->session->userdata('user_type') == 'patient'){
	        /** CORRECTION REQUIRED */
            $this->db->select('is_registered, first_name, last_name, middle_initial, email');
            $this->db->where('patient_login_id', $this->session->userdata('login_id'));
            $query = $this->db->get('patient_login');
            $this->is_patient_registered = $query->row_array();
	        /* ---------------------*/
	        $is_primary = $this->db->select('is_primary')->from('patient_registration')->where('patient_id', $this->session->userdata('patient_id'))->get()->row_array();
	        $this->is_patient_registered['is_primary'] = @$is_primary['is_primary'];
            return $this->is_patient_registered;
        }
    }
    
    /**
     * MODIFIED 21-11-2012 4:39 PM
     * @author Rohitashva Singh <rohitashvarathore@gmail.com>
     */
    public function new_patient_signup(){
        $new_patient_data = array();
        $this->db->set('first_name', @$_POST['first-name']);
        $this->db->set('last_name', @$_POST['last-name']);
        $this->db->set('middle_initial', @$_POST['middle-initial']);
        $this->db->set('email', @$_POST['email']);
        $this->db->set('username', @$_POST['username']);
        $this->db->set('password', md5(@$_POST['password']));
        $this->db->set('sign_up_date', date('Y-m-d H:i:s'));
        $this->db->set('last_login', date('Y-m-d H:i:s'));
        $this->db->insert('patient_login');
        
        $new_patient_data['patient_login_id'] = $this->db->insert_id();
        $new_patient_data['name'] = @$_POST['first-name'].' '.@$_POST['last-name'];
        return $new_patient_data;
    }
    
    public function patient_login()
    {
        $this->db->select('patient_login_id, first_name, last_name, username, password, is_registered');
        $this->db->where('username', @$_POST['username']);
        $this->db->where('password', md5(@$_POST['password']));
        $query = $this->db->get('patient_login');
        return $query->row();
    }
	
    public function patient_login_part_2()
    {
       $this->db->select('p.first_name, p.last_name,p.patient_id, p.patient_login_id,p.is_primary');
       $this->db->from('patient_registration p');
       $this->db->where('p.patient_uin', (@$_POST['p_uin']));
       $this->db->where('pl.username', (@$this->session->userdata('username')));
       $this->db->where('pl.password', md5(@$this->session->userdata('password')));
       $this->db->join('patient_login pl', 'p.patient_login_id = pl.patient_login_id', 'left'); // this joins the user table to topics
	   
       // $this->db->select('patient_login_id, patient_id, first_name, last_name');
       // $this->db->where('patient_uin', (@$_POST['p_uin']));
       $query = $this->db->get();
       return $query->row();
    }
    
    public function update_last_login($id){
        $this->db->set('last_login', date('Y-m-d H:i:s'));
        $this->db->where('patient_login_id', $id);
        $this->db->update('patient_login');
    }
    
    public function patient_log($patient_id, $activity){
        $this->db->set('patient_id', $patient_id);
        $this->db->set('datetime', date('Y-m-d H:i:s'));
        $this->db->set('ip_address', $_SERVER['REMOTE_ADDR']);
        $this->db->set('http_user_agent', $_SERVER['HTTP_USER_AGENT']);
        $this->db->set('activity', $activity);
        $this->db->insert('patient_log');
    }
    
    public function patient_status(){
        //$query = $this->db->get('patient_status');
        //return $query;
        $patient_status = array(
            1 => 'Married',
            2 => 'Single',
            3 => 'Child',
            4 => 'Other'
        );
        return $patient_status;
    }
    
    public function us_states(){
        $this->db->select('id, state, state_abbr');
        $query = $this->db->get('us_states');
        return $query;
    }
    
    public function patient_relationship_insured(){
        $patient_relationship_insured = array(
                                            1 => 'Self',
                                            2 => 'Spouse',
                                            3 => 'Child',
                                            4 => 'Other'
                                        );
        return $patient_relationship_insured;
    }
    
    public function patient_health_conditions(){
        $query = $this->db->get('health_conditions');
        return $query;
    }
    
    public function patient_other_medicines_or_neutricuticals(){
        $query = $this->db->get('other_medicines_or_neutricuticals');
        return $query;
    }
    
    //PATIENT REGISTRATION
    public function insert_patient_registration_data(){
		//@Patient Information
        $this->db->set('patient_login_id', $this->session->userdata('login_id'));
        $this->db->set('registration_date', date('Y-m-d H:i:s'));
	    $this->db->set('first_name', @$_POST['first-name']);
        $this->db->set('last_name', @$_POST['last-name']);
        $this->db->set('middle_initial', @$_POST['middle-initial']);
        $this->db->set('email', @$_POST['email']);
        $this->db->set('p_sex', @$_POST['sex']);
        $this->db->set('p_marital_status', @$_POST['status']);
        $this->db->set('p_marital_status_other', @$_POST['martial-status-other']);
        $this->db->set('p_ssn', @$_POST['ssn']);
        $this->db->set('p_dln', @$_POST['dln']);
        $this->db->set('p_dob', @$_POST['dob']);
        $this->db->set('p_address_street', @$_POST['street']);
        $this->db->set('p_address_apartment_number', @$_POST['apartment-number']);
        $this->db->set('p_address_city', @$_POST['city']);
        $this->db->set('p_address_state_id', @$_POST['state']);
        $this->db->set('p_address_zipcode', @$_POST['p_zip']);
        $this->db->set('p_phone_home', @$_POST['phone-home']);
        $this->db->set('p_phone_work', @$_POST['phone-work']);
        $this->db->set('p_phone_cell', @$_POST['phone-cell']);
        $this->db->set('p_practice_reference', @$_POST['practice-reference']);
        
                //@Health Condition
        $this->db->set('p_health_condition', serialize(@$_POST['patient-health-condition']));
        
                //@Other Medicines or Neutricuticals
        $this->db->set('p_other_medicines', serialize(@$_POST['patient_other_medicines_or_neutricuticals']));
        
                //@Spouse or Responsible Party Information
        $this->db->set('srp_following_is_for', @$_POST['srp-following-is-for']);
        $this->db->set('srp_first_name', @$_POST['srp-first-name']);
        $this->db->set('srp_last_name', @$_POST['srp-last-name']);
        $this->db->set('srp_middle_initial', @$_POST['srp-middle-initial']);
        $this->db->set('srp_sex', @$_POST['srp-sex']);
        $this->db->set('srp_marital_status', @$_POST['srp-status']);
        $this->db->set('srp_marital_status_other', @$_POST['srp-martial-status-other']);
        $this->db->set('srp_ssn', @$_POST['srp-ssn']);
        $this->db->set('srp_dob', @$_POST['srp-dob']);
        $this->db->set('srp_phone_home', @$_POST['srp-phone-home']);
        $this->db->set('srp_phone_work', @$_POST['srp-phone-work']);
        $this->db->set('srp_phone_ext', @$_POST['srp-phone-ext']);
        $this->db->set('srp_best_time_call', @$_POST['srp-best-time-call']);
        $this->db->set('srp_address_street', @$_POST['srp-street']);
        $this->db->set('srp_address_apartment_number', @$_POST['srp-apartment-number']);
        $this->db->set('srp_address_city', @$_POST['srp-city']);
        $this->db->set('srp_address_state_id', @$_POST['srp-state']);
        $this->db->set('srp_address_zipcode', @$_POST['srp_zip']);
        
                //@Employment Information
        $this->db->set('e_name', @$_POST['e-name']);
        $this->db->set('e_occupation', @$_POST['e-occupation']);
        $this->db->set('e_address_street', @$_POST['e-street']);
        $this->db->set('e_address_city', @$_POST['e-city']);
        $this->db->set('e_address_state_id', @$_POST['e-state']);
        $this->db->set('e_address_zipcode', @$_POST['e_zip']);
        
                //@Insurance Information - Primary Insurance
        $this->db->set('pi_first_name', @$_POST['pi-first-name']);
        $this->db->set('pi_last_name', @$_POST['pi-last-name']);
        $this->db->set('pi_middle_initial', @$_POST['pi-middle-initial']);
        $this->db->set('pi_is_insured_patient', @$_POST['pi-is-insured-patient']);
        $this->db->set('pi_dob', @$_POST['pi-dob']);
        $this->db->set('pi_id', @$_POST['pi-id']);
        $this->db->set('pi_group', @$_POST['pi-group']);
        $this->db->set('pi_address_street', @$_POST['pi-street']);
        $this->db->set('pi_address_city', @$_POST['pi-city']);
        $this->db->set('pi_address_state_id', @$_POST['pi-state']);
        $this->db->set('pi_address_zipcode', @$_POST['pi-zip']);
        $this->db->set('pi_emp_name', @$_POST['pi-emp-name']);
        $this->db->set('pi_emp_address_street', @$_POST['pi-emp-street']);
        $this->db->set('pi_emp_address_city', @$_POST['pi-emp-city']);
        $this->db->set('pi_emp_address_state_id', @$_POST['pi-emp-state']);
        $this->db->set('pi_emp_address_zipcode', @$_POST['pi_emp_zipcode']);
        $this->db->set('pi_patient_relation', @$_POST['pi-patient-relation']);
        $this->db->set('pi_patient_relation_other', @$_POST['pi-patient-relation-other']);
        $this->db->set('pi_insurance_plan_address', @$_POST['pi-insurance-plan-address']);
        
                //@Insurance Information - Secondary Insurance
        $this->db->set('si_first_name', @$_POST['si-first-name']);
        $this->db->set('si_last_name', @$_POST['si-last-name']);
        $this->db->set('si_middle_initial', @$_POST['si-middle-initial']);
        $this->db->set('si_is_insured_patient', @$_POST['si-is-insured-patient']);
        $this->db->set('si_dob', @$_POST['si-dob']);
        $this->db->set('si_id', @$_POST['si-id']);
        $this->db->set('si_group', @$_POST['si-group']);
        $this->db->set('si_address_street', @$_POST['si-street']);
        $this->db->set('si_address_city', @$_POST['si-city']);
        $this->db->set('si_address_state_id', @$_POST['si-state']);
        $this->db->set('si_address_zipcode', @$_POST['si_zip']);
        $this->db->set('si_emp_name', @$_POST['si-emp-name']);
        $this->db->set('si_emp_address_street', @$_POST['si-emp-street']);
        $this->db->set('si_emp_address_city', @$_POST['si-emp-city']);
        $this->db->set('si_emp_address_state_id', @$_POST['si-emp-state']);
        $this->db->set('si_emp_address_zipcode', @$_POST['si_emp_zip']);
        $this->db->set('si_patient_relation', @$_POST['si-patient-relation']);
        $this->db->set('si_patient_relation_other', @$_POST['si-patient-relation-other']);
        $this->db->set('si_insurance_plan_address', @$_POST['si-insurance-plan-address']);
        
                //@Physicians /Health Professionals, Names & Phone Numbers
        $this->db->set('physician_health_prof_name_1', @$_POST['physician-health-prof-name-1']);
        $this->db->set('physician_health_prof_name_2', @$_POST['physician-health-prof-name-2']);
        $this->db->set('physician_health_prof_name_3', @$_POST['physician-health-prof-name-3']);
        $this->db->set('physician_health_prof_name_4', @$_POST['physician-health-prof-name-4']);
        $this->db->set('physician_health_prof_phone_1', @$_POST['physician-health-prof-phone-1']);
        $this->db->set('physician_health_prof_phone_2', @$_POST['physician-health-prof-phone-2']);
        $this->db->set('physician_health_prof_phone_3', @$_POST['physician-health-prof-phone-3']);
        $this->db->set('physician_health_prof_phone_4', @$_POST['physician-health-prof-phone-4']);
        
                //@PMedications & Dosages You Are Currently Taking
        $this->db->set('med_dosage_1', @$_POST['med-dosage-1']);
        $this->db->set('med_dosage_2', @$_POST['med-dosage-2']);
        $this->db->set('med_dosage_3', @$_POST['med-dosage-3']);
        $this->db->set('med_dosage_4', @$_POST['med-dosage-4']);
        $this->db->set('med_dosage_5', @$_POST['med-dosage-5']);
        $this->db->set('med_dosage_6', @$_POST['med-dosage-6']);
        
        $this->db->insert('patient_registration'); // INSERT ROW INTO `patient_registration`
        $id = $this->db->insert_id();
        /** UNIQUE PATIENT IDENTIFICATION NUMBER
         * @author Rohitashva Singh <rohitashvarathore@gmail.com>
         * 21-11-2012 2:21 PM
         */
        $patient_uin = 'P'.sprintf('%04d', $id);
        $this->db->set('patient_uin', $patient_uin);
	    if(@$this->is_patient_registered['is_registered']=='N')
		    $this->db->set('is_primary', 'Y');
        $this->db->where('patient_id', $id);
        $this->db->update('patient_registration');
 
         /**----------------------------------------------------------- */
        //UPDATE 'patient_login' TABLE with `is_registered` = 'Y'
        if(@$this->is_patient_registered['is_registered']=='N')
        {
            $this->db->set('is_registered', 'Y');
            $this->db->where('patient_login_id', $this->session->userdata('login_id'));
            $this->db->update('patient_login');
        }
        
        /**
         * ADDED 29-11-2012 12:44 PM [return $id]
         * @author Rohitashva Singh <rohitashvarathore@gmail.com>
         */
		 $this->send_sign_up_email($patient_uin, $_POST);
         return $id;
        /* ------------------------------------------------------- */
    }
    
    /**
     * @author Rohitashva Singh
     * Modified 30-11-2012 7:31 PM
     * @param int $patient_id
     */
    public function patient_info($patient_id){
        //$query = $this->db->get_where('patient_data', array('patient_id' => $patient_id));
        //$string = 'SELECT p.*, CONCAT(p.`first_name`, \' \', p.`last_name`, \' \') AS `name`
        //          FROM patient_data AS p
        //          WHERE `patient_id` = '.$patient_id.';';
        $string = 'SELECT CONCAT(p.`first_name`, \' \', p.`last_name`, \' \') AS `name`, p.`patient_uin`, p.`p_address_street`, p.`p_address_apartment_number`, p_address_city, p_address_state_id, p_address_zipcode, p.`p_total_insurance`, l.`username`
                   FROM patient_registration AS p
                   INNER JOIN patient_login AS l ON (p.`patient_login_id` = l.`patient_login_id`)
                           WHERE `patient_id` = '.$patient_id.';';
        $query = $this->db->query($string);
        return $query;
    }
    
    public function forgot_password(){
        //$this->db->select('username, first_name, email');
        //$this->db->where('username', @$_POST['username']);
        //$query = $this->db->get('patient_login')->row_array();
        
        $string = "SELECT l.`username`, r.`email`, r.`first_name`, r.`patient_uin`
                   FROM patient_registration AS r
                   INNER JOIN patient_login AS l ON (r.`patient_login_id` = l.`patient_login_id`)  
                   WHERE (r.`is_primary` = 'Y' AND l.`username` = '".@$_POST['username']."');";
        $query = $this->db->query($string)->row_array();           
        
        if($query){
            $new_password = $this->_generateRandomString();
            $this->db->set('password', md5($new_password));
            $this->db->where('username', @$_POST['username']);
            $this->db->update('patient_login');
            $query['password'] = $new_password;
            return $query;
        }
        else return FALSE;
    }
    
    private function _generateRandomString($length = 10){
    	$characters = '0123456789abcdefghijklmnopqrstuvwxyz_ABCDEFGHIJKLMNOPQRSTUVWXYZ';
    	$randomString = '';
        for ($i = 0; $i < $length; $i++) {
        $randomString .= $characters[rand(0, strlen($characters) - 1)];
    	}
    	return $randomString;
    }
	
    public function get_appointment()
    {
       $this->db->select('s.*, concat(p.first_name, " ", p.last_name) as patient_name ');
       $this->db->from('schedule s');
       $this->db->join('patient_registration p', 'p.patient_id = s.patient_id', 'left'); // this joins the user table to topics
       $query = $this->db->get();
       echo $this->db->last_query();
       foreach($query->result_array() as $row):
            $data[] = $row;
       endforeach;
       print_r($data);
       exit;
    }
    
    /**
     * MODIFIED 2-12-2012 6:54 AM
     * @param int $id:: PATIENT ID <SECONDARY P> OR PATIENT LOGIN ID <PRIMARY P>
     * @param int $flag 0 OR 1
     * @return type array
     */
    public function current_checkups($id, $flag){
	switch ($flag){
	    case 0:
            $query_string = 'SELECT
                                l.`patient_login_id`
                                  , r.`patient_id`
                                  , r.`is_primary`
                                  , c.`patient_checkup_id`
                                  , DATE_FORMAT(c.`date`, \'%h:%i %p\') AS `time`
                                  , DATE_FORMAT(c.`date`, \'%Y-%m-%d\') AS `date`
                                  , CONCAT(r.`first_name`, \' \', r.`last_name`, \' \') AS `name`
                                  , r.`patient_uin`
                                  , c.`treatment_cons`
                                  , c.`treatment_pros`
                                  , c.`status`
                                  , c.`paid_for`
                                  , c.`treatment_uin`
                              FROM
                                  patient_login AS l
                                  INNER JOIN patient_registration AS r
                                  ON (l.`patient_login_id` = r.`patient_login_id`)
                                  INNER JOIN patient_checkup AS c
                                  ON (r.`patient_id` = c.`patient_id`)
                              WHERE (l.`patient_login_id` = '.$id.' AND c.`status` = \'Approved\' AND (`paid_for` = \'N\' OR `appointment_taken` = \'N\'))
                              ORDER BY `date` DESC, `time` DESC;';
            break;
	    case 1:
            $query_string = 'SELECT
                                l.`patient_login_id`
                                  , r.`patient_id`
                                  , r.`is_primary`
                                  , c.`patient_checkup_id`
                                  , DATE_FORMAT(c.`date`, \'%h:%i %p\') AS `time`
                                  , DATE_FORMAT(c.`date`, \'%Y-%m-%d\') AS `date`
                                  , CONCAT(r.`first_name`, \' \', r.`last_name`, \' \') AS `name`
                                  , r.`patient_uin`
                                  , c.`treatment_cons`
                                  , c.`treatment_pros`
                                  , c.`status`
                                  , c.`paid_for`
                                  , c.`treatment_uin`
                              FROM
                                  patient_login AS l
                                  INNER JOIN patient_registration AS r
                                  ON (l.`patient_login_id` = r.`patient_login_id`)
                                  INNER JOIN patient_checkup AS c
                                  ON (r.`patient_id` = c.`patient_id`)
                              WHERE (r.`patient_id` = '.$id.'  AND c.`status` = \'Approved\' AND (`paid_for` = \'N\' OR `appointment_taken` = \'N\'))
                              ORDER BY `date` DESC, `time` DESC;';
            break;
	}
	$query = $this->db->query($query_string);
	return $query->result_array();
    }
    
    /**
     * MODIFIED 16-12-2012 4:03 PM
     * @param int $patient_id
     * @param int $patient_checkup_id
     * @return type array
     */
    public function get_checkup($patient_id, $patient_checkup_id){
        $query_string = 'SELECT
                            `tooth_desc`
                            , `ada_code`
                            , `ada_code_desc`
                            , `treat_id`
                            , `recommended_treatment_desc`
                            , `price`
                            , `insurance`
                            , `t_price`
                            , `e_insurance_coverage`
                            , `ins_covered_per`
                            , `annual_deductible`
                            , `patient_fee`
                            , `patient_checkup_relation_id`
                         FROM
                            all_patient_treatments
                         WHERE (`patient_id` = '.$patient_id.'
                            AND `patient_checkup_id` = '.$patient_checkup_id.')
                         GROUP BY `treat_id`;'; // 29-11-2012 1:08 AM NECESSARY, OTHERWISE CERTAIN ROWS WILL DUPLICATE
        $query = $this->db->query($query_string);
        return $query->result_array();
    }
    /** ------------------------------- */
    
    /**
     * MODIFIED 29-11-2012 3:25 PM
     * @param int $patient_id
     * @param int $patient_checkup_id
     * @return type array
     */
    public function get_checkup_price($patient_id, $patient_checkup_id){
//        $query_string = 'SELECT SUM(a.`price`) AS `total_price`, SUM(a.`insurance`) AS `total_insurance`, SUM(a.`deductable`) AS `total_deductible`, SUM(`price` - `insurance` - `deductable`) AS `total`
//                         FROM
//                            all_patient_treatments AS a
//                         WHERE (`patient_id` = '.$patient_id.'
//                         AND `patient_checkup_id` = '.$patient_checkup_id.');';
//        $query_string = 'SELECT SUM(a.`patient_fee`) AS `patient_grand_total`
//                            FROM
//                               all_patient_treatments AS a
//                            WHERE (`patient_id` = '.$patient_id.'
//                            AND `patient_checkup_id` = '.$patient_checkup_id.');';
        $query_string = 'SELECT
                            a.`treat_id`
                            , a.`patient_fee` AS `patient_grand_total`
                        FROM all_patient_treatments AS a
                        WHERE (`patient_id` = '.$patient_id.' AND `patient_checkup_id` = '.$patient_checkup_id.')
                        GROUP BY a.`treat_id`;';
        $query = $this->db->query($query_string)->result_array();
        $patient_grand_total = array();
        $temp = 0.00;
        if($query){
            foreach($query AS $row):
                $temp+=$row['patient_grand_total'];
            endforeach;
            $patient_grand_total['patient_grand_total'] = $temp; 
            return $patient_grand_total;
        }
        else return FALSE;
    }
    /** ------------------------------- */
    
    /** 
     * MODIFIED 8-12-2012 2:01 AM
     * @author Rohitashva Singh <rohitashvarathore@gmail.com>
     * @param int $patient_id
     * @param int $patient_checkup_id
     * @return type array
     */
    public function get_checkup_detail($patient_id, $patient_checkup_id){
        $query_string = 'SELECT
                                a.`patient_checkup_id`, a.`notes`, a.`patient_description`, a.treatment_pros, a.treatment_cons, DATE_FORMAT(`treatment_time`, \'%H:%i\') AS `treatment_time`, a.`status`, DATE_FORMAT(a.`date`, \'%M %d %Y\') AS `date`, DATE_FORMAT(a.`date`, \'%h:%i %p\') AS `time`, a.`frontoffice_notes`, a.`treatment_uin`, a.`paid_for`, a.`appointment_taken`
                         FROM
                            patient_checkup AS a
                         INNER JOIN patient_registration AS b
                                ON (a.`patient_id` = b.`patient_id`)
                         WHERE (b.`patient_id` = '.$patient_id.'
                                AND a.`patient_checkup_id` = '.$patient_checkup_id.');';
        $query = $this->db->query($query_string);
        return $query->row_array();
    }
    /** ----------------------------------------------------------- */
	
    //02/11/2012
    //vaibhav
    public function patient_details($patient_id)
    {
       
        $sql =  'SELECT pl.*, p.*,  DATE_FORMAT(p.`registration_date`, \'%Y-%m-%d, %h:%i%p\') AS `registration_date`
                FROM patient_registration as p
                LEFT JOIN patient_login as pl
                ON p.patient_login_id = pl.patient_login_id 
                WHERE (p.patient_id = '.$patient_id.')';
        $record = $this->db->query($sql);
        return $record->row_array();
    }
	
    public function select_health_con($str){
        $this->db->select('description');
        $this->db->where_in('health_con_id', $str);
        $query = $this->db->get('health_conditions');;
        return $query->result_array();
    }
	
    public function select_other_medicines($str){
        $this->db->select('description');
        $this->db->where_in('other_medicine_id', $str);
        $query = $this->db->get('other_medicines_or_neutricuticals');;
        return $query->result_array();
    }
    
    /** *
     * @author Rohitashva Singh <rohitashvarathore@gmail.com>
     * @param int $patient_id
     * @param int $patient_checkup_id
     * @return array
     * MODIFIED 16-12-2012 4:39 PM
     */
    public function get_checkup_for_pay($patient_id, $patient_checkup_id){
        $query_string = 'SELECT
                                c.`patient_checkup_id`
                              , t.`description` AS `tooth_des`
                              , ada.`ada_code_id`
                              , ada.`description` AS `ada_code_desc`
                              , cr.`treat_id` AS `rec_treatment_id`
                              , tos.`price` AS `treatment_price`
                              , tos.`treatment_insurance`
                              , s.`ins_covered_per`
                              , s.`annual_deductible`
                              , s.`patient_fee`
                              , s.`t_price`
                              , s.`e_insurance_coverage`
                              , tos.`treatment_deductable`
                              , tos.`pros` AS `treatment_pros`
                              , tos.`cons` AS `treatment_cons`
                              , tos.`description` AS `treatment_description`
                          FROM patient_registration AS p
                              INNER JOIN patient_checkup AS c ON (p.`patient_id` = c.`patient_id`)
                              INNER JOIN patient_checkup_relation AS cr ON (c.`patient_checkup_id` = cr.`patient_checkup_id`)
                              INNER JOIN teeth AS t ON (cr.`tooth_id` = t.`tooth_id`)
                              INNER JOIN ada_codes AS ada ON (cr.`ada_code_id` = ada.`ada_code_id`)
                              INNER JOIN treatment_options AS tos ON (cr.`treat_id` = tos.`treat_id`)
                              INNER JOIN service_price AS s ON (cr.`id` = s.`patient_checkup_relation_id`)
                          WHERE (p.`patient_id` ='.$patient_id.' AND c.`patient_checkup_id` ='.$patient_checkup_id.')
                          ORDER BY `treatment_price` ASC;';
        $query = $this->db->query($query_string);
        return $query->result_array();
    }
    
    /** *
     * @author Rohitashva Singh <rohitashvarathore@gmail.com>
     * @param int $ada_code_id
     * 7 November 2012
     */
    public function get_treatment_option_values($ada_code_id){
        $this->db->select('treatment_options.treat_id, treatment_options.description');
        $this->db->from('treatment_options');
        $this->db->where('ada_code_treatment_options.ada_code_id', $ada_code_id);
        $this->db->join('ada_code_treatment_options', 'ada_code_treatment_options.treat_id = treatment_options.treat_id');
        $query = $this->db->get();
        return $query->result_array();
    }
	
     /** *
     * @author Vaibhav Soni
     * 6 November 2012
     */
    public function update_patient_registration_data()
    {
         /** UPDATE `email` in patient_login TABLE--------------------
         * @author Rohitashva Singh <rohitashvarathore@gmail.com>
         * 14-11-2012 8:25PM
         */
        $this->db->set('first_name', @$_POST['first-name']);
        $this->db->set('last_name', @$_POST['last-name']);
        $this->db->set('middle_initial', @$_POST['middle-initial']);
        $this->db->set('email', @$_POST['email']);
        $this->db->set('p_sex', @$_POST['sex']);
        $this->db->set('p_marital_status', @$_POST['status']);
        $this->db->set('p_marital_status_other', @$_POST['martial-status-other']);
        $this->db->set('p_ssn', @$_POST['ssn']);
        $this->db->set('p_dln', @$_POST['dln']);
        $this->db->set('p_dob', @$_POST['dob']);
        $this->db->set('p_address_street', @$_POST['street']);
        $this->db->set('p_address_apartment_number', @$_POST['apartment-number']);
        $this->db->set('p_address_city', @$_POST['city']);
        $this->db->set('p_address_state_id', @$_POST['state']);
        $this->db->set('p_address_zipcode', @$_POST['p_zip']);
        $this->db->set('p_phone_home', @$_POST['phone-home']);
        $this->db->set('p_phone_work', @$_POST['phone-work']);
        $this->db->set('p_phone_cell', @$_POST['phone-cell']);
        $this->db->set('p_practice_reference', @$_POST['practice-reference']);

        //@Health Condition
        $this->db->set('p_health_condition', serialize(@$_POST['patient-health-condition']));

        //@Other Medicines or Neutricuticals
        $this->db->set('p_other_medicines', serialize(@$_POST['patient_other_medicines_or_neutricuticals']));

        //@Spouse or Responsible Party Information
        $this->db->set('srp_following_is_for', @$_POST['srp-following-is-for']);
        $this->db->set('srp_first_name', @$_POST['srp-first-name']);
        $this->db->set('srp_last_name', @$_POST['srp-last-name']);
        $this->db->set('srp_middle_initial', @$_POST['srp-middle-initial']);
        $this->db->set('srp_sex', @$_POST['srp-sex']);
        $this->db->set('srp_marital_status', @$_POST['srp-status']);
        $this->db->set('srp_marital_status_other', @$_POST['srp-martial-status-other']);
        $this->db->set('srp_ssn', @$_POST['srp-ssn']);
        $this->db->set('srp_dob', @$_POST['srp-dob']);
        $this->db->set('srp_phone_home', @$_POST['srp-phone-home']);
        $this->db->set('srp_phone_work', @$_POST['srp-phone-work']);
        $this->db->set('srp_phone_ext', @$_POST['srp-phone-ext']);
        $this->db->set('srp_best_time_call', @$_POST['srp-best-time-call']);
        $this->db->set('srp_address_street', @$_POST['srp-street']);
        $this->db->set('srp_address_apartment_number', @$_POST['srp-apartment-number']);
        $this->db->set('srp_address_city', @$_POST['srp-city']);
        $this->db->set('srp_address_state_id', @$_POST['srp-state']);
        $this->db->set('srp_address_zipcode', @$_POST['srp_zip']);

         //@Employment Information
        $this->db->set('e_name', @$_POST['e-name']);
        $this->db->set('e_occupation', @$_POST['e-occupation']);
        $this->db->set('e_address_street', @$_POST['e-street']);
        $this->db->set('e_address_city', @$_POST['e-city']);
        $this->db->set('e_address_state_id', @$_POST['e-state']);
        $this->db->set('e_address_zipcode', @$_POST['e_zip']);

        //@Insurance Information - Primary Insurance
        $this->db->set('pi_first_name', @$_POST['pi-first-name']);
        $this->db->set('pi_last_name', @$_POST['pi-last-name']);
        $this->db->set('pi_middle_initial', @$_POST['pi-middle-initial']);
        $this->db->set('pi_is_insured_patient', @$_POST['pi-is-insured-patient']);
        $this->db->set('pi_dob', @$_POST['pi-dob']);
        $this->db->set('pi_id', @$_POST['pi-id']);
        $this->db->set('pi_group', @$_POST['pi-group']);
        $this->db->set('pi_address_street', @$_POST['pi-street']);
        $this->db->set('pi_address_city', @$_POST['pi-city']);
        $this->db->set('pi_address_state_id', @$_POST['pi-state']);
        $this->db->set('pi_address_zipcode', @$_POST['pi_zip']);
        $this->db->set('pi_emp_name', @$_POST['pi-emp-name']);
        $this->db->set('pi_emp_address_street', @$_POST['pi-emp-street']);
        $this->db->set('pi_emp_address_city', @$_POST['pi-emp-city']);
        $this->db->set('pi_emp_address_state_id', @$_POST['pi-emp-state']);
        $this->db->set('pi_emp_address_zipcode', @$_POST['pi_emp_zip']);
        $this->db->set('pi_patient_relation', @$_POST['pi-patient-relation']);
        $this->db->set('pi_patient_relation_other', @$_POST['pi-patient-relation-other']);
        $this->db->set('pi_insurance_plan_address', @$_POST['pi-insurance-plan-address']);

        //@Insurance Information - Secondary Insurance
        $this->db->set('si_first_name', @$_POST['si-first-name']);
        $this->db->set('si_last_name', @$_POST['si-last-name']);
        $this->db->set('si_middle_initial', @$_POST['si-middle-initial']);
        $this->db->set('si_is_insured_patient', @$_POST['si-is-insured-patient']);
        $this->db->set('si_dob', @$_POST['si-dob']);
        $this->db->set('si_id', @$_POST['si-id']);
        $this->db->set('si_group', @$_POST['si-group']);
        $this->db->set('si_address_street', @$_POST['si-street']);
        $this->db->set('si_address_city', @$_POST['si-city']);
        $this->db->set('si_address_state_id', @$_POST['si-state']);
        $this->db->set('si_address_zipcode', @$_POST['si_zip']);
        $this->db->set('si_emp_name', @$_POST['si-emp-name']);
        $this->db->set('si_emp_address_street', @$_POST['si-emp-street']);
        $this->db->set('si_emp_address_city', @$_POST['si-emp-city']);
        $this->db->set('si_emp_address_state_id', @$_POST['si-emp-state']);
        $this->db->set('si_emp_address_zipcode', @$_POST['si_emp_zie']);
        $this->db->set('si_patient_relation', @$_POST['si-patient-relation']);
        $this->db->set('si_patient_relation_other', @$_POST['si-patient-relation-other']);
        $this->db->set('si_insurance_plan_address', @$_POST['si-insurance-plan-address']);

        //@Physicians /Health Professionals, Names & Phone Numbers
        $this->db->set('physician_health_prof_name_1', @$_POST['physician-health-prof-name-1']);
        $this->db->set('physician_health_prof_name_2', @$_POST['physician-health-prof-name-2']);
        $this->db->set('physician_health_prof_name_3', @$_POST['physician-health-prof-name-3']);
        $this->db->set('physician_health_prof_name_4', @$_POST['physician-health-prof-name-4']);
        $this->db->set('physician_health_prof_phone_1', @$_POST['physician-health-prof-phone-1']);
        $this->db->set('physician_health_prof_phone_2', @$_POST['physician-health-prof-phone-2']);
        $this->db->set('physician_health_prof_phone_3', @$_POST['physician-health-prof-phone-3']);
        $this->db->set('physician_health_prof_phone_4', @$_POST['physician-health-prof-phone-4']);

        //@PMedications & Dosages You Are Currently Taking
        $this->db->set('med_dosage_1', @$_POST['med-dosage-1']);
        $this->db->set('med_dosage_2', @$_POST['med-dosage-2']);
        $this->db->set('med_dosage_3', @$_POST['med-dosage-3']);
        $this->db->set('med_dosage_4', @$_POST['med-dosage-4']);
        $this->db->set('med_dosage_5', @$_POST['med-dosage-5']);
        $this->db->set('med_dosage_6', @$_POST['med-dosage-6']);

        $this->db->where('patient_id', @$this->session->userdata('patient_id'));
            $this->db->update('patient_registration'); // INSERT ROW INTO `patient_registration`
    }
	
    /** MODIFIED 10-12-2012
     * @author Rohitashva Singh <rohitashvarathore@gmail.com>
     * @param int $transcation
     * @param int $patient_id
     */
    public function insert_billing_details($transcation, $patient_id)
    {
        $treatment = explode(',',@$_POST['treat_ids']);
        /** MODIFIED 10-12-2012 by Rohitashva Singh */
            //$this->db->set('patient_id', $this->session->userdata('patient_id'));
            $this->db->set('patient_id', $patient_id);
        /** --------------------------------------- */
        $this->db->set('patient_checkup_id', $_POST['patient_checkup_id']);
        $this->db->set('treat_ids', serialize(@$treatment));
        $this->db->set('total_amount_paid', $_POST['amount']);
        $this->db->set('billing_date', date('Y-m-d H:i:s'));
        $this->db->set('transaction_id', $transcation['TRANSACTIONID']);
        $this->db->insert('billing');

        $this->db->set('paid_for', 'Y');
        $this->db->where('patient_checkup_id', $_POST['patient_checkup_id']);
        $this->db->update('patient_checkup');
    }
	
    /** PATIENT SCHEDULED APPOINTMENTS
     * @author Vaibhav Soni
     * @param int $id
     * @param int $flag
     * MODIFIED 9-12-2012 4:24 PM by- Rohitashva Singh <rohitashvarathore@gmail.com>
     */
    public function scheduled_appointment($id, $flag)
    {
	    switch ($flag){
	        case 0:
		        //$string = 'SELECT
		        //		    r.`patient_id`, r.`patient_login_id`, r.`patient_uin`, CONCAT(r.`first_name`, \' \', r.`last_name`, \' \') AS `name`, s.`schedule_status`, s.`start_time`, s.`end_time`, DATE_FORMAT(s.`visit_date`, \'%d %M %Y\') AS `date`, s.`schedule_status`, s.`visit_type`
		        //	   FROM
		        //	      schedule AS s
		        //	   INNER JOIN patient_registration AS r 
		        //		  ON (s.`patient_id` = r.`patient_id`)
		        //	   WHERE (r.`patient_login_id` ='.$id.' AND s.`schedule_status` !=\'Pending\')
		        //	   ORDER BY `date` ASC;';
		        $string = 'SELECT
				            r.`patient_id`, r.`patient_login_id`, r.`patient_uin`, CONCAT(r.`first_name`, \' \', r.`last_name`, \' \') AS `name`, s.`schedule_status`, s.`start_time`, s.`end_time`, DATE_FORMAT(s.`visit_date`, \'%d %M %Y\') AS `date`, s.`schedule_status`, s.`visit_type`
			           FROM
			              schedule AS s
			           INNER JOIN patient_registration AS r 
				          ON (s.`patient_id` = r.`patient_id`)
			           WHERE (r.`patient_login_id` ='.$id.' AND s.`schedule_status` !=\'Canceled\')
			           ORDER BY `date` ASC;';
		        break;
	        case 1:
		        //$string = 'SELECT
		        //		    r.`patient_id`, r.`patient_login_id`, r.`patient_uin`, CONCAT(r.`first_name`, \' \', r.`last_name`, \' \') AS `name`, s.`schedule_status`, s.`start_time`, s.`end_time`, DATE_FORMAT(s.`visit_date`, \'%d %M %Y\') AS `date`, s.`schedule_status`, s.`visit_type`
		        //	   FROM
		        //	      schedule AS s
		        //	   INNER JOIN patient_registration AS r 
		        //		  ON (s.`patient_id` = r.`patient_id`)
		        //	   WHERE (r.`patient_id` ='.$id.' AND s.`schedule_status` !=\'Pending\')
		        //	   ORDER BY `date` ASC;';
		        $string = 'SELECT
				            r.`patient_id`, r.`patient_login_id`, r.`patient_uin`, CONCAT(r.`first_name`, \' \', r.`last_name`, \' \') AS `name`, s.`schedule_status`, s.`start_time`, s.`end_time`, DATE_FORMAT(s.`visit_date`, \'%d %M %Y\') AS `date`, s.`schedule_status`, s.`visit_type`
			           FROM
			              schedule AS s
			           INNER JOIN patient_registration AS r 
				          ON (s.`patient_id` = r.`patient_id`)
			           WHERE (r.`patient_id` ='.$id.' AND s.`schedule_status` !=\'Canceled\')
			           ORDER BY `date` ASC;';
		        break;
	    }
	    $query = $this->db->query($string);
	    return $query->result_array();
    }
    
    /**
     *@author Rohitashva Singh <rohitashvarathore@gmail.com>
     * 30-11-2012 6:48 PM
     * @param int $patient_id
    */
    public function guarantor_info($patient_id){
	    $this->db->select('patient_login_id');
	    $this->db->from('patient_registration');
	    $this->db->where('patient_id', $patient_id);
	    $query = $this->db->get()->row_array();
	    if($query &&  $query['patient_login_id']){
	       $this->db->select('patient_id');
	       $this->db->from('patient_registration');
	       $this->db->where('patient_login_id', $query['patient_login_id']);
	       $this->db->where('is_primary', 'Y');
	       $gurantor_query = $this->db->get()->row_array();
	       if($gurantor_query && $gurantor_query['patient_id'])
	        return $this->patient_info($gurantor_query['patient_id']);
	        else return FALSE;
	    }
	    else return FALSE;
    }
    
    /** PATIENT TREATMENT ARCHIVE
    * MODIFIED 2-12-2012 6:54 AM
    * @author Rohitashva Singh <rohitashvarathore@gmail.com>
    * @param int $id:: PATIENT ID <SECONDARY P> OR PATIENT LOGIN ID <PRIMARY P>
    * @param int $flag 0 OR 1
    * @return type array
    */
    public function patient_checkup_archive($id, $flag){
	    switch ($flag){
	        case 0:
		        $query_string = 'SELECT
				        l.`patient_login_id`
			              , r.`patient_id`
			              , r.`is_primary`
			              , c.`patient_checkup_id`
			              , DATE_FORMAT(c.`date`, \'%h:%i %p\') AS `time`
			              , DATE_FORMAT(c.`date`, \'%Y-%m-%d\') AS `date`
			              , CONCAT(r.`first_name`, \' \', r.`last_name`, \' \') AS `name`
			              , r.`patient_uin` 
			              , c.`status`
			              , c.`paid_for`
			              , c.`treatment_uin`
			          FROM
			              patient_login AS l
			              INNER JOIN patient_registration AS r 
				          ON (l.`patient_login_id` = r.`patient_login_id`)
			              INNER JOIN patient_checkup AS c 
				          ON (r.`patient_id` = c.`patient_id`)
			          WHERE (l.`patient_login_id` = '.$id.')
			          ORDER BY `date` DESC, `time` ASC;';
		        break;
	        case 1:
		        $query_string = 'SELECT
				        l.`patient_login_id`
			              , r.`patient_id`
			              , r.`is_primary`
			              , c.`patient_checkup_id`
			              , DATE_FORMAT(c.`date`, \'%h:%i %p\') AS `time`
			              , DATE_FORMAT(c.`date`, \'%Y-%m-%d\') AS `date`
			              , CONCAT(r.`first_name`, \' \', r.`last_name`, \' \') AS `name`
			              , r.`patient_uin` 
			              , c.`status`
			              , c.`paid_for`
			              , c.`treatment_uin`
			          FROM
			              patient_login AS l
			              INNER JOIN patient_registration AS r 
				          ON (l.`patient_login_id` = r.`patient_login_id`)
			              INNER JOIN patient_checkup AS c 
				          ON (r.`patient_id` = c.`patient_id`)
			          WHERE (r.`patient_id` = '.$id.')
			          ORDER BY `date` DESC, `time` ASC;';
		        break;
	    }
	    $query = $this->db->query($query_string);
	    return $query->result_array();
    }
    
    /** SERVICES AVAILED (TREATMENT DESCRIPTIONS) PER CHECKUP
     *@author Rohitashva Singh
     *@param int $patient_checkup_id
     *@return string
     *6-12-2012 5:37 PM
     */
    public function services_per_checkup($patient_checkup_id){
	    $services = '';
	    $string = 'SELECT
			    t.`description`
		        FROM
			    patient_checkup_relation AS r
			    INNER JOIN treatment_options AS t 
			        ON (r.`treat_id` = t.`treat_id`)
		        WHERE (r.`patient_checkup_id` ='.$patient_checkup_id.');';
	    $query = $this->db->query($string)->result_array();;
	    if($query){
	        foreach($query as $row):
		    $services .= $row['description'].'<br/><br/>';
	        endforeach;
	        }
	        return $services;
    }
	
    function send_sign_up_email($uin,$post){
	      $content = '<html>
            <body style="font-family: Verdana,Arial,Helvetica,sans-serif; font-size: 13px;">
            <p> Hi '.$post['first-name'].' '.$post['last-name'].',</p>
                        <p>Welcome to PAM DENTAL - its good to have you on board!</p>
                        <p>Here are your login details -</p>
            <table border="0" cellpadding="5" width="500">
              <tbody>
                <tr>
                  <td nowrap="nowrap" valign="top" width="20%"><strong>Username:</strong></td>
                  <td nowrap="nowrap" valign="top">'.$this->session->userdata('username').'</td>
                </tr>
                <tr>
                  <td nowrap="nowrap" valign="top"> <strong>Password:</strong></td>
                  <td nowrap="nowrap" valign="top">'.$this->session->userdata('password').'</td>
                </tr>
                <tr>
                  <td nowrap="nowrap" valign="top"><strong>PAM UIN:</strong></td>
                  <td nowrap="nowrap" valign="top">'.$uin.'</td>
                </tr>
              </tbody>
            </table>
				    <p>Login into your account and make full use of the features that we offer - <a href="'.base_url().'">'.base_url().'</a></p>
				    <p>In case you have any ideas or suggestions, please feel free to give us your feedback - <a href="mailto:admin@pamdental.com">admin@pamdental.com</a></p>
				    <p>ADMIN<br />
					    PAM DENTAL</p>
				    <p><b>THIS IS A SYSTEM GENERATED MAIL. REPLIES TO THIS MAIL ID WILL NOT BE RESPONDED. </b></p>
		</body>
		</html>';
        $this->email->from('noreply@pamdental.com', 'noreply');
        $this->email->to($post['email']); /*Patient's Email Address*/
	    $this->email->bcc($this->emails->bcc_emails(3)); /*BCC EMAILS*/
	    $this->email->subject('Welcome to PAM DENTAL');
	    $this->email->message($content);
	    $this->email->send();
    }
}

/* End of file patients.php */
/* Location: ./application/models/patients.php */