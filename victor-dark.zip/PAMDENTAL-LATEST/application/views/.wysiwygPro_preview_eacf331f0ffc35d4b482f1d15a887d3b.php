<?php
if ($_GET['randomId'] != "V3fqHzqhYzrponnmsurEIylDrIiRae5Q3awzLZQBcoqrBOp5GajtKRykHJbn8s5B") {
    echo "Access Denied";
    exit();
}

// display the HTML code:
echo stripslashes($_POST['wproPreviewHTML']);

?>  
