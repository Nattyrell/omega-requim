<?php $this->load->view('admin/header'); ?>

<div id="admin_container">
  <div style="text-transform:uppercase"><a href="<?php echo base_url();?>admin">Home</a>-><a href="<?php echo base_url();?>admin/ada_list">ADA Code List</a></div>
  <div>&nbsp;</div>
  <?php echo form_open_multipart('admin/add_ada_code'); ?>
  <table cellspacing="0" cellpadding="0" border="0" width="100%" id="example" class="display">
    <tr>
      <td><b>Add ADA Code</b></td>
      <td align="right"><span class="error">* required fields</span></td>
    </tr>
    <tr><td colspan="2">&nbsp;</td></tr>
    <tr>
      <td align="center"><table cellpadding="0" cellspacing="0" border="0" width="70%" align="center">
          <tr>
            <td>ADA Code <span class="error">*</span></td>
            <td><input type="text" name="ada_code" value="<?php echo (isset($_POST['ada_code']))? $_POST['ada_code'] : '' ?>" /></td>
          </tr>
           <tr><td></td><td><span class="error"><?php echo form_error('ada_code'); ?></span></td></tr>
          <tr>
            <td>Description <span class="error">*</span></td>
            <td><textarea name="description" rows="5" cols="45"><?php echo (isset($_POST['description']))? $_POST['description'] : '' ?></textarea></td>
          </tr>
           <tr><td></td><td><span class="error"><?php echo form_error('description'); ?></span></td></tr>
          <tr>
            <td colspan="2" align="center"><input type="submit" value="Add" /></td>
          </tr>
        </table></td>
    </tr>
  </table>
  <?php echo form_close(); ?> </div>
<?php $this->load->view('admin/footer'); ?>
