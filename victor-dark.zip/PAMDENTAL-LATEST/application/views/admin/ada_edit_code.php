<?php $this->load->view('admin/header'); ?>

<div id="admin_container">
  <div style="text-transform:uppercase"><a href="<?php echo base_url();?>admin">Home</a>-><a href="<?php echo base_url();?>admin/ada_list">ADA Code List</a></div>
  <div>&nbsp;</div>
  <?php echo form_open_multipart('admin/edit_ada_code/'.$this->uri->segment(3)); ?>
  <table cellspacing="0" cellpadding="0" border="0" width="100%" id="example" class="display">
    <tr>
      <td><b>Edit ADA Code</b></td>
      <td align="right"><span class="error">* required fields</span></td>
    </tr>
    <tr>
      <td colspan="2">&nbsp;</td>
    </tr>
    <tr>
      <td align="center"><table cellpadding="2" cellspacing="5" border="0">
          <tr>
            <td>ADA Code</td>
            <td><?php echo $result->ada_code ?></td>
          </tr>
          <tr>
            <td style="vertical-align:top">Description <span class="error">*</span></td>
            <td><textarea name="description" rows="5" cols="45"><?php echo (isset($_POST['description']))? $_POST['description'] : $result->description ?></textarea></td>
          </tr>
          <tr><td></td><td><span class="error"><?php echo form_error('description'); ?></span></td></tr>
          <tr>
            <td colspan="2" align="center"><input type="submit" value="Update" /></td>
          </tr>
        </table></td>
    </tr>
  </table>
  <?php echo form_close(); ?> </div>
<?php $this->load->view('admin/footer'); ?>