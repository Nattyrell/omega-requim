<?php $this->load->view('admin/header'); ?>

<div id="admin_container">
  <div style="text-transform:uppercase"><a href="<?php echo base_url();?>admin">Home</a>-><a href="<?php echo base_url();?>admin/ada_list">ADA Code List</a>-><a href="<?php echo base_url();?>admin/ada_treatment_list/<?php echo $this->uri->segment(3)?>">ADA Code Treatment List</a></div>
  <div>&nbsp;</div>
  <?php echo form_open_multipart('admin/ada_edit_treatment/'.$this->uri->segment(3).'/'.$this->uri->segment(4)); ?>
  <input type="hidden" name="treat_id" value="<?php echo $this->uri->segment(4) ?>" />
  <table cellspacing="0" cellpadding="0" border="0" width="100%" id="example" class="display">
    <tr>
      <td><b>Edit ADA Treatment</b></td>
      <td align="right"><span class="error">* required fields</span></td>
    </tr>
    <tr>
      <td colspan="2">&nbsp;</td>
    </tr>
    <tr>
      <td align="center"><table cellpadding="0" cellspacing="0" border="0" width="70%" align="center">
          <tr>
            <td style="vertical-align:top">Description <span class="error">*</span></td>
            <td><textarea name="description" rows="8" cols="40"><?php echo (isset($_POST['description']))? $_POST['description'] : $record->description ?></textarea></td>
          </tr>
           <tr><td></td><td><span class="error"><?php echo form_error('description'); ?></span></td></tr>
          <tr>
            <td>Price  <span class="error">*</span></td>
            <td><input type="text" name="price" value="<?php echo (isset($_POST['price']))? $_POST['price'] : $record->price ?>" size="53" /></td>
          </tr>
           <tr><td></td><td><span class="error"><?php echo form_error('price'); ?></span></td></tr>
          <tr>
            <td>Treatment Insurance  <span class="error">*</span></td>
            <td><input type="text" name="treatment_insurance" value="<?php echo (isset($_POST['treatment_insurance']))? $_POST['treatment_insurance'] : $record->treatment_insurance ?>" size="53" /></td>
          </tr>
           <tr><td></td><td><span class="error"><?php echo form_error('treatment_insurance'); ?></span></td></tr>
          <tr>
            <td>Treatment Deductable  <span class="error">*</span></td>
            <td><input type="text" name="treatment_deductable" value="<?php echo (isset($_POST['treatment_deductable']))? $_POST['treatment_deductable'] : $record->treatment_deductable ?>" size="53" /></td>
          </tr>
           <tr><td></td><td><span class="error"><?php echo form_error('treatment_deductable'); ?></span></td></tr>
          <tr>
            <td style="vertical-align:top">Pros</td>
            <td><textarea name="pros" rows="8" cols="40"><?php echo (isset($_POST['pros']))? $_POST['pros'] : $record->pros ?></textarea></td>
          </tr>
          <tr>
            <td style="vertical-align:top">Cons</td>
            <td><textarea name="cons" rows="8" cols="40"><?php echo (isset($_POST['cons']))? $_POST['cons'] : $record->cons ?></textarea></td>
          </tr>
          <tr>
            <td colspan="2" align="center"><input type="submit" value="Update" /></td>
          </tr>
        </table></td>
    </tr>
  </table>
  <?php echo form_close(); ?> </div>
<?php $this->load->view('admin/footer'); ?>
