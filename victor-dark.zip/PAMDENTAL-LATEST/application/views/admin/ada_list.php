<?php $this->load->view('admin/header'); ?>
<script type="text/javascript" charset="utf-8">
	$(document).ready(function() {
	$('#example').dataTable( {
		"sPaginationType": "full_numbers"
		} );
	} );
</script>

<div id="admin_container">
  <div style="text-transform:uppercase"><a href="<?php echo base_url();?>admin">Home</a></div>
  <div>&nbsp;</div>
<table style="width:975px;" border="0" cellspacing='0' cellpadding='0' >
	<tr><td><b>ADA Code List</b></td></tr>
    <tr><td colspan="2" align="right"><a href="<?php echo base_url();?>admin/add_ada_code"><b>Add ADA Code</b></a></td></tr>
    <tr><td colspan="2">&nbsp;</td></tr>
    <tr><td colspan="2" align="center" class="error"><?php echo ($this->session->flashdata('show_message')!='')? $this->session->flashdata('show_message') : ''; ?></td></tr>
    <tr><td colspan="2">&nbsp;</td></tr>
    <tr><td>
          <table cellspacing="0" cellpadding="0" border="0" style="width:975px;" id="example" class="display">
            <thead>
              <tr>
                <th align="center">S.No.</th>
                <th align="center">ADA Code</th>
                <th align="center">Description</th>
                <th align="center">Treatment</th>
                <th align="center">Action</th>
              </tr>
            </thead>
            <tbody>
              <?php if($result)
                {
                    foreach($result->result() as $row):
          ?>
              <tr>
                <td align="center"><?php echo $row->ada_code_id;?></td>
                <td align="center"><?php echo $row->ada_code;?></td>
                <td align="left"><?php echo $row->description;?></td>
                <td align="center"><a href="<?php echo base_url();?>admin/ada_treatment_list/<?php echo base64_encode($row->ada_code_id);?>"><?php echo 'View Treatment'?></a></td>
                <td align="center"><a href="<?php echo base_url();?>admin/edit_ada_code/<?php echo base64_encode($row->ada_code_id);?>">Edit</a></td>
              </tr>
              <?php endforeach;
                }
                else
                    echo '<tr><td colspan="5">No Record Found.</td></tr>';
             ?>
            </tbody>
          </table>
            </td></tr>
</table>  
</div>
<?php $this->load->view('admin/footer'); ?>