<?php $this->load->view('admin/header'); ?>
<script type="text/javascript" charset="utf-8">
	$(document).ready(function() {
	$('#example').dataTable( {
		"sPaginationType": "full_numbers"
		} );
	} );
</script>

<div id="admin_container">
  <div style="text-transform:uppercase"><a href="<?php echo base_url();?>admin">Home</a>-><a href="<?php echo base_url();?>admin/ada_list">ADA Code List</a></div>
  <div>&nbsp;</div>
  <table style="width:975px;" border="0" cellspacing='0' cellpadding='0' >
    <tr>
      <td><b>Treatment</b></td>
    </tr>
    <tr>
      <td colspan="2" align="right"><a href="<?php echo base_url();?>admin/ada_add_treatment/<?php echo $this->uri->segment(3);?>"><b>Add ADA Treatment</b></a></td>
    </tr>
    <tr>
      <td colspan="2">&nbsp;</td>
    </tr>
    <tr>
      <td colspan="2" align="center" class="error"><?php echo ($this->session->flashdata('show_message')!='')? $this->session->flashdata('show_message') : ''; ?></td>
    </tr>
    <tr>
      <td colspan="2">&nbsp;</td>
    </tr>
    <tr>
      <td><table cellspacing="0" cellpadding="0" border="0" style="width:975px;" id="example" class="display">
          <thead>
            <tr>
              <th align="center">S.No.</th>
              <th align="center">Description</th>
              <th align="center">Price</th>
              <th align="center">Treatment Insurance</th>
              <th align="center">Treatment Deductable</th>
              <th align="center">Pros</th>
              <th align="center">Cons</th>
              <th align="center">Action</th>
            </tr>
          </thead>
          <tbody>
            <?php if($result)
  		{   $i=0;
			foreach($result->result() as $row):
  ?>
            <tr>
              <td align="center"><?php echo $i+=1;?></td>
              <td align="center"><?php echo $row->description;?></td>
              <td align="center"><?php echo $row->price;?></td>
              <td align="center"><?php echo $row->treatment_insurance;?></td>
              <td align="center"><?php echo $row->treatment_deductable;?></td>
              <td align="center"><?php echo $row->pros;?></td>
              <td align="center"><?php echo $row->cons;?></td>
              <td align="center"><a href="<?php echo base_url();?>admin/ada_edit_treatment/<?php echo $this->uri->segment(3);?>/<?php echo base64_encode($row->treat_id);?>">Edit</a></td>
            </tr>
            <?php endforeach;
		}
		else
			echo '<tr><td colspan="5">No Record Found.</td></tr>';
	 ?>
          </tbody>
        </table></td>
    </tr>
  </table>
</div>
<?php $this->load->view('admin/footer'); ?>
