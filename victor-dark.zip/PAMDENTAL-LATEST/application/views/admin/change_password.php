<?php $this->load->view('admin/header'); ?>
	<div id="admin_container">
    <div  style="text-transform:uppercase"><a href="<?php echo base_url();?>admin">Home</a></div>
    <div>&nbsp;</div>
<?php

$password1= array (
'name'    =>  'password1',
'id'      =>  'password1',
'value' => @$_POST['password1']
);
$password2= array (
'name'    =>  'password2',
'id'      =>  'password2',
'value' => @$_POST['password2']
);
$password3= array (
'name'    =>  'password3',
'id'      =>  'password3',
'value' => @$_POST['password3']
);

$form = array(
			'name' => 'change_pas',
			'id'   => 'change_pass',
);
echo form_open_multipart('admin/changepassword',$form); ?>
<table cellspacing="0" cellpadding="0" border="0" width="100%" id="example" class="display">
<tr><td align="center">
<table cellpadding="0" cellspacing="0" border="0" width="30%">
    <tr>
      <td>Old Password:<font color="#FF0000">*</font></td>
      <td><?php echo form_password($password1);?></td>
    </tr>
    <tr>
      <td colspan="2"><font color="#FF0000"><?php echo form_error($password1['name']); ?></font></td>
    </tr>
    <tr>
      <td>New Password:<font color="#FF0000">*</font></td>
      <td><?php echo form_password($password2);?></td>
    </tr>
    <tr>
      <td colspan="2"><font color="#FF0000"><?php echo form_error($password2['name']); ?></font></td>
    </tr>
    <tr>
      <td>Confirm Password:<font color="#FF0000">*</font></td>
      <td><?php echo form_password($password3);?></td>
    </tr>
    <tr>
      <td colspan="2"><font color="#FF0000"><?php echo form_error($password3['name']); ?></font></td>
    </tr>
    <tr>
      <td colspan="2"><font color="#FF0000"><?php echo $this->session->flashdata('pass_mismatch');?></font></td>
    </tr>
    <tr>
      <td align="center" colspan="2"><input type="submit" name="save" value="SAVE" />&nbsp;</td>
    </tr>
  </table>
 </td></tr></table>
 
   </div>
<?php $this->load->view('admin/footer'); ?>