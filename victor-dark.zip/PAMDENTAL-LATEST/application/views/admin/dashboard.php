<?php $this->load->view('admin/header'); ?>
    <div id="admin_container" style="min-height:350px;">
    <div><?php if($this->session->flashdata('show_message')){?><font color="#FF0000"><?php echo $this->session->flashdata('show_message');}?></font></div>
        <div class="dashboard" onmouseover="change_colour_patient();" onmouseout="restore_colour_patient();"><a href="<?php echo base_url()?>admin/patient-list" id="patient">Patient List</a></div>
        <div class="dashboard" onmouseover="change_colour_schedule();" onmouseout="restore_colour_schedule();"><a href="<?php echo base_url()?>admin/appointment-list" id="appointment">Appointment Schedule</a></div>
        <div class="dashboard" onmouseover="change_colour_billing();" onmouseout="restore_colour_billing();"><a href="<?php echo base_url()?>admin/billing-history" id="billing">Billing History</a></div>
        <div class="dashboard" onmouseover="change_colour_ada_code();" onmouseout="restore_colour_ada_code();"><a href="<?php echo base_url().'admin/ada-list' ?>" id="ada_code">Ada Codes</a></div>
        <div class="dashboard" onmouseover="change_colour_teeth_list();" onmouseout="restore_colour_teeth_list();"><a href="<?php echo base_url().'admin/teeth-list' ?>" id="teeth_list">Teeth</a></div>
        <div class="dashboard" onmouseover="change_colour_dentist();" onmouseout="restore_colour_dentist();"><a href="<?php echo base_url()?>admin/dentist-list" id="dentist">Dentist</a></div>
        <div class="dashboard" onmouseover="change_colour_frontoffice();" onmouseout="restore_colour_frontoffice();"><a href="<?php echo base_url()?>admin/frontoffice-list" id="frontoffice">Front office</a></div>
        <div class="dashboard" onmouseover="change_colour_settings();" onmouseout="restore_colour_settings();"><a href="<?php echo base_url()?>admin/changepassword" id="settings">Settings</a></div>
   </div>
<?php $this->load->view('admin/footer'); ?>