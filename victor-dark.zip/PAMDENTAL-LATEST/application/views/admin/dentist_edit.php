<?php $this->load->view('admin/header'); ?>

<div id="admin_container">
  <div style="text-transform:uppercase"><a href="<?php echo base_url();?>admin">Home</a>-><a href="<?php echo base_url();?>admin/dentist_list">Dentist</a></div>
  <div>&nbsp;</div>
  <?php echo $this->session->flashdata('profile_updated') ? '<div><font color = "red"><code>'.$this->session->flashdata('profile_updated').'</code></font></div>' : ''?>
  <div>&nbsp;</div>
  <?php echo form_open_multipart('admin/dentist_edit/'.$this->uri->segment(3)); ?>
  <table cellspacing="0" cellpadding="0" border="0" width="100%" id="example" class="display">
    <tr>
      <td><b>Edit Dentist</b></td>
      <td align="right"><span class="error">* required fields</span></td>
    </tr>
    <tr>
      <td colspan="2">&nbsp;</td>
    </tr>
    <tr>
      <td align="center"><table cellpadding="0" cellspacing="0" border="0" width="70%" align="center">
          <tr>
            <td>First Name <span class="error">*</span></td>
            <td><input type="text" name="first_name" value="<?php echo (isset($_POST['first_name']))? $_POST['first_name'] : $record->first_name ?>" size="53"/></td>
          </tr>
           <tr><td></td><td><span class="error"><?php echo form_error('first_name'); ?></span></td></tr>
          <tr>
            <td>Last Name <span class="error">*</span></td>
            <td><input type="text" name="last_name" value="<?php echo (isset($_POST['last_name']))? $_POST['last_name'] : $record->last_name ?>" size="53" /></td>
          </tr>
           <tr><td></td><td><span class="error"><?php echo form_error('last_name'); ?></span></td></tr>
          <tr>
            <td>Middle Initial</td>
            <td><input type="text" name="middle_initial" value="<?php echo (isset($_POST['middle_initial']))? $_POST['middle_initial'] : $record->middle_initial ?>" size="53" /></td>
          </tr>
           <tr><td></td><td></td></tr>
           <tr>
           	<td>Clinic Name <span class="error">*</span></td>
            <td><input type="text" name="clinic_name" value="<?php echo (isset($_POST['clinic_name']))? $_POST['clinic_name'] : $record->clinic_name ?>" size="53" /></td>
          </tr>
           <tr><td></td><td><span class="error"><?php echo form_error('clinic_name'); ?></span></td></tr>
          <tr>
            <td>Email <span class="error">*</span></td>
            <td><input type="text" name="email" value="<?php echo (isset($_POST['email']))? $_POST['email'] : $record->email ?>" size="53" /></td>
          </tr>
           <tr><td></td><td><span class="error"><?php echo form_error('email'); ?></span></td></tr>
          <tr>
            <td>Username <span class="error">*</span></td>
            <td><input type="text" name="username" value="<?php echo (isset($_POST['username']))? $_POST['username'] : $record->username ?>" size="53" /></td>
          </tr>
           <tr><td></td><td><span class="error"><?php echo form_error('username'); ?></span></td></tr>
          <tr>
            <td>Address street <span class="error">*</span></td>
            <td><input type="text" name="address_street" value="<?php echo (isset($_POST['address_street']))? $_POST['address_street'] : $record->address_street ?>" size="53" /></td>
          </tr>
           <tr><td></td><td><span class="error"><?php echo form_error('address_street'); ?></span></td></tr>
          <tr>
            <td>Apartment</td>
            <td><input type="text" name="address_apartment_number" value="<?php echo (isset($_POST['address_apartment_number']))? $_POST['address_apartment_number'] : $record->address_apartment_number ?>" size="53" /></td>
          </tr>
           <tr><td></td><td><span class="error"><?php echo form_error('address_apartment_number'); ?></span></td></tr>
          <tr>
            <td>City <span class="error">*</span></td>
            <td><input type="text" name="address_city" value="<?php echo (isset($_POST['address_city']))? $_POST['address_city'] : $record->address_city ?>" size="53" /></td>
          </tr>
           <tr><td></td><td><span class="error"><?php echo form_error('address_city'); ?></span></td></tr>
          <tr>
            <td>State <span class="error">*</span></td>
            <td><?php $query=$this->db->get('us_states');
                            foreach ($query->result() as $row)
                            {
                                $address_state_id[$row->state_abbr]=$row->state_abbr;
                            }
                             echo form_dropdown('address_state',$address_state_id,(@$_POST)? @$_POST['address_state'] : $record->address_state); ?></td>
          </tr>
           <tr><td></td><td></td></tr>
          <tr>
            <td>Zip Code <span class="error">*</span></td>
            <td><input type="text" name="address_zipcode" value="<?php echo (isset($_POST['address_zipcode']))? $_POST['address_zipcode'] : $record->address_zipcode ?>" size="53" /></td>
          </tr>
           <tr><td></td><td><span class="error"><?php echo form_error('address_zipcode'); ?></span></td></tr>
          <tr>
            <td>Phone <span class="error">*</span></td>
            <td><input type="text" name="phone" value="<?php echo (isset($_POST['phone']))? $_POST['phone'] : $record->phone ?>" size="53" /></td>
          </tr>
           <tr><td></td><td><span class="error"><?php echo form_error('phone'); ?></span></td></tr>                                                       
          <tr>
            <td style="vertical-align:top">Password</td>
            <td><input type="password" name="password" value="" size="53" /></td>
          </tr>
          <tr><td></td><td></td></tr>
            <tr>
            <td style="vertical-align:top">Confirm Password</td>
            <td><input type="password" name="conf_password" value="" size="53" /></td>
          </tr>
          <tr><td></td><td><span class="error"><?php echo form_error('conf_password'); ?></span></td></tr>
          <tr>
            <td colspan="2" align="center"><input type="submit" value="Update" /></td>
          </tr>
        </table></td>
    </tr>
  </table>
  <?php echo form_close(); ?> </div>
<?php $this->load->view('admin/footer'); ?>
