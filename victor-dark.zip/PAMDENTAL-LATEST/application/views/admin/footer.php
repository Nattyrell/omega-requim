<div id="footer">
        	<div class="rightcol"><div style="float:left; position:relative; margin:38px 0px 0px 0px;"></div>
	            <div align="left" style="float:left; position:relative; margin:38px 5px 0px 0px; line-height:18px;">
                    ©2012 <font color="#fff">PAM DENTAL </font><br/>
                </div>
    	    </div>
</div>
</body>
</html>