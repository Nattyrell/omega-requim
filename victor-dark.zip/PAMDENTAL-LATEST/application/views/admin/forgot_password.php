<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title></title>
<link rel="shortcut icon" href="<?php echo base_url();?>system/application/images/favicon.ico"/>
<link href="<?php echo base_url();?>css/admin_style.css" rel="stylesheet" type="text/css" />
</head>
<body>
	<div id="admin_outer_wrapper">
    	<div id="wrapper">
        	<div id="content_box">
            	WELCOME TO PAM DENTAL
                <div id="content_block">
<div style ="margin-left: 150px; width: 700px">
    <form name="patient-forgot-password-form" id="patient-forgot-password-form" method="post" action="<?php echo base_url()?>admin/forgot_password" enctype="multipart/form-data">
    <fieldset>
        
        <legend>Forgot Password?</legend>
        
        <div style="clear: both; padding-top: 25px"></div>
        
        <div style="float: left; width: 150px"><label>ENTER PAM USERNAME<font color="#FF2437">*</font></label></div>
        <div style="float: left; width: 250px"><input type="text" id="username" name= "username" maxlength="255" size="32" value="<?php echo set_value('email'); ?>"/></div>
        <div style="float: left; width: 250px"><font size=2 color="#FF2437"><?php echo form_error('username')?></font></div>
        
        <div style="clear: both; padding-top: 25px"></div>
        
        
        <div style="float: left; width: 150px">&nbsp;</div>
        <div style="float: left; width: 250px"><input type="submit" name="submit" id="submit" value="Proceed"/></div>
        <div style="float: left; width: 250px">&nbsp;</div>
        
        
    </fieldset>
    </form>
    
    <div style="clear: both; padding-top: 10px"></div>
    
</div>
</div>
            </div>
            <div id="footer">
            	<div class="rightcol"><div style="float:left; position:relative; margin:18px 5px 0px 0px;"></div> &copy; Copyright 2012 <a href="#" title="PAM Dental" style="color:#fff;">PAM Dental</a></div>
        	</div>
        </div>
    </div>
    
</body>
</html>