<?php $this->load->view('admin/header'); ?>

<div id="admin_container">
  <div style="text-transform:uppercase"><a href="<?php echo base_url();?>admin">Home</a>-><a href="<?php echo base_url();?>admin/frontoffice_list">Frontoffice</a></div>
  <div>&nbsp;</div>
  <?php echo $this->session->flashdata('profile_updated') ? '<div><font color = "red"><code>'.$this->session->flashdata('profile_updated').'</code></font></div>' : ''?>
  <div>&nbsp;</div>
  <?php echo form_open_multipart('admin/frontoffice_edit/'.$this->uri->segment(3)); ?>
  <table cellspacing="0" cellpadding="0" border="0" width="100%" id="example" class="display">
    <tr>
      <td><b>Edit Frontoffice</b></td>
      <td align="right"><span class="error">* required fields</span></td>
    </tr>
    <tr>
      <td colspan="2">&nbsp;</td>
    </tr>
    <tr>
      <td align="center"><table cellpadding="0" cellspacing="0" border="0" width="70%" align="center">
          <tr>
            <td style="vertical-align:top">First Name <span class="error">*</span></td>
            <td><input type="text" name="first_name" value="<?php echo (isset($_POST['first_name']))? $_POST['first_name'] : $record->first_name ?>" /></td>
          </tr>
           <tr><td></td><td><span class="error"><?php echo form_error('first_name'); ?></span></td></tr>
          <tr>
            <td>Last Name <span class="error">*</span></td>
            <td><input type="text" name="last_name" value="<?php echo (isset($_POST['last_name']))? $_POST['last_name'] : $record->last_name ?>" size="53" /></td>
          </tr>
           <tr><td></td><td><span class="error"><?php echo form_error('last_name'); ?></span></td></tr>
          <tr>
            <td>Middle Initial</td>
            <td><input type="text" name="middle_initial" value="<?php echo (isset($_POST['middle_initial']))? $_POST['middle_initial'] : $record->middle_initial ?>" size="53" /></td>
          </tr>
           <tr><td></td><td></td></tr>
          <tr>
            <td>Email <span class="error">*</span></td>
            <td><input type="text" name="email" value="<?php echo (isset($_POST['email']))? $_POST['email'] : $record->email ?>" size="53" /></td>
          </tr>
           <tr><td></td><td><span class="error"><?php echo form_error('email'); ?></span></td></tr>
          <tr>
            <td>Username <span class="error">*</span></td>
            <td><input type="text" name="username" value="<?php echo (isset($_POST['username']))? $_POST['username'] : $record->username ?>" size="53" /></td>
          </tr>
           <tr><td></td><td><span class="error"><?php echo form_error('username'); ?></span></td></tr>
          <tr>
            <td style="vertical-align:top">Password</td>
            <td><input type="password" name="password" value="<?php echo (isset($_POST['password']))? $_POST['password'] : '' ?>" size="53" /></td>
          </tr>
          <tr><td></td><td></td></tr>
            <tr>
            <td style="vertical-align:top">Confirm Password</td>
            <td><input type="password" name="conf_password" value="<?php echo (isset($_POST['conf_password']))? $_POST['conf_password'] : '' ?>" size="53" /></td>
          </tr>
          <tr><td></td><td><span class="error"><?php echo form_error('conf_password'); ?></span></td></tr>
          <tr>
            <td colspan="2" align="center"><input type="submit" value="Update" /></td>
          </tr>
        </table></td>
    </tr>
  </table>
  <?php echo form_close(); ?> </div>
<?php $this->load->view('admin/footer'); ?>
