<?php $this->load->view('admin/header'); ?>
<script type="text/javascript" charset="utf-8">
	$(document).ready(function() {
	$('#example').dataTable( {
		"sPaginationType": "full_numbers"
		} );
	} );
</script>

<div id="admin_container">
  <div style="text-transform:uppercase"><a href="<?php echo base_url();?>admin">Home</a>-><a href="<?php echo base_url();?>admin/frontoffice_list">Front office List</a></div>
  <div>&nbsp;</div>
<table style="width:975px;" border="0" cellspacing='0' cellpadding='0' >
	<tr><td><b>Front office Log</b></td></tr>
    <tr><td colspan="2">&nbsp;</td></tr>
    <tr><td colspan="2" align="center" class="error"><?php echo ($this->session->flashdata('show_message')!='')? $this->session->flashdata('show_message') : ''; ?></td></tr>
    <tr><td colspan="2">&nbsp;</td></tr>
    <tr><td>
          <table cellspacing="0" cellpadding="0" border="0" style="width:975px;" id="example" class="display">
            <thead>
              <tr>
                <th align="center">S.No.</th>
                <th align="center">Front office Name</th>
                <th align="center">IP Address</th>
                <th align="center">User Agent</th>
                <th align="center">Date</th>
                <th align="center">Activity</th>
              </tr>
            </thead>
            <tbody>
              <?php if($result)
                {	$i=0;
                    foreach($result->result() as $row):
          ?>
              <tr>
                <td align="left"><?php echo $i+=1;?></td>
                <td align="center"><?php echo base64_decode($this->uri->segment(3));?></td>
                <td align="left"><?php echo $row->ip_address;?></td>
                <td align="left"><?php echo $row->http_user_agent;?></td>
                <td align="center"><?php echo date('d F Y g:i A',strtotime($row->datetime));?></td>
                <td align="center"><?php echo $row->activity;?></td>
              </tr>
              <?php endforeach;
                }
                else
                    echo '<tr><td colspan="5">No Record Found.</td></tr>';
             ?>
            </tbody>
          </table>
            </td></tr>
</table>  
</div>
<?php $this->load->view('admin/footer'); ?>