<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<title><?php if(!isset($title)) { echo '';} else { echo @$title; }?></title>
	<?php echo (isset($js))? $js : '';?>
	<?php echo (isset($css))? $css : '';?>
	<link rel="shortcut icon" type="image/x-icon" href="<?php echo base_url()?>images/favicon.ico" />
</head>
<body>
	<div id="admin_wrapper">
    	<div id="pageHeader">
           	<div class="logo"><h1><a href="<?php echo base_url()?>admin" title="">PAM Dental</a></h1></div>
            <div class="user_block">
                    	<div class="left_stripe">&nbsp;</div>
                        <div class="right_stripe">
                        	<table border="0" cellspacing="0" cellpadding="0" align="center">
                                <tr>
                                	<td valign="top">
                                    	<div class="guestblock">
                                            <div class="welcome">WELCOME</div>
                                            <div class="clear"></div>
                                            <div class="guestname"><?php echo "Administrator";?></div>
                                        </div>
                                    </td>
                                    <td valign="top"><div class="v_separator">&nbsp;</div></td>
                                    <td valign="top"><div class="logout"><a href="<?php echo base_url()?>admin/logout">Logout</a></div></td>
                                </tr>
                            </table>
                        </div>
                    </div>
        </div>
        
        <div class="clear"></div>