<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title></title>
<link rel="shortcut icon" href="<?php echo base_url();?>system/application/images/favicon.ico"/>
<link href="<?php echo base_url();?>css/admin_style.css" rel="stylesheet" type="text/css" />
<link rel="shortcut icon" type="image/x-icon" href="<?php echo base_url()?>images/favicon.ico" />
</head>

<?php

$data1 = array(
              'name'        => 'username',
              'id'          => 'username',
			  'class'		=>	'login_input',
			  'value'		=>	'',
            );
			
$data2 = array(
              'name'        => 'password',
              'id'          => 'password',
              'class'		=>	'login_input',
			  'value'		=>	'',
              
            );
?>

<body>
	<div id="admin_outer_wrapper">
    	<div id="wrapper">
        	<div id="content_box">
            	WELCOME TO PAM DENTAL
                <div id="content_block">
                    <?php echo form_open('admin/login'); ?>
                        <table width="92%" border="0" cellspacing="3" cellpadding="3" align="center">
                        	<tr>
                                <td valign="top" height="25px" colspan="2"></td>
                            </tr>
                            <tr>
                                <td valign="top" colspan="2"><strong><font color="#FF0000"><?php echo $this->session->flashdata('error');?></font></strong></td>
                            </tr>
                            <tr>
                                <td valign="top" height="10px" colspan="2"></td>
                            </tr>
                            <tr>
                                <td width="18%" valign="middle">Username:</td>
                                <td width="82%" valign="middle"><?php echo form_input($data1);?></td>
                            </tr>
                             <tr>
                                <td valign="top" colspan="2"><font color="#FF0000"><?php echo form_error($data1['name']); ?></font></td>
                            </tr>
                            <tr>
                                <td valign="middle">Password:</td>
                                <td valign="middle"><?php echo form_password($data2);?></td>
                            </tr>
                              <tr>
                                <td valign="top" colspan="2"><font color="#FF0000"><?php echo form_error($data2['name']); ?></font></td>
                            </tr>

                            <tr>
                                <td valign="top" height="3px" colspan="2"></td>
                            </tr>
                            <tr>
                                <td valign="middle">&nbsp;</td>
                                <td valign="middle"><input type="submit" name="login" value="Login"/></td>
                            </tr>
                            <tr>
                                <td valign="top" height="5px" colspan="2"></td>
                            </tr>
                        </table>
                   <?php form_close();?>
                   
                   <div align="middle" style="float:left; width:500px"><p>Forgot your Username or Password? <a href="<?php echo base_url()?>admin/forgot_password">Click here</a></p></div>
                </div>
            </div>
            <div id="footer">
            	<div class="rightcol"><div style="float:left; position:relative; margin:18px 5px 0px 0px;"></div> &copy; Copyright 2012 <a href="#" title="PAM Dental" style="color:#fff;">PAM Dental</a></div>
        	</div>
        </div>
    </div>
    
</body>
</html>