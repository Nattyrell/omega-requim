<?php $this->load->view('admin/header'); ?>
<script type="text/javascript" charset="utf-8">
    $(document).ready(function() {
    jQuery.extend( jQuery.fn.dataTableExt.oSort, {
    "num-html-pre": function ( a ) {
        var x = a.replace( /<.*?>/g, "" );
        return parseFloat( x );
    },
 
    "num-html-asc": function ( a, b ) {
        return ((a < b) ? -1 : ((a > b) ? 1 : 0));
    },
 
    "num-html-desc": function ( a, b ) {
        return ((a < b) ? 1 : ((a > b) ? -1 : 0));
    }
    } );
    $('#example').dataTable( {
            "sPaginationType": "full_numbers",
            "aoColumns": [
            null,
            null,
            null,
            null,
            { "sType": "num-html" },
            { "sType": "num-html" },
            { "sType": "num-html" },
        ]
            } );
    } );
</script>

<style type="text/css">
    legend {
        font-size: 1.2em;
        font-weight: bold;
    }
    fieldset {
        border: 1px solid #13A7CD;
        padding: 0 1.4em 1.4em;
    }
</style>

<?php 
/*$treat_ids = unserialize($billing_detail['treat_ids']);
$treatment_options = $this->admin_model->billing_treatment_options($treat_ids);
$billing_teeth_and_ada = $this->admin_model->billing_teeth_and_ada($billing_detail['patient_checkup_id']);
$billing = array();
if($treatment_options && $billing_teeth_and_ada){
    foreach ($billing_teeth_and_ada as $key=>$val):
        $billing[$key]['tooth_desc'] = $val['tooth_desc'];
        $billing[$key]['ada_code_des'] = $val['ada_code_des'];
        $billing[$key]['treatment_option'] = $treatment_options['description'][$key];
        $billing[$key]['price'] = $treatment_options['price'][$key];
        $billing[$key]['treatment_insurance'] = $treatment_options['treatment_insurance'][$key];
        $billing[$key]['treatment_deductible'] = $treatment_options['treatment_deductible'][$key];
    endforeach;
}*/
?>

<div id="admin_container">
  <div style="text-transform:uppercase"><a href="<?php echo base_url();?>admin">Home</a></div>
  <div style="clear: both; padding-top: 10px; padding-bottom: 10px">&nbsp;</div>
    <div style="padding-left: 25px; padding-right: 25px; padding-bottom: 10px">
        <fieldset>
            <legend>Transaction Detail</legend>
            <table width="50%" style="padding-bottom: 25px">
                <tr>
                    <th>Name</th>
                    <td><?php echo $billing_detail['name']?></td>
                </tr>
                <tr>
                    <th>Patient ID</th>
                    <td><?php echo $billing_detail['patient_uin']?></td>
                </tr>
                <tr>
                    <th>Payment Date</th>
                    <td><?php echo $billing_detail['date']?></td>
                </tr>
                <tr>
                    <th>Time of Payment</th>
                    <td><?php echo $billing_detail['time']?></td>
                </tr>
                <tr>
                    <th>Patient Grand Total (US$)</th>
                    <td><font color="red"><?php echo $billing_detail['total_amount_paid']?></font></td>
                </tr>
                <tr>
                    <th>Transaction ID</th>
                    <td><code><?php echo $billing_detail['transaction_id']?></code></td>
                </tr>
                <tr>
                    <th>Billing Address</th>
                    <td>
                        <?php
                        $states = array();
                        foreach($us_states->result_array() AS $row){
                            $states[$row['id']] = $row['state_abbr'];
                        }

                        // DO MODIFICATIONS....
                        $contact_address = $patient_address['p_address_apartment_number'].nbs(1).$patient_address['p_address_street'].', '.$patient_address['p_address_city'].nbs(1).$states[$patient_address['p_address_state_id']].nbs(1).$patient_address['p_address_zipcode'];
                        echo $contact_address;
                        ?>
                    </td>
                </tr>
            </table>
        </fieldset>
        <div style="clear: both; padding-top: 10px; padding-bottom: 10px"></div>
        <fieldset>
            <legend>Treatment Plan</legend>
            <table border="0" cellspacing='0' cellpadding='0' id="example" class="display" style="width:100%;">
                <thead>
                <tr>
                    <th align="center">Sr. No.</th>
                    <!--                    <th align="center">Tooth Description</th>-->
                    <!--                    <th align="center">ADA Code Description</th>-->
                    <th align="center">Service</th>
                    <th align="center">Service Price (US$)</th>
                    <!--<th align="center">INS. Fee (US$)</th>-->
                    <th align="center">Est. Insurance Coverage (US$)</th>
                    <th align="center">INS. Covered %</th>
                    <th align="center">Annual Deductible (US$)</th>
                    <th align="center">Patient Fee (US$)</th>
                    <!--                    <th align="center">Treatment Insurance(US$)</th>-->
                    <!--                    <th align="center">Treatment Deductible(US$)</th>-->
                </tr>
                </thead>
                <tbody>
                <?php
                $i=0;
                if($treatment_detail){
                    foreach($treatment_detail as $row):
                        ?>
                    <tr>
                        <td align="center"><?php echo $i+=1?></td>
                        <!--                    <td align="center">--><?php //echo $row['tooth_desc']?><!--</td>-->
                        <!--                    <td align="center">--><?php //echo $row['ada_code_des']?><!--</td>-->
                        <td align="center"><?php echo $row['treatment_description']?></td>
                        <td align="center"><font color="red"><?php echo $row['t_price']?></font></td>
                        <td align="center"><font color="red"><?php echo $row['e_insurance_coverage']?></font></td>
                        <td align="center"><?php echo $row['ins_covered_per']?></td>
                        <td align="center"><font color="red"><?php echo $row['annual_deductible']?></font></td>
                        <td align="center"><font color="red"><?php echo $row['patient_fee']?></font></td>
                        <!--                    <td align="center"><font color="red">--><?php //echo $row['treatment_insurance']?><!--</font></td>-->
                        <!--                    <td align="center"><font color="red">--><?php //echo $row['treatment_deductible']?><!--</font></td>-->
                    </tr>
                        <?php
                    endforeach; }?>
                </tbody>
            </table>
        </fieldset>
        </div>
</div>
<?php $this->load->view('admin/footer'); ?>
