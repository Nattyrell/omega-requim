<?php $this->load->view('admin/header'); ?>
<script type="text/javascript" charset="utf-8">
    $(document).ready(function() {
    jQuery.extend( jQuery.fn.dataTableExt.oSort, {
    "num-html-pre": function ( a ) {
        var x = a.replace( /<.*?>/g, "" );
        return parseFloat( x );
    },
 
    "num-html-asc": function ( a, b ) {
        return ((a < b) ? -1 : ((a > b) ? 1 : 0));
    },
 
    "num-html-desc": function ( a, b ) {
        return ((a < b) ? 1 : ((a > b) ? -1 : 0));
    }
    } );
    $('#example').dataTable( {
            "sPaginationType": "full_numbers",
            "aoColumns": [
            null,
            null,
            { "sType": "num-html" },
            null,
            null,
            null,
            null
        ]
            } );
    } );
</script>
<div id="admin_container">
  <div style="text-transform:uppercase"><a href="<?php echo base_url();?>admin">Home</a></div>
  <div style="clear: both">&nbsp;</div>
    <table style="width:975px;" border="0" cellspacing='0' cellpadding='0' >
        <tr><td><b>Billing Archive</b></td></tr>
        <tr><td colspan="2">&nbsp;</td></tr>
        <tr><td colspan="2">&nbsp;</td></tr>
        <tr><td colspan="2">
              <table cellspacing="0" cellpadding="0" border="0" style="width:975px;" id="example" class="display">
                <thead>
                  <tr>
                    <th align="center">S.No.</th>
                    <th align="middle">Treatment ID</th>
                    <th align="center">Amount Paid (US$)</th>
                    <th align="center">Date</th>
                    <th align="center">Time</th>
                    <th align="center">Transaction ID</th>
                    <th align="center">Action</th>
                  </tr>
                </thead>
                <tbody>
                  <?php if($result)
                    {	$i=0;
                        foreach($result as $row):
                  ?>
                  <tr>
                    <td align="center"><?php echo $i+=1;?></td>
                    <td align="middle"><?php echo $row['treatment_uin']?></td>
                    <td align="center"><font color="red"><?php echo $row['total_amount_paid']?></font></td>
                    <td align="center"><?php echo $row['date']?></td>
                    <td align="center"><?php echo $row['time']?></td>
                    <td align="center"><code><?php echo $row['transaction_id']?></code></td>
                      <td align="center"><?php echo anchor('admin/billing_detail/'.base64_encode($row['patient_checkup_id']).'/'.base64_encode($row['patient_id']), 'View')?></td>
                  </tr>
                  <?php endforeach;
                    }
                    //else
                        //echo '<tr><td colspan="5">No Record Found.</td></tr>';
                 ?>
                </tbody>
              </table>
              </td></tr>
    </table>  
</div>
<?php $this->load->view('admin/footer'); ?>
