<?php $this->load->view('admin/header'); ?>
<script type="text/javascript" charset="utf-8">
	$(document).ready(function() {
	$('#example').dataTable( {
		"sPaginationType": "full_numbers"
		} );
	} );
</script>

<div id="admin_container">
  <div style="text-transform:uppercase"><a href="<?php echo base_url();?>admin">Home</a>-><a href="<?php echo base_url();?>admin/patient_list">Patient List</a></div>
  <div>&nbsp;</div>
  <table style="width:975px;" border="0" cellspacing='0' cellpadding='0' >
    <tr>
      <td><b>Patient Details</b></td>
    </tr>
    <tr>
      <td colspan="2">&nbsp;</td>
    </tr>
    <tr>
      <td colspan="2" align="center" class="error"><?php echo ($this->session->flashdata('show_message')!='')? $this->session->flashdata('show_message') : ''; ?></td>
    </tr>
    <tr>
      <td colspan="2">&nbsp;</td>
    </tr>
    <tr>
      <td align="left" width="50%">
      	<table cellspacing="5" cellpadding="5" border="0" width="100%">
          <tr>
            <td colspan="2"><b>Patient Information</b></td>
          </tr>
          <tr>
            <td>First Name</td>
            <td><?php echo $result->first_name ?></td>
          </tr>
           <tr>
            <td>Middle Name</td>
            <td><?php echo $result->middle_initial ?></td>
          </tr>
           <tr>
            <td>Last Name</td>
            <td><?php echo $result->last_name ?></td>
          </tr>
           <tr>
            <td>Email</td>
            <td><?php echo $result->email ?></td>
          </tr>
           <tr>
            <td>Username</td>
            <td><?php echo $result->username ?></td>
          </tr>
           <tr>
            <td>Registration Date</td>
            <td><?php echo $result->registration_date ?></td>
          </tr>
          <tr>
            <td>Gender</td>
            <td><?php echo $result->p_sex ?></td>
          </tr>
          <tr>
            <td>Marital Status</td>
            <td><?php echo ($result->p_marital_status)? ($result->p_marital_status==4)? $result->p_marital_status_other : $result->p_marital_status : '' ?></td>
          </tr>
          <tr>
            <td>Socail Security No.</td>
            <td><?php echo $result->p_ssn ?></td>
          </tr>
          <tr>
            <td>Driving License</td>
            <td><?php echo $result->p_dln ?></td>
          </tr>
          <tr>
            <td>Date of Birth</td>
            <td><?php echo $result->p_dob ?></td>
          </tr>
          <tr>
            <td>Address</td>
            <td><?php echo $result->p_address_street.'<br/>'.$result->p_address_apartment_number ?></td>
          </tr>
          <tr>
            <td>City</td>
            <td><?php echo $result->p_address_city ?></td>
          </tr>
          <tr>
            <td>State</td>
            <td><?php echo $result->p_address_state_id ?></td>
          </tr>
          <tr>
            <td>Zip Code</td>
            <td><?php echo $result->p_address_zipcode ?></td>
          </tr>
          <tr>
            <td>Phone</td>
            <td><?php echo ($result->p_phone_home)? $result->p_phone_home.' (H)' : ''; echo ($result->p_phone_work)? $result->p_phone_work.' (O)' : ''?></td>
          </tr>
          <tr>
            <td>Mobile</td>
            <td><?php echo $result->p_phone_cell ?></td>
          </tr>
          <tr>
            <td>Practice Reference</td>
            <td><?php echo $result->p_practice_reference ?></td>
          </tr>
          <tr>
            <td>Health Condition</td>
            <td><?php echo $result->p_health_condition ?></td>
          </tr>
          <tr>
            <td>Other Medicines</td>
            <td><?php echo $result->p_other_medicines ?></td>
          </tr>
          <tr>
            <td>Total Insurance</td>
            <td><?php echo $result->p_total_insurance ?></td>
          </tr>
          <tr>
            <td colspan="2"><b>Spouse or Responsible Party Information</b></td>
          </tr>
          <tr>
            <td>Details For</td>
            <td><?php echo $result->srp_following_is_for ?></td>
          </tr>
          <tr>
            <td>First Name</td>
            <td><?php echo $result->srp_first_name ?></td>
          </tr>
          <tr>
            <td>Middle name</td>
            <td><?php echo $result->srp_middle_initial ?></td>
          </tr>
          <tr>
            <td>Last name</td>
            <td><?php echo $result->srp_last_name ?></td>
          </tr>
          <tr>
            <td>Gender</td>
            <td><?php echo $result->srp_sex ?></td>
          </tr>
          <tr>
            <td>Marital Status</td>
             <td><?php echo ($result->srp_marital_status)? ($result->srp_marital_status==4)? $result->srp_marital_status_other : $result->srp_marital_status : '' ?></td>
          </tr>
          <tr>
            <td>Social Security No.</td>
            <td><?php echo $result->srp_ssn ?></td>
          </tr>
          <tr>
            <td>Date of Birth</td>
            <td><?php echo $result->srp_dob ?></td>
          </tr>
          <tr>
            <td>Address</td>
            <td><?php echo $result->srp_address_street.'<br/>'.$result->srp_address_apartment_number ?></td>
          </tr>
          <tr>
            <td>City</td>
            <td><?php echo $result->srp_address_city ?></td>
          </tr>
          <tr>
            <td>State</td>
            <td><?php echo $result->srp_address_state_id ?></td>
          </tr>
          <tr>
            <td>Zip Code</td>
            <td><?php echo $result->srp_address_zipcode ?></td>
          </tr>
          <tr>
            <td>Phone</td>
            <td><?php echo ($result->srp_phone_home)? $result->srp_phone_home.' (H)' : ''; echo ($result->srp_phone_work)? $result->srp_phone_work.' (O)' : ''?></td>
          </tr>
          <tr>
            <td>Phone Ext</td>
            <td><?php echo $result->srp_phone_ext ?></td>
          </tr>
          <tr>
            <td>Best Time To Call</td>
            <td><?php echo $result->srp_best_time_call ?></td>
          </tr>
          <tr>
            <td colspan="2"><b>Employment Information</b></td>
          </tr>

          <tr>
            <td>Details For</td>
            <td><?php echo $result->e_following_is_for ?></td>
          </tr>
          <tr>
            <td>Employer's Name </td>
            <td><?php echo $result->e_name ?></td>
          </tr>
          <tr>
            <td>Occupation</td>
            <td><?php echo $result->e_occupation ?></td>
          </tr>
          <tr>
            <td>Address</td>
            <td><?php echo $result->e_address_street ?></td>
          </tr>
          <tr>
            <td>City</td>
            <td><?php echo $result->e_address_city ?></td>
          </tr>
          <tr>
            <td>State</td>
            <td><?php echo $result->e_address_state_id ?></td>
          </tr>
          <tr>
            <td>Zip Code</td>
            <td><?php echo $result->e_address_zipcode ?></td>
          </tr>
        </table></td>
      <td align="right" style="vertical-align:top;"><table cellspacing="5" cellpadding="5" border="0" width="100%">
          <tr>
            <td colspan="2"><b>Insurance Information - Primary Insurance</b></td>
          </tr>
          <tr>
            <td>First Name</td>
            <td><?php echo $result->pi_first_name ?></td>
          </tr>
          <tr>
            <td>Middle name</td>
            <td><?php echo $result->pi_middle_initial ?></td>
          </tr>
          <tr>
            <td>Last name</td>
            <td><?php echo $result->pi_last_name ?></td>
          </tr>
          <tr>
            <td>Is insured a patient</td>
            <td><?php echo $result->pi_is_insured_patient ?></td>
          </tr>
          <tr>
            <td>Insured's Birth Date</td>
            <td><?php echo $result->pi_dob ?></td>
          </tr>
          <tr>
            <td>ID # </td>
            <td><?php echo $result->pi_id ?></td>
          </tr>
          <tr>
            <td>Group #</td>
            <td><?php echo $result->pi_group ?></td>
          </tr>
          <tr>
            <td>Address</td>
            <td><?php echo $result->pi_address_street ?></td>
          </tr>
          <tr>
            <td>City</td>
            <td><?php echo $result->pi_address_city ?></td>
          </tr>
          <tr>
            <td>State</td>
            <td><?php echo $result->pi_address_state_id ?></td>
          </tr>
          <tr>
            <td>Zip Code</td>
            <td><?php echo $result->pi_address_zipcode ?></td>
          </tr>
          <tr>
            <td>Insured's Employer Name </td>
            <td><?php echo $result->pi_emp_name ?></td>
          </tr>
          <tr>
            <td>Insured's Employer Address</td>
            <td><?php echo $result->pi_emp_address_street ?></td>
          </tr>
                    <tr>
            <td>City</td>
            <td><?php echo $result->pi_emp_address_city ?></td>
          </tr>
          <tr>
            <td>State</td>
            <td><?php echo $result->pi_emp_address_state_id ?></td>
          </tr>
          <tr>
            <td>Zip Code</td>
            <td><?php echo $result->pi_emp_address_zipcode ?></td>
          </tr>
 <tr>
            <td>Patient's relationship to insured</td>
            <td><?php echo $result->pi_patient_relation ?></td>
          </tr> <tr>
            <td>Ins. Plan Name and Address</td>
            <td><?php echo $result->pi_insurance_plan_address ?></td>
          </tr>
                    <tr>
            <td colspan="2"><b>Insurance Information - Secondry Insurance</b></td>
          </tr>
          <tr>
            <td>First Name</td>
            <td><?php echo $result->si_first_name ?></td>
          </tr>
          <tr>
            <td>Middle name</td>
            <td><?php echo $result->si_middle_initial ?></td>
          </tr>
          <tr>
            <td>Last name</td>
            <td><?php echo $result->si_last_name ?></td>
          </tr>
          <tr>
            <td>Is insured a patient</td>
            <td><?php echo $result->si_is_insured_patient ?></td>
          </tr>
          <tr>
            <td>Insured's Birth Date</td>
            <td><?php echo $result->si_dob ?></td>
          </tr>
          <tr>
            <td>ID # </td>
            <td><?php echo $result->si_id ?></td>
          </tr>
          <tr>
            <td>Group #</td>
            <td><?php echo $result->si_group ?></td>
          </tr>
          <tr>
            <td>Address</td>
            <td><?php echo $result->si_address_street ?></td>
          </tr>
          <tr>
            <td>City</td>
            <td><?php echo $result->si_address_city ?></td>
          </tr>
          <tr>
            <td>State</td>
            <td><?php echo $result->si_address_state_id ?></td>
          </tr>
          <tr>
            <td>Zip Code</td>
            <td><?php echo $result->si_address_zipcode ?></td>
          </tr>
          <tr>
            <td>Insured's Employer Name </td>
            <td><?php echo $result->si_emp_name ?></td>
          </tr>
          <tr>
            <td>Insured's Employer Address</td>
            <td><?php echo $result->si_emp_address_street ?></td>
          </tr>
                    <tr>
            <td>City</td>
            <td><?php echo $result->si_emp_address_city ?></td>
          </tr>
          <tr>
            <td>State</td>
            <td><?php echo $result->si_emp_address_state_id ?></td>
          </tr>
          <tr>
            <td>Zip Code</td>
            <td><?php echo $result->si_emp_address_zipcode ?></td>
          </tr>
 <tr>
            <td>Patient's relationship to insured</td>
            <td><?php echo $result->si_patient_relation ?></td>
          </tr> <tr>
            <td>Ins. Plan Name and Address</td>
            <td><?php echo $result->si_insurance_plan_address ?></td>
          </tr>

        </table></td>
    </tr>
  </table>
</div>
<?php $this->load->view('admin/footer'); ?>
