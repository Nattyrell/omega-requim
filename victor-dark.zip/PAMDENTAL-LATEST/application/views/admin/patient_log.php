<?php $this->load->view('admin/header'); ?>
<script type="text/javascript" charset="utf-8">
	$(document).ready(function() {
	$('#example').dataTable( {
		"sPaginationType": "full_numbers"
		} );
	} );
</script>

<style type="text/css">
    legend {
        font-size: 1.2em;
        font-weight: bold;
    }
    fieldset {
        border: 1px solid #13A7CD;
        padding: 0 1.4em 1.4em;
        width: 75%;
    }
    th {
        background: none repeat scroll 0 0 #C3D9FF;
        font-weight: bold;
    }
</style>
<?php
    /*TEST VARIABLES HERE -*/
    //echo '<pre>';
    //print_r($patient_data);
    //echo '</pre>'; 
?>
<div id="admin_container">
  <div style="text-transform:uppercase"><a href="<?php echo base_url();?>admin">Home</a>-><a href="<?php echo base_url();?>admin/patient_list">Patient List</a></div>
  <div style="padding-top: 10px">
    <fieldset>
      <legend>Patient Details</legend>
      <table name="patient-log" id="patient-log" width="50%" cellspacing="5" cellpadding="10">
          <tr>
              <th>PATIENT NAME:&nbsp;</th>
              <td><?php echo $patient_data['name']?></td>
          </tr>
          <tr>
              <td colspan="2">&nbsp;</td>
          </tr>
          <tr>
              <th>PATIENT UIN:</th>
              <td><?php echo $patient_data['patient_uin']?></td>
          </tr>
          <tr>
              <td colspan="2">&nbsp;</td>
          </tr>
          <tr>
              <th>GUARANTOR NAME AND MAILING ADDRESS:</th>
              <td>
                <?php 
                    echo $guarantor_data['name'].br(1);
                    $states = array();
                      foreach($us_states->result_array() AS $row){
                          $states[$row['id']] = $row['state'];
                      }
                      $contact_address = $guarantor_data['p_address_apartment_number'].nbs(1).$guarantor_data['p_address_street'].', '.$guarantor_data['p_address_city'].nbs(1).$states[$guarantor_data['p_address_state_id']].nbs(1).$guarantor_data['p_address_zipcode'];
                    echo $contact_address;
                ?>
              </td>
          </tr>
      </table>
    </fieldset>
  <div style="clear: both; padding-top: 25px"></div>
    <table style="width:975px;" border="0" cellspacing='0' cellpadding='0' >
	    <tr>
            <td>
                <font style="font-size: 1.2em;  font-weight: bold;">Patient Log</font>
            </td>
        </tr>
        <tr><td colspan="2">&nbsp;</td></tr>
        <tr><td colspan="2" align="center" class="error"><?php echo ($this->session->flashdata('show_message')!='')? $this->session->flashdata('show_message') : ''; ?></td></tr>
        <tr><td colspan="2">&nbsp;</td></tr>
        <tr><td>
              <table cellspacing="0" cellpadding="0" border="0" style="width:975px;" id="example" class="display">
                <thead>
                  <tr>
                    <th align="center">S.No.</th>
                    <!--<th align="center">Patient Name</th>-->
                    <th align="center">IP Address</th>
                    <th align="center">User Agent</th>
                    <th align="center">Date</th>
                    <th align="center">Activity</th>
                  </tr>
                </thead>
                <tbody>
                  <?php if($result)
                    {	$i=0;
                        foreach($result->result() as $row):
              ?>
                  <tr>
                    <td align="left"><?php echo $i+=1;?></td>
                    <!--<td align="center"><?php echo $row->patient_id;?></td>-->
                    <td align="center"><?php echo $row->ip_address;?></td>
                    <td align="center"><?php echo $row->http_user_agent;?></td>
                    <td align="center"><?php echo date('d F Y g:i A',strtotime($row->datetime));?></td>
                    <td align="center"><?php echo $row->activity;?></td>
                  </tr>
                  <?php endforeach;
                    }
                    else
                        echo '<tr><td colspan="5">No Record Found.</td></tr>';
                 ?>
                </tbody>
              </table>
                </td></tr>
    </table>  
</div>
<?php $this->load->view('admin/footer'); ?>