<?php $this->load->view('admin/header'); ?>
<script type="text/javascript" charset="utf-8">
	$(document).ready(function() {
	$('#example').dataTable( {
		"sPaginationType": "full_numbers"
		} );
	} );
</script>

<div id="admin_container">
  <div style="text-transform:uppercase"><a href="<?php echo base_url();?>admin">Home</a></div>
  <div>&nbsp;</div>
<table style="width:975px;" border="0" cellspacing='0' cellpadding='0' >
	<tr><td><b>Teeth List</b></td></tr>
    <tr><td colspan="2">&nbsp;</td></tr>
    <tr><td colspan="2" align="center" class="error"><?php echo ($this->session->flashdata('show_message')!='')? $this->session->flashdata('show_message') : ''; ?></td></tr>
    <tr><td colspan="2">&nbsp;</td></tr>
    <tr><td colspan="2">
          <table cellspacing="0" cellpadding="0" border="0" style="width:975px;" id="example" class="display">
    <thead>
      <tr>
        <th align="center">S.No.</th>
        <th align="center">Description</th>
      <!--  <th align="center">Action</th>-->
      </tr>
    </thead>
    <tbody>
      <?php if($result)
  		{
			foreach($result->result() as $row):
  ?>
      <tr>
        <td align="center"><?php echo $row->tooth_id ;?></td>
        <td align="center"><?php echo $row->description;?></td>
       <?php /*?> <td align="center"><a href="<?php echo base_url();?>dolphin7534/addproblems/<?php echo $row->tooth_id;?>">Edit</a></td><?php */?>
      </tr>
      <?php endforeach;
		}
		else
			echo '<tr><td colspan="5">No Record Found.</td></tr>';
	 ?>
            </tbody>
          </table>
            </td></tr>
</table>  
</div>
<?php $this->load->view('admin/footer'); ?>