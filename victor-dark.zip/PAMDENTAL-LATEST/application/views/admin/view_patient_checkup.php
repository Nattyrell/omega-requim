<?php $this->load->view('admin/header'); ?>
<script type="text/javascript" charset="utf-8">
    $(document).ready(function(){
        $('#example').dataTable({
            "sPaginationType": "full_numbers"
         });
    });
</script>

<div id="admin_container">
  <div style="text-transform:uppercase"><a href="<?php echo base_url();?>admin">Home</a></div>
  <div style="clear: both; padding-top: 25px"></div>
  <b>Patient Checkups</b><br/><br/>
    <table border="0" cellspacing='0' cellpadding='0' id="example" class="display" style="width:100%;">
        <thead>
            <tr>
                <th align="center">S.No.</th>
                <th>Treatment ID</th>
                <th align="center">Date</th>
                <th align="center">Time</th>
                <th align="center">Status</th>
                <th align="center">Action</th>
            </tr>
        </thead>
        <tbody>
          <?php if($result){ $i=0; foreach($result as $row):?>
          <tr>
                <td align="center"><?php echo $i+=1;?></td>
                <td align="center"><?php echo $row['treatment_uin']?></td>
                <td align="center"><?php echo $row['date']?></td>
                <td align="center"><?php echo $row['time']?></td>
                <td align="center"><?php echo $row['status']?></td>
                <td align="center">
                    <?php echo anchor('admin/view-patient-checkup-detail/'.base64_encode($row['patient_checkup_id']).'/'.base64_encode($row['patient_id']), 'View')?>
                </td>
          </tr>
          <?php endforeach;} //else echo '<tr><td colspan="5" align="center">No Record Found.</td></tr>'; ?>
        </tbody>
    </table>
</div>
<?php $this->load->view('admin/footer'); ?>