<div id="footer">
    <table cellpadding="0" cellspacing="0" border="0" style="margin-bottom:0px !important;">
        <tr>
            <td align="right" style="text-align:right !important">
                <!--          <a href="http://www.PositiveSSL.com" title="SSL Certificate Authority" target="_blank"><img src="--><?php //echo base_url() ?><!--images/SSL Image.gif" alt="SSL Certificate Authority" title="SSL Certificate Authority" align="middle"/></a>-->
                <span id="siteseal"><script type="text/javascript" src="https://seal.godaddy.com/getSeal?sealID=LNDzjeMpZTSKDrENE4ItlLGoaFCOVXHCdytyaHyRO8HqmjNrnUSGu"></script></span>
            </td>
            <td align="left">&copy; 2012 PAM DENTAL<br/>
                All Rights Reserved.<br/></td>
        </tr>
    </table>
</div>
<!-- footer -->

</div>
<!-- page -->
</body>
</html>