<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<meta name="language" content="en" />
	<title><?php echo url_title(@$title);?></title>
	<link rel="stylesheet" type="text/css" href="<?php echo base_url()?>/css/front/screen.css" media="screen, projection" />
	<link rel="stylesheet" type="text/css" href="<?php echo base_url()?>/css/front/print.css" media="print" />
	<!--[if lt IE 8]>
	<link rel="stylesheet" type="text/css" href="<?php echo base_url()?>/css/front/ie.css" media="screen, projection" />
	<![endif]-->

	<link rel="stylesheet" type="text/css" href="<?php echo base_url()?>/css/front/main.css" />
	<link rel="stylesheet" type="text/css" href="<?php echo base_url()?>/css/front/form.css" />
    <link rel="stylesheet" type="text/css" href="<?php echo base_url()?>/css/front/plugins/buttons/screen.css" />
</head>

<body>

<div class="container" id="page">

	<div id="header">
		<div id="logo">PAM DENTAL</div>
	</div><!-- header -->

	<div id="mainmenu">
                <ul>
       		<li>&nbsp;</li>
        </ul>	
        </div><!-- mainmenu -->


<div id="content">
    <form name="dentist-forgot-password-form" id="dentist-forgot-password-form" method="post" action="<?php echo base_url()?>dentist/forgot-password" enctype="multipart/form-data">
    <fieldset>
        
        <legend>Forgot Password?</legend>
        <div style="float: left; width: 150px"><label>ENTER PAM USERNAME<font color="#FF2437">*</font></label></div>
        <div style="float: left; width: 250px"><input type="text" id="username" name= "username" maxlength="255" size="32" value="<?php echo set_value('email'); ?>"/></div>
        <div style="float: left; width: 250px"><font size=2 color="#FF2437"><?php echo form_error('username')?></font></div>
        
        <div style="clear: both; padding-top: 25px"></div>
        
        
        <div style="float: left; width: 150px">&nbsp;</div>
        <div style="float: left; width: 250px"><input type="submit" name="submit" id="submit" value="Proceed"/></div>
        <div style="float: left; width: 250px">&nbsp;</div>
        
        
    </fieldset>
    </form>
    
</div>
<?php $this->load->view('frontoffice/frontoffice_footer');?>