<?php $this->load->view('dentist/dentist_header');?>
<script type="text/javascript" charset="utf-8">
 $(document).ready(function() {
 $('#example').dataTable( {
     "bJQueryUI": true,
     "sPaginationType": "full_numbers"
  } );
 } );
</script>

<div id="content">
  <h2>Patient List</h2>
  <table border="0" cellspacing='0' cellpadding='0' id="example" class="display" style="width:100%;">
    <thead>
      <tr>
        <th>S.NO</th>
        <th>PATIENT UIN</th>
        <th>NAME</th>
        <th>ACTION</th>
      </tr>
    </thead>
    <tbody>
      <?php 
            $i=1;
            foreach ($patients as $row)
        {	
                     ?>
      <tr>
        <td align='center'><?php echo $i; ?></td>
        <td><?php echo $row->patient_uin?></td>
        <td align='center'><?php echo $row->first_name." ".$row->last_name;?></td>
        <td align='center'><?php echo anchor('dentist/submit-application/'.$row->patient_id, 'Apply Treatment').nbs(1).'|'.nbs(1).anchor('dentist/patient-detail/'.base64_encode($row->patient_id), 'View Profile'); ?></td>
      </tr>
      <?php $i++;  } ?>
    </tbody>
  </table>
</div>
<?php $this->load->view('dentist/dentist_footer');?>
