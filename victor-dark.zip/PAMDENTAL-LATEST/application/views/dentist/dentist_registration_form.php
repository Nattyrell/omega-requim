<?php $this->load->view('patient/patient_header');?>
<script type ="text/javascript">
	$(function() {
		$( "#datepicker" ).datepicker({
			showOn: "button",
			buttonImage: "<?php echo base_url()?>images/patient/datepicker/calendar.gif",
			buttonImageOnly: true
		});
	});
</script>
<style type="text/css">#ui-datepicker-div{font-size: 62.5%;}</style>
        
<div style ="margin-left: 10px; margin-right: 10px; width: 700px">
    
    <div style="clear: both; padding-top: 10px"></div>
    <?php 
        //echo '<h1>COMING SOON .....</h1>';
    ?>
    
    <fieldset>
        <legend>Patient Information</legend>
        
        <div style="clear: both; padding-top: 10px"></div>
        
        <div style="float: left">
            <label>First Name</label>
            <input type="text" id="first-name" name= "first-name" maxlength="255" size="16" value="<?php echo set_value('first-name'); ?>"/>
        </div>
        <div style="float: left; padding-left: 5px">
            <label>Last Name</label>
            <input type="text" id="last-name" name= "last-name" maxlength="255" size="16" value="<?php echo set_value('last-name'); ?>"/>
        </div>
        <div style="float: left; padding-left: 5px">
            <label>MI</label>
            <input type="text" id="middle-initial" name= "middle-initial" maxlength="1" size="4" value="<?php echo set_value('middle-initial'); ?>"/>
        </div>
        
        <div style="clear: both; padding-top: 10px"></div>
        
        <div style="float: left">
            <label>Date</label>
            <input type="text" id="datepicker">
        </div>
        
        <div style="clear: both; padding-top: 10px"></div>
    </fieldset>
    
</div>
<?php $this->load->view('patient/patient_footer');?>
