<?php $this->load->view('patient/patient_header');?>

<div style ="margin-left: 150px; width: 700px">
    <form name="patient-sign-up-form" id="patient-sign-up-form" method="post" action="<?php echo base_url()?>patient/patient_sign_up" enctype="multipart/form-data">
    <fieldset>
        
        <legend>Create your personal account</legend>
        
        <div style="clear: both; padding-top: 25px"></div>
        
        <div style="float: left; width: 150px"><label>First Name<font color="#FF2437">*</font></label></div>
        <div style="float: left; width: 250px"><input type="text" id="first-name" name= "first-name" maxlength="255" size="16" value="<?php echo set_value('first-name'); ?>"/></div>
        <div style="float: left; width: 250px"><font size=2 color="#FF2437"><?php echo form_error('first-name')?></font></div>
        <div style="clear: both; padding-top: 5px"></div>
        
        <div style="float: left; width: 150px"><label>Last Name<font color="#FF2437">*</font></label></div>
        <div style="float: left; width: 250px"><input type="text" id="last-name" name= "last-name" maxlength="255" size="16" value="<?php echo set_value('last-name'); ?>"/></div>
        <div style="float: left; width: 250px"><font size=2 color="#FF2437"><?php echo form_error('last-name')?></font></div>
        <div style="clear: both; padding-top: 5px"></div>
        
        <div style="float: left; width: 150px"><label>Middle Initial</label></div>
        <div style="float: left; width: 250px"><input type="text" id="middle-initial" name= "middle-initial" maxlength="1" size="4" value="<?php echo set_value('middle-initial'); ?>"/></div>
        <div style="float: left; width: 250px"><font size=2 color="#FF2437"><?php echo form_error('middle-initial')?></font></div>
        
        <div style="clear: both; padding-top: 25px"></div>
        
        <div style="float: left; width: 150px"><label>Email address<font color="#FF2437">*</font></label></div>
        <div style="float: left; width: 250px"><input type="email" id="email" name= "email" maxlength="255" size="32" value="<?php echo set_value('email'); ?>"/></div>
        <div style="float: left; width: 250px"><font size=2 color="#FF2437"><?php echo form_error('email')?></font></div>
        
        <div style="clear: both; padding-top: 25px"></div>
        
        <div style="float: left; width: 150px"><label>PAM User ID <font color="#FF2437">*</font></label></div>
        <div style="float: left; width: 250px"><input type="text" id="username" name= "username" maxlength="255" size="32" value="<?php echo set_value('username'); ?>"/>&nbsp;<a href="#" class="someClass" title="User ID must be at least 6 characters long.">?</a></div>
        <div style="float: left; width: 250px"><font size=2 color="#FF2437"><?php echo form_error('username')?></font></div>
        
        <div style="clear: both; padding-top: 25px"></div>
        
        <div style="float: left; width: 150px"><label>Password<font color="#FF2437">*</font></label></div>
        <div style="float: left; width: 250px"><input type="password" id="password" name= "password" maxlength="255" size="32" value="<?php echo set_value('password'); ?>"/></div>
        <div style="float: left; width: 250px"><font size=2 color="#FF2437"><?php echo form_error('password')?></font></div>
        
        <div style="clear: both; padding-top: 25px"></div>
        
        <div style="float: left; width: 150px"><label>Confirm Password<font color="#FF2437">*</font></label></div>
        <div style="float: left; width: 250px"><input type="password" id="confirm-password" name= "confirm-password" maxlength="255" size="32" value="<?php echo set_value('confirm-password'); ?>"/></div>
        <div style="float: left; width: 250px"><font size=2 color="#FF2437"><?php echo form_error('confirm-password')?></font></div>
        
        <div style="clear: both; padding-top: 25px"></div>
        
        <div style="float: left; width: 150px"><input type="submit" name="submit" id="submit" value="Proceed"/></div>
        
        
    </fieldset>
    </form>
    
    <div style="clear: both; padding-top: 10px"></div>
    
    <div align="middle" style="float:left; width:500px"><p>Existing users, click <a href="<?php echo base_url()?>patient">here</a> to Login</p></div>
</div>
<?php $this->load->view('patient/patient_footer');?>
