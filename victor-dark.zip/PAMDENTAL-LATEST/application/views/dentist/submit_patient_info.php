<?php $this->load->view('dentist/dentist_header');?>
<script type="text/javascript">
	function get_ada_treatment(ada_id,set,treat_id)
	{
		$.post("<?php echo base_url();?>dentist/get_treatment/",{ada_id : ""+ada_id+"",treat_id : ""+treat_id+""},function(data){
							document.getElementById('treatment_'+set).innerHTML=data;
		});
	}
		
	function add_more_teeth()
	{
		var ni = document.getElementById('myDiv');
		var currtime = new Date().getTime();
		var numi = document.getElementById('theValue');
		var num = (document.getElementById("theValue").value-1)+2;
		numi.value = num;
		
		var divIdName = 'tbl_translation'+num;
		var newdiv = document.createElement('div');
		newdiv.setAttribute("id",divIdName);
		newdiv.setAttribute("class","job_form");
		
		$.post("<?php echo base_url();?>dentist/get_set/",{set_id : ""+num+""},function(data){
							newdiv.innerHTML=data;
					});
							
		ni.appendChild(newdiv);
	}

	function removeElement(divNum)
	{
		var d = document.getElementById('myDiv');
		var image_val=document.getElementById('theValue').value;
		image_val=image_val-1;
		document.getElementById('theValue').value=image_val;
		var olddiv = document.getElementById(divNum);
		d.removeChild(olddiv);
	}
</script>
<script type="text/javascript">
    $(document).ready(function() {
        $('#timepicker').jtimepicker({
            "hourMode": 10,
            "secView": false,
            "clockIcon": '<?php echo base_url()?>images/timepicker/icon_clock_1.gif'
        });
    });
</script>
<?php  //echo '<pre>';print_r($_POST);?>
<div id="content">
    <div style="float:left"><?php echo ($error!='')? '<div class="error">'.$error.'</div>' : ''; ?></div>
    <div style="clear:both"></div>
    <div style="float:left"><?php echo ($this->session->flashdata('treatment_rec_msg'))? '<div class="error">'.$this->session->flashdata('treatment_rec_msg').'</div>' : ''; ?></div>
    <div style="clear:both"></div>
  <form name="patient_info_form" id="patient_info_form" method="post" action="<?php echo base_url()?>dentist/submit-application/<?php echo $this->uri->segment(3)?>">
    <table border="0" cellspacing='5' cellpadding='5' style="width:950px;" class="bottom">
      <tr>
        <th>Teeth</th>
        <th>ADA Code</th>
        <th colspan="2">Description</th>
      </tr>
      <?php $set = 1; ?>
      <tr>
        <td>
            <select name="teeth[]" id="teeth[0]">
            <option value=' ' select='selected'><?php echo 'Please Select Teeth'; ?></option>
            <?php foreach($teeth as $row) :?>
                    <option value="<?php echo $row->tooth_id; ?>" <?php echo (@$_POST['teeth'][0]==$row->tooth_id)? 'selected="selected"' : '' ?>><?php echo $row->tooth_id; ?></option>
            <?php endforeach; ?>
            </select>
        </td>
        <td>
            <select name="ada_codes[]" onchange='get_ada_treatment(this.value,0);'>
            <option value=' ' select='selected'><?php echo 'Select ADA code'; ?></option>
            <?php foreach($ada_codes as $row) :?>
            <option value="<?php echo $row->ada_code_id; ?>" <?php echo (@$_POST['ada_codes'][0]==$row->ada_code_id)? 'selected="selected"' : '' ?>><?php echo $row->ada_code; ?></option>
            <?php endforeach; ?>
            </select></td>
        <td>
            <select name="treatment[]" id="treatment_0" style="width:220px;">
            <option value=' ' select='selected'><?php echo 'Please Select'; ?></option>
            </select>
            <script>get_ada_treatment('<?php echo @$_POST['ada_codes'][0] ?>','0','<?php echo @$_POST['treatment'][0] ?>');</script>
        </td>
        <td><a href="javascript:void(0)" onclick="add_more_teeth();">Add Treatment</a></td>
      </tr>
    </table>
     <div id="myDiv" style="width:950px;">
       <?php 
		  if(isset($_POST['submit']) && $_POST['theValue']>1)
		  { 
		  	for($i=1;$i<$_POST['theValue'];$i++)
			{
			?>
            
            <table id="tbl_translation<?php echo $i; ?>" style="padding-bottom:0px;">
                <tr>
                	  <td>
                            <select name="teeth[]" id="teeth[]">
                                <option value=' ' select='selected'><?php echo 'Please Select Teeth'; ?></option>
                                <?php foreach($teeth as $row) :?>
                                    <option value="<?php echo $row->tooth_id; ?>" <?php echo ($_POST['teeth'][$i]==$row->tooth_id)? 'selected="selected"' : '' ?> ><?php echo $row->tooth_id; ?></option>
                                <?php endforeach; ?>
                           </select></td>
                        <td><select name="ada_codes[]" onchange='get_ada_treatment(this.value,<?php echo $i?>);'>
                            <option value=' ' select='selected'><?php echo 'Select ADA code'; ?></option>
                            <?php foreach($ada_codes as $row) :?>
                            <option value="<?php echo $row->ada_code_id; ?>" <?php echo (@$_POST['ada_codes'][$i]==$row->ada_code_id)? 'selected="selected"' : '' ?>><?php echo $row->ada_code; ?></option>
                            <?php endforeach; ?>
                          </select></td>
                        <td><select name="treatment[]" id="treatment_<?php echo $i;?>" style="width:220px;">
                            <option value=' ' select='selected'><?php echo 'Please Select'; ?></option>
                          </select></td>
                          <script>get_ada_treatment('<?php echo @$_POST['ada_codes'][$i]?>','<?php echo $i ?>','<?php echo @$_POST['treatment'][$i] ?>');</script>
                        <td><a style="cursor:pointer" href="#" onclick="removeElement('<?php echo 'tbl_translation'.$i; ?>')">Remove</a></td>  
                </tr>
             </table>   
            <?php	
			}
		  }
		  ?>
     </div>

    <table border="0" cellspacing='15' cellpadding='0' style="width:950px;">
      <tr>
        <td colspan=2>&nbsp;</td>
      </tr>
      <tr>
        <td><label><b>Notes</b></label></td>
        <td><label><b>Treatment Pros.</b></label></td>
      </tr>
      <tr>
        <td>
            <textarea name="notes" size="50" height="50" onfocus="if(this.value=='Enter Notes..'){this.value='';}" onblur="if(this.value==''){this.value='Enter Notes..'; }">Enter Notes..</textarea>
        </td>
        <td>
<!--            <textarea name="description" size="50" height="50" onfocus="if(this.value=='Enter Description..'){this.value='';}" onblur="if(this.value==''){this.value='Enter Description..'; }">Enter Description..</textarea>-->
            <textarea name="treatment_pros" size="50" height="50" onfocus="if(this.value=='Enter Treatment Pros...'){this.value='';}" onblur="if(this.value==''){this.value='Enter Treatment Pros...'; }">Enter Treatment Pros...</textarea>
        </td>
      </tr>
      <tr>
        <td colspan=2>&nbsp;</td>
      </tr>
      <tr>
        <td><label><b>Treatment Cons.</b></label></td>
        <td><label><b>Estimated Treatment Time <font color="RED">HH:MM<font></b></label></td>
      </tr>
      <td>
            <textarea name="treatment_cons" size="50" height="50" onfocus="if(this.value=='Enter Treatment Cons...'){this.value='';}" onblur="if(this.value==''){this.value='Enter Treatment Cons...'; }">Enter Treatment Cons...</textarea>
      </td>
      <td style="vertical-align: top"><div id="timepicker"></div></td>
      <tr>
        <td colspan=3>&nbsp;&nbsp;&nbsp;&nbsp; 
        <td>
		<input type="hidden" name="theValue"  value="<?php echo (@$_POST)? @$_POST['theValue'] : '1'; ?>" readonly="readonly" id="theValue" /></td>
		<input type="hidden" name='patient_id' id='patient_id' value="<?php echo $patient_id; ?>">
        </td>
      </tr>
      <tr>
        <td>
		<!--<input type="submit" name="submit" id="submit" value="Submit" />-->
		<button class="button positive" type="submit" name="submit">Submit</button>
	</td>
	<td>
		<!--<input type="submit" name="submit_and_return" id="submit_and_return" value="Submit & Add another Treatment Plan" />-->
		<button class="button positive" type="submit" name="submit_and_return">Submit & Add another Treatment Plan</button>
	</td>
      </tr>
    </table>
  </form>
</div>
<?php $this->load->view('dentist/dentist_footer');?>