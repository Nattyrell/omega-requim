<?php $this->load->view('dentist/dentist_header');?>
<script type="text/javascript" src="<?php echo base_url();?>js/dentist/jquery-1.4.4.js"></script>
<script type="text/javascript">
	function get_ada_treatment(ada_id)
		{
			$.post("<?php echo base_url();?>dentist/get_treatment/",{ada_id : ""+ada_id+""},function(data){
							document.getElementById('treatment').innerHTML=data;
					});

		}
</script>
		
<div id="content">
  <b> "Patient current procedure has been submitted Successfully." </b> </br>
  <?php echo anchor('dentist/home/', ' Back to Dentist Home '); ?>
	
</div>

<?php $this->load->view('dentist/dentist_footer');?>
