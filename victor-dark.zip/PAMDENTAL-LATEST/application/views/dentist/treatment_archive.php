<?php $this->load->view('dentist/dentist_header');?>
<script type="text/javascript" charset="utf-8">
		 $(document).ready(function() {
		 $('#example').dataTable( {
                     "bJQueryUI": true,
                     "sPaginationType": "full_numbers"
		  } );
		 } );
		</script>

<div id="content">
  <h2>Treatment Archive</h2>	
  <table border="0" cellspacing='0' cellpadding='0' id="example" class="display" style="width:100%;">
    <thead>
      <tr>
        <th align='center'>Sr.No.</th>
	<th align='center'>Treatment ID</th>
        <!--<th align='center'>Patient ID #</th>-->
	<th align='center'>Patient UIN</th>
        <th align='center'>Patient Name</th>
<!--        <th align='center'>First Name</th>
        <th align='center'>Last Name</th>
        <th align='center'>Middle Initial</th>-->
        <th align='center'>Date</th>
        <th align='center'>Time</th>
        <th align='center'>Status</th>
        <th align='center'>Action</th>
      </tr>
    </thead>
    <tbody>
      <?php 
        if($patient_checkups){
	$i=1;
	foreach ($patient_checkups as $row)
    {	
		 ?>
      <tr>
        <td align='center'><?php echo $i; ?></td>
        <!--<td align='center'><?php echo $row->patient_id ?></td>-->
	<td align='center'><?php echo $row->treatment_uin ?></td>
	<td align='center'><?php echo $row->patient_uin ?></td>
        <td align='center'><?php echo $row->name;?>
<!--        <td align='center'><?php echo $row->first_name;?></td>
        <td align='center'><?php echo $row->last_name;?></td>
        <td align='center'><?php echo $row->middle_initial;?></td>-->
        <td align='center'><?php echo $row->date; ?></td>
        <td align='center'><?php echo $row->time; ?></td>
        <td align='center'><?php echo $row->status;?></td>
        <td align='center'><?php echo anchor('dentist/view-treatment-archive/'.base64_encode($row->patient_checkup_id).'/'.base64_encode($row->patient_id), 'View'); ?></td>
      </tr>
      <?php $i++;  } 
        }
        //else echo '<tr><td align="center" colspan="9">There is no treatment available yet.</td></tr>';?>
    </tbody>
  </table>
</div>
<?php $this->load->view('dentist/dentist_footer');?>
