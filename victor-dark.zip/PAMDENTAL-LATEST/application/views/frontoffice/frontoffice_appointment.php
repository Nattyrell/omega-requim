<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<meta name="language" content="en" />
	<title>PAM DENTAL - Review AN APPOINTMENT</title>
	<link rel="stylesheet" type="text/css" href="<?php echo base_url()?>css/front/screen.css" media="screen, projection" />
	<link rel="stylesheet" type="text/css" href="<?php echo base_url()?>css/front/print.css" media="print" />
	<!--[if lt IE 8]>
	<link rel="stylesheet" type="text/css" href="<?php echo base_url()?>css/front/ie.css" media="screen, projection" />
	<![endif]-->

	<link rel="stylesheet" type="text/css" href="<?php echo base_url()?>css/front/main.css" />
	<link rel="stylesheet" type="text/css" href="<?php echo base_url()?>css/front/form.css" />
	<link rel="stylesheet" type="text/css" href="<?php echo base_url()?>css/front/plugins/buttons/screen.css" />
	<link rel='stylesheet' type='text/css' href='<?php echo base_url() ?>calendar/libs/css/smoothness/jquery-ui-1.8.11.custom.css' />
	<link rel="stylesheet" type="text/css" href="<?php echo base_url() ?>calendar/libs/jquery.weekcalendar.css" />
	<link rel="stylesheet" type="text/css" href="<?php echo base_url() ?>calendar/skins/default.css" />
	<link rel="stylesheet" type="text/css" href="<?php echo base_url() ?>calendar/skins/gcalendar.css" />
	<link rel="shortcut icon" type="image/x-icon" href="<?php echo base_url()?>images/favicon.ico" />
	<style type="text/css">
    #window_synchronize {
        width: 500px;
        height: 300px;
        margin: 0 auto;
        padding-left:10px;
        padding-top:10px;
        border: 3px solid #ccc;
        background: #ffffff;
        border-radius:5px;
        -moz-border-radius:5px;
        -webkit-border-radius:5px;
        position: fixed;
        top: 25%;
        left: 35%;
        line-height:24px;
        text-align:left;
        z-index:555;
    }
    
    #popup_synchronize {
        height: 100%;
        width: 100%;
        background: #000000;
        position:fixed;
        top: 0;
        left:0;
        -moz-opacity:0.5;
        -khtml-opacity: 0.5;
        opacity: 0.5;
        filter:alpha(opacity=50);
        z-index:550;
    }
    </style>
  <script type='text/javascript' src='<?php echo base_url() ?>calendar/libs/jquery-1.4.4.min.js'></script>
  <script type='text/javascript' src='<?php echo base_url() ?>calendar/libs/jquery-ui-1.8.11.custom.min.js'></script>
  <script type='text/javascript' src='<?php echo base_url() ?>calendar/libs/jquery-ui-i18n.js'></script>

  <script type="text/javascript" src="<?php echo base_url() ?>calendar/libs/date.js"></script>
  <script type="text/javascript" src="<?php echo base_url() ?>calendar/libs/jquery.weekcalendar.js"></script>
  <script type="text/javascript">
	$(document).ready(function() { 
  		$('#calendar_wrapper').weekCalendar({
			timeslotsPerHour : 4,    
			switchDisplay: {'Daily Calendar': 1, 'Weekly Calendar': 7},
			businessHours :{start: 0, end: 24, limitDisplay: true },
			allowCalEventOverlap : false,
     		overlapEventsSeparate: true,
			readonly: false,
			draggable : function(calEvent, $event) {
        		return true;
    		},
    		resizable : function(calEvent, $event) {
				//alert(JSON.stringify(calEvent));	
        		return true;
    		},
			eventDrop: function(calEvent, element) {
				var schedule_id = calEvent.id;
				var st = new Date(calEvent.start);
                var sm = parseInt(st.getMonth()) + 1;
                var visit_date = st.getFullYear() + '-' + sm + '-' + st.getDate() + '';
				var start_time = st.getHours() + ':' + st.getMinutes() + ':' + st.getSeconds();
				var et = new Date(calEvent.end);
				var end_time = et.getHours() + ':' + et.getMinutes() + ':' + et.getSeconds();
				var visit_type =  calEvent.visit_type;
				var visit_note =  calEvent.visit_note;
				var name = calEvent.patient_name;
                var patient_email = calEvent.patient_email;
				var data = 'schedule_id='+schedule_id+'&start_time='+start_time+'&end_time='+end_time+'&visit_date='+visit_date+'&visit_type='+visit_type+'&visit_note='+visit_note+'&patient_name='+name+'&patient_email='+patient_email;
				$.ajax({
					 type: "POST",
					 url: "<?php echo base_url();?>frontoffice/update_appointment",
					 data: data,
					 success: function(msg){
						 //alert(msg);
                         //if(msg==1)
                         id = parseInt(msg);
                         if(id)
								alert('Appointment successfully rescheduled.');
							else
								alert('Unsuccessful attempt. Please try again.');
						 $("#calendar_wrapper").weekCalendar('refresh');
					 }
		 		});
			},
			data:'<?php echo base_url() ?>frontoffice/get_appointment',  
	   		height:function($calendar){ 
      			 return $(window).height() - $("h1").outerHeight() - 1;
    		},
			eventRender : function(calEvent, $event) {
				// alert(JSON.stringify(calEvent));	
				 if ((calEvent.status == 'Reviewed')) {
					$event.css("backgroundColor", "green");
					$event.find(".wc-time").css({
					   "backgroundColor" : "green",
					   "border" : "1px solid #888"
					});
				 }
			  },
			// Function for adding new appointment
    		eventNew:function(calEvent, $event) { $('#calendar_wrapper').weekCalendar("removeUnsavedEvents");return false;},
			eventResize: function(calEvent, element) {
				var schedule_id = calEvent.id;
				var st = new Date(calEvent.start);
                var sm = parseInt(st.getMonth()) + 1;
                var visit_date = st.getFullYear() + '-' + sm + '-' + st.getDate() + '';
				var start_time = st.getHours() + ':' + st.getMinutes() + ':' + st.getSeconds();
				var et = new Date(calEvent.end);
				var end_time = et.getHours() + ':' + et.getMinutes() + ':' + et.getSeconds();
				var visit_type =  calEvent.visit_type;
				var visit_note =  calEvent.visit_note;
				var name = calEvent.patient_name;
                var patient_email = calEvent.patient_email;
                var data = 'schedule_id='+schedule_id+'&start_time='+start_time+'&end_time='+end_time+'&visit_date='+visit_date+'&visit_type='+visit_type+'&visit_note='+visit_note+'&patient_name='+name+'&patient_email='+patient_email;
				$.ajax({
					 type: "POST",
					 url: "<?php echo base_url();?>frontoffice/update_appointment",
					 data: data,
					 success: function(msg){
                         id = parseInt(msg);
                         if(id)
								alert('Appointment successfully rescheduled.');
							else
								alert('Unsuccessful attempt. Please try again.');
							$("#calendar_wrapper").weekCalendar('refresh');
					 }
		 		});
        	},
			noEvents : function() {},
			eventClick:function(calEvent, $event) {
				// alert(JSON.stringify(calEvent));	
				 review(calEvent.id)
				 document.getElementById('patient_name').value = calEvent.patient_name; 
				 document.getElementById('visit_date').value = calEvent.visit_date;
				 document.getElementById('visit_type').value = calEvent.visit_type;
				 document.getElementById('start_time').value = calEvent.start_time;
				 document.getElementById('end_time').value = calEvent.end_time;
				 document.getElementById('visit_note').value = calEvent.visit_note;
				 document.getElementById('patient_email').value = calEvent.patient_email;
			}
  		});
		
	});
	
	function review(schedule_id)
	{
		$('#window_synchronize').show('show');
		$('#popup_synchronize').show('show');
		document.getElementById('schedule_id').value =schedule_id;
	}
	
	function hides()
	{
		$('#window_synchronize').hide(1000);
		$('#popup_synchronize').hide(1000);
	}
	
	function review_status()
	{
		var schedule_id = $('#schedule_id').val();
		var note = $('#note').val();
		var status = $('#status').val();
		var data = 'schedule_id='+schedule_id+'&note='+note+'&status='+status+'&patient_name='+$('#patient_name').val()+'&patient_email='+$('#patient_email').val()+'&visit_date='+$('#visit_date').val()+'&start_time='+$('#start_time').val()+'&end_time='+$('#end_time').val()+'&visit_type='+$('#visit_type').val();
		$.ajax({
  				 type: "POST",
   				 url: "<?php echo base_url();?>frontoffice/review_status",
   				 data: data,
   			 	 success: function(msg){
    		 			alert(msg);
						hides();
						$("#calendar_wrapper").weekCalendar('refresh');
 			 	 }
		 });
	}
</script>
<script type="text/JavaScript">
function timedRefresh(timeoutPeriod) {
    setTimeout("location.reload(true);",timeoutPeriod);
    }
</script>

</head>

<body onload="JavaScript:timedRefresh(60000);"> <!--REFRESH PAGE AFTER EVERY 60 SECONDS-->

<div class="container" id="page">
	<?php
		$query=$this->db->get('dentist_login');
		$office = $query->row();
	?>
	<div id="header">
		<div id="logo" class="span-1"><?php echo '<b>'.$office->clinic_name.'</b><br />';?>PAM DENTAL </div>
        <span class="right span-4" style="font-size:13px !important;line-height:1.875em;">
			<?php 

				  echo @$office->first_name.' '.@$office->middle_initial.' '.@$office->last_name.'<br />';
				  echo $office->address_street;
				  echo (@$office->address_apartment_number!='')? ',&nbsp;'.@$office->address_apartment_number.'<br />' : '<br />';
				  echo @$office->address_city;
				  echo ' '.@$office->address_state;
				  echo ' '.@$office->address_zipcode.'<br />';
				  echo '<b>Phone :</b> '.@$office->phone ?>
        </span>
	</div><!-- header -->
	<div id="mainmenu">
            <ul>
                <li class="<?Php echo ($this->uri->segment(2)=='patient_list')? 'active' : '' ?>"><a href="<?php echo base_url()?>frontoffice/patient-list">Home</a></li>
        <!--			<li class="<?Php echo ($this->uri->segment(2)=='setting')? '' : '' ?>"><a href="#">Billing</a></li>-->
                <li class="<?Php echo ($this->uri->segment(2)=='appointment')? 'active' : '' ?>"><a href="<?php echo base_url()?>frontoffice/appointment">Review Appointments</a></li>
                <li class="<?Php echo ($this->uri->segment(2)=='review_checkups')? 'active' : '' ?>"><a href="<?php echo base_url()?>frontoffice/review-checkups">Review Treatment Plans<?php //echo $this->frontoffice_model->checkups_pending['checkups_pending'] ? '&nbsp;(<font color ="#FF0000" >'.$this->frontoffice_model->checkups_pending['checkups_pending'].'</font>)' : ''?></a></li>
                <?php /*?><li class="<?Php echo ($this->uri->segment(2)=='setting')? 'active' : '' ?>"><a href="<?php echo base_url()?>frontoffice/setting">Setting</a></li><?php */?>
                <li class="<?Php echo ($this->uri->segment(2)=='scheduled_appointments')? 'active' : '' ?>">
                    <a href="<?php echo base_url()?>frontoffice/scheduled_appointments">Scheduled Appointments</a></li>
                <li class="right">
                    <?php 
                        $string = $this->session->userdata('user_type') =='frontoffice' ? '<a href="'.base_url().'frontoffice/logout">Logout</a>' : '';
                        echo $string;
                    ?>
                </li>
            </ul>
        </div>
        <!-- mainmenu -->
		<div id="content">
        	<h2>Review Appointment</h2>
          <div id="calendar_wrapper"></div> 
  <div id="popup_synchronize" style="display: none; opacity:0.5; filter:alpha(opacity=50);" onclick="hides()"></div>
  <div id="window_synchronize" style="display: none;">
  <div id="content_id">
 	<?php
		$status_array = array(
              'Reviewed' => 'Approved',
			  'Canceled' => 'Canceled',
        );
	?>
	<table align="center" cellpadding="0" cellspacing="5" border="0">
		<tr>
    		<td class="heading" valign="top"><b>Notes</b></td>
			<td><?php $data = array('name'=> 'note','style'=> 'width:235px; height:100px;',); echo form_textarea($data);  ?></td>
    	</tr>
		<tr>
    		<td class="heading"><b>Status</b></td>
			<td><?php echo form_dropdown('status',$status_array,'','id="status"') ; ?></td>
    	</tr>
		<tr>
    		<td colspan="2" align="center">
            <input type="hidden" name="schedule_id" id="schedule_id" />
            <input type="hidden" name="patient_id" id="patient_id" />
            <input type="hidden" name="patient_name" id="patient_name" />
            <input type="hidden" name="visit_date" id="visit_date" />
            <input type="hidden" name="visit_type" id="visit_type" />
            <input type="hidden" name="start_time" id="start_time" />
            <input type="hidden" name="end_time" id="end_time" />
            <input type="hidden" name="visit_note" id="visit_note" />
            <input type="hidden" name="patient_email" id="patient_email" />
        	<button class="button positive" type="button" name="save" value="save" onclick="review_status();">Review</button></td>
            </tr> 
 	</table> 
	</div>
</div> 

        </div>
        <?php $this->load->view('frontoffice/frontoffice_footer');?>
