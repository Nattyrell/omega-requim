<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<meta name="language" content="en" />
	<title><?php echo url_title(@$title);?></title>
	<link rel="stylesheet" type="text/css" href="<?php echo base_url()?>css/front/screen.css" media="screen, projection" />
	<link rel="stylesheet" type="text/css" href="<?php echo base_url()?>css/front/print.css" media="print" />
	<!--[if lt IE 8]>
	<link rel="stylesheet" type="text/css" href="<?php echo base_url()?>css/front/ie.css" media="screen, projection" />
	<![endif]-->

	<link rel="stylesheet" type="text/css" href="<?php echo base_url()?>css/front/main.css" />
	<link rel="stylesheet" type="text/css" href="<?php echo base_url()?>css/front/form.css" />
	<link rel="stylesheet" type="text/css" href="<?php echo base_url()?>css/front/plugins/buttons/screen.css" />
	<link rel="shortcut icon" type="image/x-icon" href="<?php echo base_url()?>images/favicon.ico" />
	<?php 
            echo @$css;
            echo @$js;
	?>
	<script type ="text/javascript">
			var site_base_path='<?php echo base_url();?>';
        </script>
</head>

<body>

<div class="container" id="page">
	<?php
		$query=$this->db->get('dentist_login');
		$office = $query->row();
	?>
	<div id="header">
		<div id="logo" class="span-1"><?php echo '<b>'.$office->clinic_name.'</b><br />';?>PAM DENTAL </div>
        <span class="right span-4" style="font-size:13px !important;line-height:1.875em;">
			<?php 

				  echo @$office->first_name.' '.@$office->middle_initial.' '.@$office->last_name.'<br />';
				  echo $office->address_street;
				  echo (@$office->address_apartment_number!='')? ',&nbsp;'.@$office->address_apartment_number.'<br />' : '<br />';
				  echo @$office->address_city;
				  echo ' '.@$office->address_state;
				  echo ' '.@$office->address_zipcode.'<br />';
				  echo '<b>Phone :</b> '.@$office->phone ?>
        </span>
	</div><!-- header -->
        <div id="mainmenu">
            <ul>
                <li class="<?Php echo ($this->uri->segment(2)=='patient_list')? 'active' : '' ?>"><a href="<?php echo base_url()?>frontoffice/patient-list">Home</a></li>
        <!--			<li class="<?Php echo ($this->uri->segment(2)=='setting')? '' : '' ?>"><a href="#">Billing</a></li>-->
                <li class="<?Php echo ($this->uri->segment(2)=='appointment')? 'active' : '' ?>"><a href="<?php echo base_url()?>frontoffice/appointment">Review Appointments</a></li>
                <li class="<?Php echo ($this->uri->segment(2)=='review_checkups')? 'active' : '' ?>"><a href="<?php echo base_url()?>frontoffice/review-checkups">Review Treatment Plans<?php //echo $this->frontoffice_model->checkups_pending['checkups_pending'] ? '&nbsp;(<font color ="#FF0000" >'.$this->frontoffice_model->checkups_pending['checkups_pending'].'</font>)' : ''?></a></li>
                <?php /*?><li class="<?Php echo ($this->uri->segment(2)=='setting')? 'active' : '' ?>"><a href="<?php echo base_url()?>frontoffice/setting">Setting</a></li><?php */?>
                <li class="<?Php echo ($this->uri->segment(2)=='scheduled_appointments')? 'active' : '' ?>">
                    <a href="<?php echo base_url()?>frontoffice/scheduled_appointments">Scheduled Appointments</a></li>
                <li class="right">
                    <?php 
                        $string = $this->session->userdata('user_type') =='frontoffice' ? '<a href="'.base_url().'frontoffice/logout">Logout</a>' : '';
                        echo $string;
                    ?>
                </li>
            </ul>
        </div>
        <!-- mainmenu -->
