<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<meta name="language" content="en" />
	<title>PAM :: Frontoffice Login</title>
	<link rel="stylesheet" type="text/css" href="<?php echo base_url()?>css/front/screen.css" media="screen, projection" />
	<link rel="stylesheet" type="text/css" href="<?php echo base_url()?>css/front/print.css" media="print" />
	<!--[if lt IE 8]>
	<link rel="stylesheet" type="text/css" href="<?php echo base_url()?>css/front/ie.css" media="screen, projection" />
	<![endif]-->

	<link rel="stylesheet" type="text/css" href="<?php echo base_url()?>css/front/main.css" />
	<link rel="stylesheet" type="text/css" href="<?php echo base_url()?>css/front/form.css" />
	<link rel="stylesheet" type="text/css" href="<?php echo base_url()?>css/front/plugins/buttons/screen.css" />
	<link rel="shortcut icon" type="image/x-icon" href="<?php echo base_url()?>images/favicon.ico" />
</head>

<body>

<div class="container" id="page">
	<?php
		$query=$this->db->get('dentist_login');
		$office = $query->row();
	?>
	<div id="header">
		<div id="logo" class="span-1"><?php echo '<b>'.$office->clinic_name.'</b><br />';?>PAM DENTAL </div>
        <span class="right span-4" style="font-size:13px !important;line-height:1.875em;">
			<?php 

				  echo @$office->first_name.' '.@$office->middle_initial.' '.@$office->last_name.'<br />';
				  echo $office->address_street;
				  echo (@$office->address_apartment_number!='')? ',&nbsp;'.@$office->address_apartment_number.'<br />' : '<br />';
				  echo @$office->address_city;
				  echo ' '.@$office->address_state;
				  echo ' '.@$office->address_zipcode.'<br />';
				  echo '<b>Phone :</b> '.@$office->phone ?>
        </span>
	</div><!-- header --> 
  <div id="mainmenu">
    <ul>
      <li>&nbsp;</li>
    </ul>
  </div>
<div id="content">
	<div class="form">
    	<form name="frontoffice-login-form" id="frontoffice-login-form" method="post" action="<?php echo base_url()?>frontoffice/login" enctype="multipart/form-data">
	        <fieldset>
    	        <legend>Front Office Login</legend>
                    <div><?php echo $this->session->flashdata('login_error')? '<div class="error">'.$this->session->flashdata('login_error').'</div>' :'';?></div>
                    <div>&nbsp;</div>

                    
                    <div><label>USER NAME <span class="required">*</span></label></div>
                    <div><input type="text" class="text" id="username" name= "username" maxlength="255" size="32" value="<?php echo set_value('username'); ?>"/></div>
                    <div><font color="#FF2437"><?php echo form_error('username')?></font></div>
                    <div></div>

                    <div><label>PASSWORD <span class="required">*</span></label></div>
                    <div><input type="password" class="text"  id="password" name= "password" maxlength="255" size="32" value="<?php echo set_value('password'); ?>"/></div>
                    <div><font color="#FF2437"><?php echo form_error('password')?></font></div>


                    <div><p>Forgot your Username or Password? <a href="<?php echo base_url()?>frontoffice/forgot-password">Click here</a></p></div>
                     <p class="buttons"><button class="button positive" type="submit" name="login">Log In</button></p>
                    <div>&nbsp;</div>
	        </fieldset>
 	   </form>
     </div>
</div>
<?php $this->load->view('frontoffice/frontoffice_footer');?>