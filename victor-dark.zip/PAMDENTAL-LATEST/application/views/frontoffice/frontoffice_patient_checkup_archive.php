<?php $this->load->view('frontoffice/frontoffice_header');?>
<script type="text/javascript" charset="utf-8">
    $(document).ready(function(){
        $('#example').dataTable({
            "bJQueryUI": true,
            "sPaginationType": "full_numbers"
         });
    });
</script>
<div id="content">
	<h2>Treatment Archive</h2>
    <table border="0" cellspacing='0' cellpadding='0' id="example" class="display" style="width:100%;">
        <thead>
            <tr>
                <th align="center">S.No.</th>
		<th align="center">Treatment ID</th>
                <th align="center">Date</th>
                <th align="center">Time</th>
                <th align="center">Status</th>
                <th align="center">Action</th>
            </tr>
        </thead>
        <tbody>
          <?php if($result){ $i=0; foreach($result as $row):?>
          <tr>
                <td align="center"><?php echo $i+=1;?></td>
		<td align="center"><?php echo $row['treatment_uin']?></td>
                <td align="center"><?php echo $row['date']?></td>
                <td align="center"><?php echo $row['time']?></td>
                <td align="center"><?php echo $row['status']?></td>
                <td align="center">
                    <?php echo anchor(base_url().'frontoffice/view-checkup-detail/'.base64_encode($row['patient_checkup_id']).'/'.base64_encode($row['patient_id']), 'View')?>
                </td>
          </tr>
          <?php endforeach;} //else echo '<tr><td colspan="5" align="center">No Record Found.</td></tr>'; ?>
        </tbody>
    </table>
</div>
       
<?php $this->load->view('frontoffice/frontoffice_footer');?>
