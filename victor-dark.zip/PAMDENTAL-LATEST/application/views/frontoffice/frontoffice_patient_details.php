<?php $this->load->view('frontoffice/frontoffice_header');?>
   <script type="text/javascript" charset="utf-8">
    $(document).ready(function() {
    $('#example').dataTable( {
     "sPaginationType": "full_numbers"
     } );
    } );
   </script>
<div id="content">
	<h2>Patient Details</h2>	
	<table style="width:975px;" border="0" cellspacing='0' cellpadding='0'>
    <tr>
      <td align="left" width="50%">
      	<table cellspacing="5" cellpadding="5" border="0" width="100%" class="list">
          <tr>
            <th colspan="2"><b>Patient Information</b></th>
          </tr>
          <tr>
            <td><label>First Name</label></td>
            <td><?php echo $result->first_name ?></td>
          </tr>
           <tr>
           <td><label>Middle Name</label></td>
            <td><?php echo $result->middle_initial ?></td>
          </tr>
           <tr>
            <td><label>Last Name</label></td>
            <td><?php echo $result->last_name ?></td>
          </tr>
           <tr>
            <td><label>Email</label></td>
            <td><?php echo $result->email ?></td>
          </tr>
           <tr>
            <td><label>Username</label></td>
            <td><?php echo $result->username ?></td>
          </tr>
           <tr>
            <td><label>Registration Date</label></td>
            <td><?php echo $result->registration_date ?></td>
          </tr>
          <tr>
            <td><label>Gender</label></td>
            <td><?php echo $result->p_sex ?></td>
          </tr>
          <tr>
            <td><label>Marital Status</label></td>
            <td><?php echo ($result->p_marital_status)? ($result->p_marital_status==4)? $result->p_marital_status_other : $result->p_marital_status : '' ?></td>
          </tr>
          <tr>
            <td><label>Socail Security No.</label></td>
            <td><?php echo $result->p_ssn ?></td>
          </tr>
          <tr>
            <td><label>Driving License</label></td>
            <td><?php echo $result->p_dln ?></td>
          </tr>
          <tr>
            <td><label>Date of Birth</label></td>
            <td><?php echo $result->p_dob ?></td>
          </tr>
          <tr>
            <td><label>Address</label></td>
            <td><?php echo $result->p_address_street.'<br/>'.$result->p_address_apartment_number ?></td>
          </tr>
          <tr>
            <td><label>City</label></td>
            <td><?php echo $result->p_address_city ?></td>
          </tr>
          <tr>
            <td><label>State</label></td>
            <td><?php echo $result->p_address_state_id ?></td>
          </tr>
          <tr>
            <td><label>Zip Code</label></td>
            <td><?php echo $result->p_address_zipcode ?></td>
          </tr>
          <tr>
            <td><label>Phone</label></td>
            <td><?php echo ($result->p_phone_home)? $result->p_phone_home.' (H) ' : ''; echo ($result->p_phone_work)? ' '.$result->p_phone_work.' (O)' : ''?></label></td>
          </tr>
          <tr>
            <td><label>Mobile</label></td>
            <td><?php echo $result->p_phone_cell ?></td>
          </tr>
          <tr>
            <td><label>Practice Reference</label></td>
            <td><?php echo $result->p_practice_reference ?></td>
          </tr>
          <tr>
            <th colspan="2"><b>Health Conditions</b></th>
          </tr>
          <tr>
            <td colspan="2">
              <table>
                <?php
                      $arr_health_con = unserialize($result->p_health_condition);
                      if(!empty($arr_health_con)){
                        $health_con = implode("', '", $arr_health_con);
                        $health_con = str_replace("'\'", '', $arr_health_con);
                        $res = $this->dentists->select_health_con($health_con);
                        if($res){
                            foreach($res as $row):?>
                <tr>
                  <td><?php echo $row['description']?></td>
                </tr>
                <?php 
                            endforeach;
                        }
                        else echo '<tr><td><label>N.A</label></td></tr>';
                      }
                      else echo '<tr><td><label>N.A</label></td></tr>';
                      ?>
              </table>
              </td>
          </tr>
          <tr>
            <th colspan="2"><b>Other Medicines or Neutricuticals</b></th>
          </tr>
          <tr>
            <td colspan="2">
              <table>
                <?php
                      $arr_other_med = unserialize($result->p_health_condition);
                      if(!empty($arr_health_con)){
                        $other_med = implode("', '", $arr_other_med);
                        $other_med = str_replace("'\'", '', $arr_other_med);
                        $res = $this->dentists->select_other_medicines($other_med);
                        if($res){
                            foreach($res as $row):?>
                <tr>
                  <td><?php echo $row['description'].nbs(2).'<b>Yes</b>'?></td>
                </tr>
                <?php 
                            endforeach;
                        }
                        else echo '<tr><td><label>N.A</label></td></tr>';
                      }
                      else echo '<tr><td><label>N.A</label></td></tr>';
                      ?>
              </table>
              </td>
          </tr>
          
          <tr>
            <th colspan="2"><b>Spouse or Responsible Party Information</b></th>
          </tr>
          <tr>
            <td><label>Details For</label></td>
            <td><?php echo $result->srp_following_is_for ?></td>
          </tr>
          <tr>
            <td><label>First Name</label></td>
            <td><?php echo $result->srp_first_name ?></td>
          </tr>
          <tr>
            <td><label>Middle name</label></td>
            <td><?php echo $result->srp_middle_initial ?></td>
          </tr>
          <tr>
            <td><label>Last name</label></td>
            <td><?php echo $result->srp_last_name ?></td>
          </tr>
          <tr>
            <td><label>Gender</label></td>
            <td><?php echo $result->srp_sex ?></td>
          </tr>
          <tr>
            <td><label>Marital Status</label></td>
             <td><?php echo ($result->srp_marital_status)? ($result->srp_marital_status==4)? $result->srp_marital_status_other : $result->srp_marital_status : '' ?></td>
          </tr>
          <tr>
            <td><label>Social Security No.</label></td>
            <td><?php echo $result->srp_ssn ?></td>
          </tr>
          <tr>
            <td><label>Date of Birth</label></td>
            <td><?php echo $result->srp_dob ?></td>
          </tr>
          <tr>
            <td><label>Address</label></td>
            <td><?php echo $result->srp_address_street.'<br/>'.$result->srp_address_apartment_number ?></td>
          </tr>
          <tr>
            <td><label>City</label></td>
            <td><?php echo $result->srp_address_city ?></td>
          </tr>
          <tr>
            <td><label>State</label></td>
            <td><?php echo $result->srp_address_state_id ?></td>
          </tr>
          <tr>
            <td><label>Zip Code</label></td>
            <td><?php echo $result->srp_address_zipcode ?></td>
          </tr>
          <tr>
            <td><label>Phone</label></td>
            <td><?php echo ($result->srp_phone_home)? $result->srp_phone_home.' (H)' : ''; echo ($result->srp_phone_work)? $result->srp_phone_work.' (O)' : ''?></label></td>
          </tr>
          <tr>
            <td><label>Phone Ext</label></td>
            <td><?php echo $result->srp_phone_ext ?></td>
          </tr>
          <tr>
            <td><label>Best Time To Call</label></td>
            <td><?php echo $result->srp_best_time_call ?></td>
          </tr>
          <tr>
            <th colspan="2"><b>Employment Information</b></th>
          </tr>

          <tr>
            <td><label>Details For</label></td>
            <td><?php echo $result->e_following_is_for ?></td>
          </tr>
          <tr>
            <td><label>Employer's Name </label></td>
            <td><?php echo $result->e_name ?></td>
          </tr>
          <tr>
            <td><label>Occupation</label></td>
            <td><?php echo $result->e_occupation ?></td>
          </tr>
          <tr>
            <td><label>Address</label></td>
            <td><?php echo $result->e_address_street ?></td>
          </tr>
          <tr>
            <td><label>City</label></td>
            <td><?php echo $result->e_address_city ?></td>
          </tr>
          <tr>
            <td><label>State</label></td>
            <td><?php echo $result->e_address_state_id ?></td>
          </tr>
          <tr>
            <td><label>Zip Code</label></td>
            <td><?php echo $result->e_address_zipcode ?></td>
          </tr>
        </table></label></td>
      <td align="right" style="vertical-align:top;"><table cellspacing="5" cellpadding="5" border="0" width="100%" class="list">
          <tr>
            <th colspan="2"><b>Insurance Information - Primary Insurance</b></th>
          </tr>
          <tr>
            <td><label>First Name</label></td>
            <td><?php echo $result->pi_first_name ?></td>
          </tr>
          <tr>
            <td><label>Middle name</label></td>
            <td><?php echo $result->pi_middle_initial ?></td>
          </tr>
          <tr>
            <td><label>Last name</label></td>
            <td><?php echo $result->pi_last_name ?></td>
          </tr>
          <tr>
            <td><label>Is insured a patient</label></td>
            <td><?php echo $result->pi_is_insured_patient ?></td>
          </tr>
          <tr>
            <td><label>Insured's Birth Date</label></td>
            <td><?php echo $result->pi_dob ?></td>
          </tr>
          <tr>
            <td><label>ID # </label></td>
            <td><?php echo $result->pi_id ?></td>
          </tr>
          <tr>
            <td><label>Group #</label></td>
            <td><?php echo $result->pi_group ?></td>
          </tr>
          <tr>
            <td><label>Address</label></td>
            <td><?php echo $result->pi_address_street ?></td>
          </tr>
          <tr>
            <td><label>City</label></td>
            <td><?php echo $result->pi_address_city ?></td>
          </tr>
          <tr>
            <td><label>State</label></td>
            <td><?php echo $result->pi_address_state_id ?></td>
          </tr>
          <tr>
            <td><label>Zip Code</label></td>
            <td><?php echo $result->pi_address_zipcode ?></td>
          </tr>
          <tr>
            <td><label>Insured's Employer Name </label></td>
            <td><?php echo $result->pi_emp_name ?></td>
          </tr>
          <tr>
            <td><label>Insured's Employer Address</label></td>
            <td><?php echo $result->pi_emp_address_street ?></td>
          </tr>
                    <tr>
            <td><label>City</label></td>
            <td><?php echo $result->pi_emp_address_city ?></td>
          </tr>
          <tr>
            <td><label>State</label></td>
            <td><?php echo $result->pi_emp_address_state_id ?></td>
          </tr>
          <tr>
            <td><label>Zip Code</label></td>
            <td><?php echo $result->pi_emp_address_zipcode ?></td>
          </tr>
 <tr>
            <td><label>Patient's relationship to insured</label></td>
            <td><?php echo $result->pi_patient_relation ?></td>
          </tr> <tr>
            <td><label>Ins. Plan Name and Address</label></td>
            <td><?php echo $result->pi_insurance_plan_address ?></td>
          </tr>
          <tr>
            <td><label>Total Insurance</label></td>
            <td><?php echo $result->p_total_insurance ?></td>
          </tr>
                    <tr>
            <th colspan="2"><b>Insurance Information - Secondry Insurance</b></th>
          </tr>
          <tr>
            <td><label>First Name</label></td>
            <td><?php echo $result->si_first_name ?></td>
          </tr>
          <tr>
            <td><label>Middle name</label></td>
            <td><?php echo $result->si_middle_initial ?></td>
          </tr>
          <tr>
            <td><label>Last name</label></td>
            <td><?php echo $result->si_last_name ?></td>
          </tr>
          <tr>
            <td><label>Is insured a patient</label></td>
            <td><?php echo $result->si_is_insured_patient ?></td>
          </tr>
          <tr>
            <td><label>Insured's Birth Date</label></td>
            <td><?php echo $result->si_dob ?></td>
          </tr>
          <tr>
            <td><label>ID # </label></td>
            <td><?php echo $result->si_id ?></td>
          </tr>
          <tr>
            <td><label>Group #</label></td>
            <td><?php echo $result->si_group ?></td>
          </tr>
          <tr>
            <td><label>Address</label></td>
            <td><?php echo $result->si_address_street ?></td>
          </tr>
          <tr>
            <td><label>City</label></td>
            <td><?php echo $result->si_address_city ?></td>
          </tr>
          <tr>
            <td><label>State</label></td>
            <td><?php echo $result->si_address_state_id ?></td>
          </tr>
          <tr>
            <td><label>Zip Code</label></td>
            <td><?php echo $result->si_address_zipcode ?></td>
          </tr>
          <tr>
            <td><label>Insured's Employer Name </label></td>
            <td><?php echo $result->si_emp_name ?></td>
          </tr>
          <tr>
            <td><label>Insured's Employer Address</label></td>
            <td><?php echo $result->si_emp_address_street ?></td>
          </tr>
                    <tr>
            <td><label>City</label></td>
            <td><?php echo $result->si_emp_address_city ?></td>
          </tr>
          <tr>
            <td><label>State</label></td>
            <td><?php echo $result->si_emp_address_state_id ?></td>
          </tr>
          <tr>
            <td><label>Zip Code</label></td>
            <td><?php echo $result->si_emp_address_zipcode ?></td>
          </tr>
 <tr>
            <td><label>Patient's relationship to insured</label></td>
            <td><?php echo $result->si_patient_relation ?></td>
          </tr> <tr>
            <td><label>Ins. Plan Name and Address</label></td>
            <td><?php echo $result->si_insurance_plan_address ?></td>
          </tr>

        </table></label></td>
    </tr>
  </table>
</div>
<script type="application/javascript">
$('.list tr:even').addClass('even');
$('.list tr:odd').addClass('odd');
</script>
<?php $this->load->view('frontoffice/frontoffice_footer');?>
