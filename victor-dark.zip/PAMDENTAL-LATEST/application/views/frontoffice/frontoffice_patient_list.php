<?php $this->load->view('frontoffice/frontoffice_header');?>
<script type="text/javascript" charset="utf-8">
 $(document).ready(function(){
	 $('#example').dataTable({
		 "bJQueryUI": true,
		 "sPaginationType": "full_numbers"
	  });
 });
</script>
<div id="content">
	<h2>Patient List</h2>
	<table border="0" cellspacing='0' cellpadding='0' id="example" class="display" style="width:100%;">
		<thead>
	      <tr>
                <th align="center">S.No.</th>
                <!--<th align="center">Patient ID.</th>-->
		<th align="center">Patient UIN</th>
                <th align="center">Patient Name</th>
                <th align="center">email</th>
                <th align="center">Action</th>
              </tr>
		</thead>
    <tbody>
 <?php if($result)
                {	$i=0;
                    foreach($result->result() as $row):
          ?>
              <tr>
                <td align="center"><?php echo $i+=1;?></td>
                <!--<td align="center"><?php echo '#'.$row->patient_id;?></td>-->
		<td align="center"><?php echo $row->patient_uin;?></td>
                <td align="center"><a href="<?php echo base_url();?>frontoffice/patient-details/<?php echo base64_encode($row->patient_id);?>"><?php echo $row->name;?></a></td>
                <td align="center"><?php echo $row->email;?></td>
                <td align="center">
                    <a href="<?php echo base_url()?>frontoffice/patient-billing-history/<?php echo base64_encode($row->patient_id)?>">Billing History</a>&nbsp;|&nbsp;<a href="<?php echo base_url()?>frontoffice/patient-checkup-archive/<?php echo base64_encode($row->patient_id)?>">View Treatment Archive</a>
                </td>

              </tr>
              <?php endforeach;
                }
                //else
                    //echo '<tr><td colspan="5">No Record Found.</td></tr>';
             ?>
 	</tbody>
</table>
</div>

<?php $this->load->view('frontoffice/frontoffice_footer');?>
