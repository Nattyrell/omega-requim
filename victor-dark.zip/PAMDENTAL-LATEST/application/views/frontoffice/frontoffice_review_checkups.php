<?php $this->load->view('frontoffice/frontoffice_header');?>
<style type="text/css">
#window_synchronize {
	width: 500px;
	height: 300px;
	margin: 0 auto;
	padding-left:10px;
	padding-top:10px;
	border: 3px solid #ccc;
	background: #ffffff;
	border-radius:5px;
	-moz-border-radius:5px;
	-webkit-border-radius:5px;
	position: fixed;
	top: 25%;
	left: 35%;
	line-height:24px;
	text-align:left;
	z-index:555;
}

#popup_synchronize {
	height: 100%;
	width: 100%;
	background: #000000;
	position:fixed;
	top: 0;
	left:0;
	-moz-opacity:0.5;
	-khtml-opacity: 0.5;
	opacity: 0.5;
	filter:alpha(opacity=50);
	z-index:550;
}
</style>

<script type="text/javascript">
function review(patient_checkup_id)
{
    $('#window_synchronize').show('show');
    $('#popup_synchronize').show('show');
    document.getElementById('patient_checkup_id').value = patient_checkup_id;
}

function hides()
{
    $('#window_synchronize').hide(1000);
    $('#popup_synchronize').hide(1000);
}

$(document).ready(function() {
  $('#save').click(function(){
      var patient_checkup_id = $('#patient_checkup_id').val();
      var status = $('#status').val();
      var note = $('#note').val();
      $.ajax({url:"<?php echo base_url()?>frontoffice/refresh_checkups", type: "POST", data:'patient_checkup_id='+patient_checkup_id+'&note='+note+'&status='+status, success:function(result){
      $("#tableData").html(result);
      alert('Checkup successfully reviewed.');
      hides();
  }});
  });
});
</script>
<div id="content">
    <h2>Review Treatment Plans</h2>
    <div id="tableData">
        <script type="text/javascript" charset="utf-8">
        $(document).ready(function() {
            $('#example').dataTable( {
                "bJQueryUI": true,
                "sPaginationType": "full_numbers"
             });
        });
       </script>
        <table border="0" cellspacing='0' cellpadding='0' id="example" class="display" style="width:100%;">
            <thead>
                <tr>
                    <th align="center">S.No.</th>
		    <th align="center">Treatment ID</th>
                    <th align="center">Patient UIN</th>
                    <th align="center">Patient Name</th>
                    <th align="center">Checkup Date</th>
                    <th align="center">Checkup Time</th>
                    <th align="center">Action</th>
                </tr>
            </thead>
            <tbody>
              <?php if($result){ $i=0; foreach($result as $row):?>
              <tr>
                    <td align="center"><?php echo $i+=1;?></td>
		    <td align="center"><?php echo $row['treatment_uin']?></td>
                    <td align="center"><?php echo $row['patient_uin']?></td>
                    <td align="center"><?php echo $row['name']?></td>
                    <td align="center"><?php echo $row['date']?></td>
                    <td align="center"><?php echo $row['time']?></td>
                    <td align="center">
                        <?php echo anchor(base_url().'frontoffice/view-checkup-detail/'.base64_encode($row['patient_checkup_id']).'/'.base64_encode($row['patient_id']), 'View Treatment Plan')?>
                        <?php echo nbs(1).'|'.nbs(1)?>
                        <?php
                        /** COMMENTED ON 28-11-2012 7:57 PM*/
                        ?>
<!--                        <a href="#" onclick="review(<?php echo $row['patient_checkup_id']?>)">Review</a>-->
                        <?php
                        /** ------------------------------ */
                        ?>
                        <a href="<?php echo base_url()?>frontoffice/review-treatment-plan/<?php echo base64_encode($row['patient_checkup_id'])?>/<?php echo base64_encode($row['patient_id'])?>">Review Treatment Plan</a>
                    </td>
              </tr>
              <?php endforeach;} //else echo '<tr><td colspan="6" align="center">No Record Found.</td></tr>'; ?>
            </tbody>
        </table>
    </div>
<div id="popup_synchronize" style="display: none;opacity: 0.5; filter:alpha(opacity=50); " onclick="hides()"></div>
<div id="window_synchronize" style="display: none;">
<div id="content_id">
  <?php
          $status_array = array(
            'Approved' => 'Approved',
            'Canceled' => 'Canceled',
  );
  ?>
  <table align="center" cellpadding="0" cellspacing="5" border="0">
        <tr>
          <td class="heading" valign="top"><b>Notes</b></td>
          <td>
              <?php 
                $data = array('name'=> 'note',
                                'id' => 'note',
                              'style'=> 'width:235px; height:100px;'
                    ); 
                echo form_textarea($data);  
              ?></td>
        </tr>
        <tr>
          <td class="heading"><b>Status</b></td>
          <td><?php echo form_dropdown('status',$status_array,'','id="status"') ; ?></td>
        </tr>
        <tr>
          <td colspan="2" align="center">
                <input type="hidden" name="patient_checkup_id" id="patient_checkup_id" />
                <button class="button positive" id="save" type="button" name="save" value="Save">Review</button>
          </td>
        </tr> 
  </table> 
  </div>
</div> 
        
<?php $this->load->view('frontoffice/frontoffice_footer');?>
