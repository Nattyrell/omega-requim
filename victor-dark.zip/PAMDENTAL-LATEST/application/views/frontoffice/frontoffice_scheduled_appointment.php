<?php $this->load->view('frontoffice/frontoffice_header');?>
<script type="text/javascript" charset="utf-8">
 $(document).ready(function() {
 $('#example').dataTable( {
    "bJQueryUI": true,
    "sPaginationType": "full_numbers"
  } );
 } );
</script>

<div id="content">
  <h2>Scheduled Appoinment</h2>
  <table border="0" cellspacing='0' cellpadding='0' id="example" class="display" style="width:100%; padding-bottom: 25px">
    <thead>
      <tr>
        <th align="center">S.No.</th>
        <th align="center">Patient Name</th>
        <th align="center">Visit Type</th>
        <th align="center">Visit Date</th>
        <th align="center">Time</th>
        <th align="center">Status</th>
      </tr>
    </thead>
    <tbody>
      <?php if($result){ $i=0; foreach($result as $row):?>
      <tr>
        <td align="center"><?php echo $i+=1;?></td>
        <td align="center"><?php echo $row['name'];?></td>
        <td align="center"><?php echo $row['visit_type']?></td>
        <td align="center"><?php echo $row['visit_date']?></td>
        <td align="center"><?php echo $row['start_time'].' - '.$row['end_time'] ?></td>
        <td align="center"><?php echo ($row['schedule_status']=='Reviewed')? 'Approved' : $row['schedule_status']?></td>
      </tr>
      <?php endforeach;} //else echo '<tr><td colspan="5" align="center">No Record Found.</td></tr>'; ?>
    </tbody>
  </table>
</div>
<?php $this->load->view('frontoffice/frontoffice_footer');?>
