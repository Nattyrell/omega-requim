<?php $this->load->view('frontoffice/frontoffice_header');?>

<div id="content">
	<h2>Settings</h2>
    
    <?php echo ($this->session->flashdata('show_message')!='')? '<div class="success">'.$this->session->flashdata('show_message').'</div>' : '';?>
  <div class="form">
    <form method="post" action="<?php echo base_url() ?>frontoffice/setting" enctype="multipart/form-data"/>
    
    <div class="row">
      <label class="required" for="first_name">First Name <span class="required">*</span></label>
      <input class="text" type="text" name="first_name" value="<?php echo (isset($_POST['first_name']))? $_POST['first_name'] : $result->first_name ?>" />
      <font color="#FF2437"><?php echo form_error('first_name') ?> </font>
    </div>
    <div class="row">
      <label class="required" for="middle_initial">Middle Initial</label>
      <input  class="text" type="text" name="middle_initial" value="<?php echo (isset($_POST['middle_initial']))? $_POST['middle_initial'] : $result->middle_initial ?>" />
    </div>
    <div class="row">
      <label class="required" for="middle_initial">Last Name <span class="required">*</span></label>
      <input  class="text" type="text" name="last_name" value="<?php echo (isset($_POST['last_name']))? $_POST['last_name'] : $result->last_name ?>" />
      <font color="#FF2437"><?php echo form_error('last_name') ?></font>
    </div>
    <div class="row">
      <label class="required" for="middle_initial">Email <span class="required">*</span></label>
      <input  class="text" type="text" name="email" value="<?php echo (isset($_POST['email']))? $_POST['email'] : $result->email ?>" />
      <font color="#FF2437"><?php echo form_error('email') ?> </font>
    </div>
    <div class="row">
      <label class="required" for="middle_initial">Username <span class="required">*</span></label>
      <input  class="text" type="text" name="username" value="<?php echo (isset($_POST['username']))? $_POST['username'] : $result->username ?>" />
     <font color="#FF2437"> <?php echo form_error('username') ?></font>
    </div>
    <div class="row">
      <label class="required" for="middle_initial">Password</label>
      <input  class="text" type="password" name="password" value="" />
    </div>
    <div class="row">
      <label class="required" for="middle_initial">Confirm Password</label>
      <input  class="text" type="password" name="conf_password" value="" />
      <font color="#FF2437"><?php echo form_error('conf_password') ?> </font>
    </div>
    <p class="buttons"><button class="button positive" type="submit">Update</button></p>
    </form>
  </div>
</div>
<?php $this->load->view('frontoffice/frontoffice_footer');?>
