<?php $this->load->view('frontoffice/frontoffice_header');?>

<script type="text/javascript" charset="utf-8">
    $(document).ready(function() {
    jQuery.extend( jQuery.fn.dataTableExt.oSort, {
    "num-html-pre": function ( a ) {
        var x = a.replace( /<.*?>/g, "" );
        return parseFloat( x );
    },
 
    "num-html-asc": function ( a, b ) {
        return ((a < b) ? -1 : ((a > b) ? 1 : 0));
    },
 
    "num-html-desc": function ( a, b ) {
        return ((a < b) ? 1 : ((a > b) ? -1 : 0));
    }
    } );
    $('#example').dataTable({
            "bJQueryUI": true,
            "sPaginationType": "full_numbers",
            "aoColumns": [
            null,
            { "sType": "num-html" },
            null,
            null,
            null,
            null
        ]
            });
    } );
</script>

<div id="content">
    <h2>Billing History</h2>
    <table cellspacing="0" cellpadding="0" border="0" style="width:100%;" id="example" class="display">
        <thead>
          <tr>
            <th align="middle">S.No.</th>
            <th align="middle">Amount Paid (US$)</th>
            <th align="middle">Date</th>
            <th align="middle">Time</th>
            <th align="middle">Transaction ID</th>
            <th align="middle">Action</th>
          </tr>
        </thead>
        <tbody>
          <?php if($result)
            {	$i=0;
                foreach($result as $row):
          ?>
          <tr>
            <td align="middle"><?php echo $i+=1;?></td>
            <td align="middle"><font color="red"><?php echo $row['total_amount_paid']?></font></td>
            <td align="middle"><?php echo $row['date']?></td>
            <td align="middle"><?php echo $row['time']?></td>
            <td align="middle"><code><?php echo $row['transaction_id']?></code></td>
            <td align="middle"><?php echo anchor('frontoffice/patient-billing-detail/'.base64_encode($row['patient_checkup_id']).'/'.base64_encode($row['patient_id']), 'View')?></td>
          </tr>
          <?php endforeach;
            }
         ?>
        </tbody>
    </table>
</div>
<?php $this->load->view('frontoffice/frontoffice_footer');?>