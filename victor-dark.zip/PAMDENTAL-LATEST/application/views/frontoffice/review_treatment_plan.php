<?php $this->load->view('frontoffice/frontoffice_header');?>
<?php 
    if(@$get_checkup_detail['treatment_time'])
        $treatment_time = explode(':', $get_checkup_detail['treatment_time'])
?>
<script type="text/javascript">
    $(document).ready(function() {
        $('#timepicker').jtimepicker({
            "hourMode": 10,
            "secView": false,
            "clockIcon": '<?php echo base_url()?>images/timepicker/icon_clock_1.gif',
            "hourDefaultValue": <?php echo @$treatment_time[0]?>,
            "minDefaultValue": <?php echo @$treatment_time[1]?>
        });
    });
</script>
<?php
    //echo '<pre>';
    //print_r($get_checkup) ;
    //echo '</pre>';
?>
<div id="content">
    <fieldset>
    <legend>Treatment Plan</legend>
    <table name="treatment-plan" id="treatment-plan" width="100%" cellspacing="5" cellpadding="10">
        <tr>
            <td width="50%" align="left">
                <?php /** MAKE DYNAMIC */?>
                <b>Express Denture Care</b><br/>
                18009 Hwy 99, Suite C<br/>
                Lynwood WA 98037<br/>
                <b>Phone:</b>&nbsp;425-672-8494
            </td>
            <td width="50%" align="right">
                <?php /** MAKE DYNAMIC */?>
                <b>PATIENT NAME:</b>&nbsp;<?php echo $patient_data['name']?>
            </td>
        </tr>
        <tr>
            <td colspan="2">&nbsp;</td>
        </tr>
        <tr>
            <td align="left">
                <table>
                    <tr>
                        <th>
                            <?php /** MAKE DYNAMIC */?>
                            GUARANTOR NAME AND MAILING ADDRESS
                        </th>
                    </tr>
                    <tr>
                        <td><?php echo $patient_data['name']?></td>
                    </tr>
                    <tr>
                        <td>
                        <?php
                            $states = array();
                            foreach($us_states->result_array() AS $row){
                                $states[$row['id']] = $row['state'];
                            }
                            $contact_address = $patient_data['p_address_apartment_number'].nbs(1).$patient_data['p_address_street'].', '.$patient_data['p_address_city'].nbs(1).$states[$patient_data['p_address_state_id']].nbs(1).$patient_data['p_address_zipcode'];
                            echo $contact_address;
                        ?>
                        </td>
                    </tr>
                </table>
            </td>
            <td align="right">
                <b><?php echo $get_checkup_detail['date'];?>
            </td>
        </tr>
    </table>
    </fieldset>
    <div style="clear: both; padding-top: 25px"></div>
    <fieldset>
    <legend><?php echo 'TREATMENT:'.'&nbsp;'.$get_checkup_detail['treatment_uin']?></legend>
        <form id="review-treatment-plan" name="review-treatment-plan" method="POST" action="<?php echo base_url()?>frontoffice/review-treatment-plan/<?php echo $this->uri->segment(3).'/'.$this->uri->segment(4)?>">
            <table name="view-checkup" id="view-checkup" width="100%" cellspacing="5" style="border: 1px solid #3366FF">
                    <tr>
                        <th align="middle">Sr. No.</th>
                        <th align="middle">Tooth Description</th>
                        <th align="middle">ADA Code</th>
                        <th align="middle">Service</th>
                        <th align="middle">Service Fee ($)</th>
                        <!--<th align="middle">INS. Fee</th>-->
                        <th align="middle">Est. Insurance Coverage ($)</th>
                        <th align="middle">INS. Covered (%)</th>
                        <th align="middle">Annual Deductible ($)</th>
                        <th align="middle">Patient Fee ($)</th>
                    </tr>
                </tbody>
                <?php
                $i=0;
                foreach ($get_checkup AS $row):?>
                <tr>
                    <td align="middle"><?php echo $i+=1?></td>
                    <td align="middle"><?php echo $row['tooth_desc']?></td>
                    <td align="middle"><?php echo $row['ada_code']?></td>
                    <td align="middle"><?php echo $row['recommended_treatment_desc']?></td>
                    <!--<td align="middle"><?php /*echo '$'.$row['price']*/?></td>
                    <td align="middle"><?php /*echo '$'.$row['insurance']*/?></td>-->
                    <td align="middle">
                        <input style="border: 1px solid #3366FF; border-left: 4px solid #3366FF; background-color:#FFFFEF; color: #FF0000" type="text" name="t_price[]" id="t_price_<?php echo $i?>" size="8" value="<?php echo @$_POST['t_price['.$i.']'] ? @$_POST['t_price['.$i.']'] : $row['t_price']?>">
                    </td>
                    <td align="middle">
                        <input style="border: 1px solid #3366FF; border-left: 4px solid #3366FF; background-color:#FFFFEF; color: #FF0000" type="text" name="e_insurance_coverage[]" id="e_insurance_coverage_<?php echo $i?>" size="8" value="<?php echo @$_POST['e_insurance_coverage['.$i.']'] ? @$_POST['e_insurance_coverage['.$i.']'] : $row['e_insurance_coverage']?>">
                    </td>
                    <td align="middle">
                        <input style="border: 1px solid #3366FF; border-left: 4px solid #3366FF; background-color:#FFFFEF; color: #FF0000" type="text" name="ins_covered_per[]" id="ins_covered_per_<?php echo $i?>" size="8" value="<?php echo @$_POST['ins_covered_per['.$i.']'] ? @$_POST['ins_covered_per['.$i.']'] : $row['ins_covered_per']?>">
                    </td>
                    <td align="middle">
                        <input style="border: 1px solid #3366FF; border-left: 4px solid #3366FF; background-color:#FFFFEF; color: #FF0000" type="text" name="annual_deductible[]" id="annual_deductible_<?php echo $i?>" size="8" value="<?php echo @$_POST['annual_deductible['.$i.']'] ? @$_POST['annual_deductible['.$i.']'] : $row['annual_deductible']?>">
                    </td>
                    <td align="middle">
                        <input style="border: 1px solid #3366FF; border-left: 4px solid #3366FF; background-color:#FFFFEF; color: #FF0000" type="text" name="patient_fee[]" id="patient_fee_<?php echo $i?>" size="8" value="<?php echo @$_POST['patient_fee['.$i.']'] ? @$_POST['patient_fee['.$i.']'] : $row['patient_fee']?>" onchange="cal_total();">
                        <!--<input type="text" name="treat_id[]" size="8" value="<?php echo $row['treat_id']?>"/>-->
                        <input type="hidden" name="patient_checkup_relation_id[]" size="8" value="<?php echo $row['patient_checkup_relation_id']?>"/>
                    </td>
                </tr>   
                <?php
                endforeach;
                ?>
                <tr>
                    <td align="middle" colspan="9">&nbsp;</td>
                </tr>
                <tbody bgcolor="#FFFFEF">
                    <tr>
                        <th colspan="8">
                            <div align="middle">Patient Grand Total</div>
                        </th>
                        <td align="middle" >
                            <span id="cal_total"><code>$0.00</code></span>
                        </td>
                    </tr>
                </tbody>
            </table>
            <table>
                <tr>
                    <th>Total Deduction from Remaining Patient Insurance</th>
                    <td align="middle" >
                        <?php echo '$'?>
                        <input style="border: 1px solid #3366FF; border-left: 4px solid #3366FF; background-color:#FFFFEF; color: #FF0000" type="text" name="patint_ins_deduct" id="patint_ins_deduct" size="8" value="<?php echo set_value('patint_ins_deduct', '0.00'); ?>">
                        <input type="hidden" name="patient_checkup_id" size="8" value="<?php echo $get_checkup_detail['patient_checkup_id']?>">
                    </td>
                </tr>
                <tr>
                    <td align="middle" >
                        <font color="red"><?php echo form_error('patint_ins_deduct')?></font>
                    </td>
                </tr>
                <tr>
                    <td>&nbsp;</td>
                </tr>
                <tr>
                    <td><label><b>Notes</b></label></td>
                    <td><label><b>Estimated Treatment Time <font color="#FF0000">HH:MM<font></b></label></td>
                </tr>
                <tr>
                <td>
                    <textarea name="notes" size="50" height="50" onfocus="if(this.value=='Front Office Notes...'){this.value='';}" onblur="if(this.value==''){this.value='Front Office Notes...'; }">Front Office Notes...</textarea>
                </td>
                <td style="vertical-align: top"><div id="timepicker"></div></td>
                </tr>
                <tr>
                    <td colspan=2>&nbsp;</td>
                </tr>
                <tr>
                    <td>
                        <div align="middle">
                            <button class="button positive" type="submit" name="submit" id="submit" onclick="return confirm_submit();">Submit Treatment Plan</button>
                        </div>
                    </td>
                </tr>
            </table>
        </form>

        <div style="clear: both; padding-top: 25px"></div>
    </fieldset>
    <div style="clear: both; padding-top: 25px"></div>
</div>
<script type="text/javascript">
    $(document).ready(function() {
      cal_total();  
    });
    
    function cal_total()
    {    
        var total='0.00';
        var m = <?php echo $i?>;
        for (var j=1;j<=m;j++){
            total=parseFloat(total)+parseFloat($('#patient_fee_'+j).val());
        }
        $('#cal_total').html('<code>$'+total.toFixed(2)+'</code>');
    }
    
    function confirm_submit()
    {
        var cnfrm= confirm("Are you sure?");
        if (cnfrm== true){
            return true;
        }
        else{
            return false;
        }
    }
</script>
<?php $this->load->view('frontoffice/frontoffice_footer');?>
