<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<meta name="language" content="en" />
	<title><?php echo url_title(@$title);?></title>
	<link rel="stylesheet" type="text/css" href="<?php echo base_url()?>/css/front/screen.css" media="screen, projection" />
	<link rel="stylesheet" type="text/css" href="<?php echo base_url()?>/css/front/print.css" media="print" />
	<!--[if lt IE 8]>
	<link rel="stylesheet" type="text/css" href="<?php echo base_url()?>/css/front/ie.css" media="screen, projection" />
	<![endif]-->

	<link rel="stylesheet" type="text/css" href="<?php echo base_url()?>/css/front/main.css" />
    <link rel="stylesheet" type="text/css" href="<?php echo base_url()?>/css/front/plugins/buttons/screen.css" />
    <style type="text/css">
		.ui-widget {
			font-size: 1em;	
		}
		
		#calendar_new_entry_form, #about {
			display: none;
			z-index: 10;
		}
		
		#about_button_container {
			position: absolute;
			top: 0em;
			right: 0em;	
			padding: 0.5em 2em;
			background: #ddf;
			border: 1px solid #bbd;
			width: 25em;
			text-align: center;
		}
		
		#calendar_new_entry_form label {
			display: block !important;
			margin-top: 1em !important;
			margin-bottom: 0.5em !important;
			z-index: 10 !important;
		}
		
		form ul {
			padding: 0.3em !important;
		}
		
		select, input[type='text'], textarea {
			width: 250px !important;
			padding: 3px !important;
		}
		
		input[type='text'] {
			width: 245px !important;
		}
		
		UL
		{
			list-style: none !important;
			padding: 0;
		}
		
		ul.formatted,ol.formatted {
			display: block !important;
			margin: 1em 0.5em !important;
		}
		
		ul.formatted li,ol.formatted li {
			margin: 5px 30px !important;
			display: auto !important;
		}
		
		ul.formatted li {
			list-style:none !important;
			list-style-type: disc !important;
		}
		
		ol.formatted li {
			list-style:none !important;
			list-style-type: decimal !important;
		}
		#switcher{float:left;}
		</style>
	<?php 
		echo @$css;
    	echo @$js;
	?>
	<script type ="text/javascript">
		var site_base_path='<?php echo base_url();?>';
		var base_path='<?php echo base_url() ?>';
		var commonAjaxHandler = './event.php';
		$(document).ready(function() { 
  		$('#calendar_wrapper').weekCalendar({
			timeslotsPerHour : 4,    
			switchDisplay: {'Daily Calendar': 1, 'Weekly Calendar': 7},
			businessHours :{start: 0, end: 24, limitDisplay: true },
			allowCalEventOverlap : false,
     		overlapEventsSeparate: true,
			draggable : function(calEvent, $event) {
        		return false;
    		},
    		resizable : function(calEvent, $event) {
        		return false;
    		},
			data:'<?php echo base_url() ?>patient/get_appointment',  
			eventRender : function(calEvent, $event) {
				// alert(JSON.stringify(calEvent));	
				 if ((calEvent.patient_id != <?php echo $this->session->userdata('patient_id') ?>) && calEvent.title!='New Appointment') {
					$event.css("backgroundColor", "red");
					$event.find(".wc-time").css({
					   "backgroundColor" : "red",
					   "border" : "1px solid #888"
					});
				 }
			  },
	   		'height':function($calendar){ 
      			 return $(window).height() - $("h1").outerHeight() - 1;
    		},
			// Function for adding new appointment
    		'eventNew':function(calEvent, $event) { 
        		 var $dialogContent = $("#calendar_new_entry_form");
        		 resetForm($dialogContent);
         		 var startField = $dialogContent.find("select[name='start']").val(calEvent.start);
         		 var endField = $dialogContent.find("select[name='end']").val(calEvent.end);
         		 var titleField = $dialogContent.find("input[name='title']");
         		 var bodyField = $dialogContent.find("textarea[name='body']");
		 		 var $this=$(this); 
         		 $dialogContent.dialog({
            	 	 title: "Add Appointment",
            		 close: function() {
              	 		$dialogContent.dialog("destroy");
               			$dialogContent.hide();
               			$('#calendar_wrapper').weekCalendar("removeUnsavedEvents");
            		},
            		buttons: {
               			save : function() {
                  			calEvent.start = new Date(startField.val());
                  			var st = new Date(startField.val());
                  			var sm = parseInt(st.getMonth()) + 1;
                  			var visit_date = st.getFullYear() + '-' + sm + '-' + st.getDate() + '';

						    var start_time = st.getHours() + ':' + st.getMinutes() + ':' + st.getSeconds();
						    calEvent.end = new Date(endField.val());
						    var et = new Date(endField.val());
						    var end_time = et.getHours() + ':' + et.getMinutes() + ':' + et.getSeconds();
						    //alert(end_time);
						   calEvent.title = '<?php echo $this->session->userdata('name') ?>';
						   calEvent.body = $("#visitNote").val();
						   calEvent.patient_id = <?php echo $this->session->userdata('patient_id') ?>;
						   calEvent.visit_type = $("#visitType").val();
						   calEvent.visit_note = $("#visitNote").val();
                  		   var checkup_id = '<?php echo base64_decode($this->uri->segment(3))?>';
						   
				  			$.post('<?php echo base_url()?>patient/add_appointment',{visit_date:visit_date, start_time:start_time, end_time:end_time, patient_id:calEvent.patient_id, visit_type:calEvent.visit_type,visit_note:calEvent.visit_note,checkup_id:checkup_id},function(data){ 
								id = parseInt(data);
								calEvent.id = id;
								if(id)
									alert("Schedule Added Successfully");
								else
									alert('Selected time slot is either busy or unavailable.');	
							});
							
							$("#calendar_wrapper").weekCalendar("refresh");
							$('#calendar_wrapper').weekCalendar("updateEvent", calEvent);
							$('#calendar_wrapper').weekCalendar("removeUnsavedEvents");
							$dialogContent.dialog("close");
							
               			},//end of save button
               			
						cancel : function() {
                  			$dialogContent.dialog("close");
		               }
            		}//End of button line 135-169
         		}).show();
		        $dialogContent.find(".date_holder").text($('#calendar_wrapper').weekCalendar("formatDate", calEvent.start));
        		setupStartAndEndTimeFields(startField, endField, calEvent, $('#calendar_wrapper').weekCalendar("getTimeslotTimes", calEvent.start));
    		},
			
			noEvents : function() {

      		},
			
			'eventClick':function(calEvent, $event) { 
      			//calendar_edit_entry(calEvent,$event); 
				//alert(JSON.stringify(calEvent));
				if (calEvent.readOnly || (calEvent.patient_id != <?php echo $this->session->userdata('patient_id') ?>)) {
					alert('Selected time slot is either busy or unavailable.');
           			 return;
        		}
				 var $dialogContent = $("#calendar_new_entry_form");
        		 resetForm($dialogContent);
         		 var startField = $dialogContent.find("select[name='start']").val(calEvent.start);
         		 var endField = $dialogContent.find("select[name='end']").val(calEvent.end);
         		 var titleField = $dialogContent.find("input[name='title']");
         		 var bodyField = $dialogContent.find("textarea[name='body']");
		 		 var $this=$(this); 
				 $dialogContent.dialog({
				   title: "Edit - " + calEvent.title,
				   close: function() {
				    	$dialogContent.dialog("destroy");
				  		// removeVisitNote();
				   		$dialogContent.hide();
				   		$('#calendar_wrapper').weekCalendar("removeUnsavedEvents");
				},
           		buttons: {
					save : function() {
		                  calEvent.start = new Date(startField.val());
                		  calEvent.end = new Date(endField.val());
		                  var st = new Date(startField.val());
        		          var sm = parseInt(st.getMonth()) + 1;
                		  var visit_date = st.getFullYear() + '-' + sm + '-' + st.getDate() + '';
                  
						  var start_time = st.getHours() + ':' + st.getMinutes() + ':' + st.getSeconds();
						  calEvent.end = new Date(endField.val());
						  var et = new Date(endField.val());
						  var end_time = et.getHours() + ':' + et.getMinutes() + ':' + et.getSeconds();
                  
						  calEvent.title = '<?php echo $this->session->userdata('name') ?>';
						  calEvent.body = $("#visitNote").val();
						  calEvent.patient_id = <?php echo $this->session->userdata('patient_id') ?>;
						  calEvent.visit_type = $("#visitType").val();
						  calEvent.visit_note = $("#visitNote").val();
						  var schedule_id = calEvent.id;
		                $.post('<?php echo base_url()?>patient/update_appointment',{action:'update', schedule_id:schedule_id, visit_date:visit_date, start_time:start_time, end_time:end_time, patient_id:calEvent.patient_id, visit_type:calEvent.visit_type,visit_note:calEvent.visit_note,},function(data){ 
								$this.dialog('close'); 
									alert(data);
								//id = parseInt(data);
							})
						
						  $('#calendar_wrapper').weekCalendar("updateEvent", calEvent);
						  $dialogContent.dialog("close");
					//	  removeVisitNote();*/
               		},// end of save
				    "delete" : function() {
						  var answer = confirm('Are you sure you want to delete this appointment!');
						  if(answer)
						  {		
	    	              	$('#calendar_wrapper').weekCalendar("removeEvent", calEvent.id);
    	                  	$dialogContent.dialog("close");
						  }
               		},
					"cancel" : function() {
						  $dialogContent.dialog("close");
						  //removeVisitNote();
					   }
					}
				 }).show();
				//	alert(calEvent.visit_note);
				 // set values from database
				 document.getElementById('patientName').value = calEvent.title;
				 document.getElementById('patientId').value = calEvent.patient_id;
				 document.getElementById('visitType').value = calEvent.visit_type;
				 document.getElementById('visitNote').value = calEvent.visit_note;
				 //alert(document.getElementById('visitNote').value);
				 var startField = $dialogContent.find("select[name='start']").val(calEvent.start);
				 var endField = $dialogContent.find("select[name='end']").val(calEvent.end);
				 $dialogContent.find(".date_holder").text($('#calendar_wrapper').weekCalendar("formatDate", calEvent.start));
				 setupStartAndEndTimeFields(startField, endField, calEvent, $('#calendar_wrapper').weekCalendar("getTimeslotTimes", calEvent.start));
				 $(window).resize().resize(); //fixes a bug in modal overlay size ??
         

				}
	  });
	  function resetForm($dialogContent) {
		  $dialogContent.find("input").val("");
		  $dialogContent.find("textarea").val("");
		  removeVisitNote();
	  }
	   
	  function removeVisitNote()
	  {
		  document.getElementById('visitNote').value='';
	  }
		 /*
		* Sets up the start and end time fields in the calendar event
		* form for editing based on the calendar event being edited
		*/
	   function setupStartAndEndTimeFields($startTimeField, $endTimeField, calEvent, timeslotTimes) {
	
		  $startTimeField.empty();
		  $endTimeField.empty();
	
		  for (var i = 0; i < timeslotTimes.length; i++) {
			 var startTime = timeslotTimes[i].start;
			 var endTime = timeslotTimes[i].end;
			 var startSelected = "";
			 if (startTime.getTime() === calEvent.start.getTime()) {
				startSelected = "selected=\"selected\"";
			 }
			 var endSelected = "";
			 if (endTime.getTime() === calEvent.end.getTime()) {
				endSelected = "selected=\"selected\"";
			 }
			 $startTimeField.append("<option value=\"" + startTime + "\" " + startSelected + ">" + timeslotTimes[i].startFormatted + "</option>");
			 $endTimeField.append("<option value=\"" + endTime + "\" " + endSelected + ">" + timeslotTimes[i].endFormatted + "</option>");
	
			 $timestampsOfOptions.start[timeslotTimes[i].startFormatted] = startTime.getTime();
			 $timestampsOfOptions.end[timeslotTimes[i].endFormatted] = endTime.getTime();
	
		  }
		  $endTimeOptions = $endTimeField.find("option");
		  $startTimeField.trigger("change");
	   }
	
	   var $endTimeField = $("select[name='end']");
	   var $endTimeOptions = $endTimeField.find("option");
	   var $timestampsOfOptions = {start:[],end:[]};
	
	   //reduces the end time options to be only after the start time options.
	   $("select[name='start']").change(function() {
		  var startTime = $timestampsOfOptions.start[$(this).find(":selected").text()];
		  var currentEndTime = $endTimeField.find("option:selected").val();
		  $endTimeField.html(
				$endTimeOptions.filter(function() {
				   return startTime < $timestampsOfOptions.end[$(this).text()];
				})
				);
	
		  var endTimeSelected = false;
		  $endTimeField.find("option").each(function() {
			 if ($(this).val() === currentEndTime) {
				$(this).attr("selected", "selected");
				endTimeSelected = true;
				return false;
			 }
		  });
	
		  if (!endTimeSelected) {
			 //automatically select an end date 2 slots away.
			 $endTimeField.find("option:eq(1)").attr("selected", "selected");
		  }
	
	   });
	});
	</script>
</head>

<body>

<div class="container" id="page">
	<?php
		$query=$this->db->get('dentist_login');
		$office = $query->row();
	?>
	<div id="header">
		<div id="logo" class="span-1"><?php echo '<b>'.$office->clinic_name.'</b><br />';?>PAM DENTAL </div>
        <span class="right span-4" style="font-size:13px !important;line-height:1.875em;">
			<?php 

				  echo @$office->first_name.' '.@$office->middle_initial.' '.@$office->last_name.'<br />';
				  echo $office->address_street;
				  echo (@$office->address_apartment_number!='')? ',&nbsp;'.@$office->address_apartment_number.'<br />' : '<br />';
				  echo @$office->address_city;
				  echo ' '.@$office->address_state;
				  echo ' '.@$office->address_zipcode.'<br />';
				  echo '<b>Phone :</b> '.@$office->phone ?>
        </span>
	</div>
        <!-- header -->

	<div id="mainmenu">
            <ul>
                    <li class="<?Php echo ($this->uri->segment(2)=='home')? 'active' : '' ?>"><a href="<?php echo base_url()?>patient/home">Home</a></li>
                    <li class="<?Php echo ($this->uri->segment(2)=='billing_history')? 'active' : '' ?>"><a href="<?php echo base_url()?>patient/billing-history">Billing</a></li>
                    <li class="<?Php echo ($this->uri->segment(2)=='appointment')? 'active' : '' ?>"><a href="<?php echo base_url()?>patient/appointment">Book an Appointment</a></li>
                    <li class="<?Php echo ($this->uri->segment(2)=='treatment_archive')? 'active' : '' ?>"><a href="<?php echo base_url()?>patient/treatment-archive">Treatment Archive</a></li>
                    <li class="<?Php echo ($this->uri->segment(2)=='patient_registration_form_edit')? 'active' : '' ?>"><a href="<?php echo base_url()?>patient/patient-registration-form-edit">Personal Information</a></li>
                    <li class="<?Php echo ($this->uri->segment(2)=='scheduled_appointments')? 'active' : '' ?>"><a href="<?php echo base_url()?>patient/scheduled-appointments">Scheduled Appointments</a></li>
                    <li class="right"><?php 
                 		$string = $this->session->userdata('user_type') =='patient' ? '<a href="'.base_url().'patient/logout">Logout</a>' : '';
           				echo $string;
       		 			?>
                        </li>
            </ul>	
        </div>
        <!-- mainmenu -->
  
<div id="content">
  <h2>Book An Appointment</h2>	
  <div id="calendar_wrapper"></div> 
  <div id="calendar_new_entry_form">
  <form>
    <input type="hidden">
    <input type="hidden" name="patient_id" id="patientId" value="<?php echo $this->session->userdata('patient_id') ?>"/>
    <input type="hidden" name="checkup_id" id="checkupId" value="<?php echo base64_decode($this->uri->segment(3))?>"/>
    <ul>
      <li> <span>
        <label for="title">Patient: <?php echo $this->session->userdata('name') ?><input type="hidden" name="patientName" id="patientName" value="<?php echo $this->session->userdata('name') ?>"/></label>
        </span> </li>
      <li> <span>
        <label for="visit_type">Visit Type: </label>
        </span> <span class="visit_type">
        <select name="visit_type" id="visitType">
         <?php if($this->uri->segment(3)!=''){?>	
         	 <option value="Follow up treatment">Follow up treatment</option>
         <?php }else{?>
          <option value="Consultation">Consultation – 30 min</option>
          <option value="New-Patient">New Patient – 1hr 30 min</option>
          <?php } ?>
        </select>
        </span> </li>
      <li>
        <label><span>Visit Date: </span><span class="date_holder"></span> </label>
      </li>
      <li>
        <label for="start">Start: </label>
        <select name="start">
          <option value="">Select Start Time</option>
        </select>
      </li>
      <li>
        <label for="end">End: </label>
        <select name="end">
          <option value="">Select End Time</option>
        </select>
      </li>
      <li>
        <label for="body">Visit Note: </label>
        <span id="visitnotetext">
        <textarea name="visit_note" id="visitNote"></textarea>
        </span> </li>
    </ul>
  </form>
</div>
</div>
<?php $this->load->view('patient/patient_footer');?>
