<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<meta name="language" content="en" />
	<title><?php echo url_title(@$title);?></title>
	<link rel="stylesheet" type="text/css" href="<?php echo base_url()?>css/front/screen.css" media="screen, projection" />
	<link rel="stylesheet" type="text/css" href="<?php echo base_url()?>css/front/print.css" media="print" />
	<!--[if lt IE 8]>
	<link rel="stylesheet" type="text/css" href="<?php echo base_url()?>css/front/ie.css" media="screen, projection" />
	<![endif]-->

	<link rel="stylesheet" type="text/css" href="<?php echo base_url()?>css/front/main.css" />
	<link rel="stylesheet" type="text/css" href="<?php echo base_url()?>css/front/form.css" />
	<link rel="stylesheet" type="text/css" href="<?php echo base_url()?>css/front/plugins/buttons/screen.css" />
	<link rel="shortcut icon" type="image/x-icon" href="<?php echo base_url()?>images/favicon.ico" />
	<?php 
		echo @$css;
    	echo @$js;
	?>
	<script type ="text/javascript">
			var site_base_path='<?php echo base_url();?>';
        </script>
</head>

<body>

<div class="container" id="page">
	<?php
		$query=$this->db->get('dentist_login');
		$office = $query->row();
	?>
	<div id="header">
		<div id="logo" class="span-1"><?php echo '<b>'.$office->clinic_name.'</b><br />';?>PAM DENTAL </div>
        <span class="right span-4" style="font-size:13px !important;line-height:1.875em;">
			<?php 

				  echo @$office->first_name.' '.@$office->middle_initial.' '.@$office->last_name.'<br />';
				  echo $office->address_street;
				  echo (@$office->address_apartment_number!='')? ',&nbsp;'.@$office->address_apartment_number.'<br />' : '<br />';
				  echo @$office->address_city;
				  echo ' '.@$office->address_state;
				  echo ' '.@$office->address_zipcode.'<br />';
				  echo '<b>Phone :</b> '.@$office->phone ?>
        </span>
	</div>
        <!-- header -->

	<div id="mainmenu">
            <ul>
                    <li class="<?Php echo ($this->uri->segment(2)=='home')? 'active' : '' ?>"><a href="<?php echo base_url()?>patient/home">Home</a></li>
                    <li class="<?Php echo ($this->uri->segment(2)=='billing_history')? 'active' : '' ?>"><a href="<?php echo base_url()?>patient/billing-history">Billing</a></li>
                    <li class="<?Php echo ($this->uri->segment(2)=='appointment')? 'active' : '' ?>"><a href="<?php echo base_url()?>patient/appointment">Book an Appointment</a></li>
                    <li class="<?Php echo ($this->uri->segment(2)=='treatment_archive')? 'active' : '' ?>"><a href="<?php echo base_url()?>patient/treatment-archive">Treatment Archive</a></li>
                    <li class="<?Php echo ($this->uri->segment(2)=='patient_registration_form_edit')? 'active' : '' ?>"><a href="<?php echo base_url()?>patient/patient-registration-form-edit">Personal Information</a></li>
                    <li class="<?Php echo ($this->uri->segment(2)=='scheduled_appointments')? 'active' : '' ?>"><a href="<?php echo base_url()?>patient/scheduled-appointments">Scheduled Appointments</a></li>
                    <li class="right"><?php 
                 		$string = $this->session->userdata('user_type') =='patient' ? '<a href="'.base_url().'patient/logout">Logout</a>' : '';
           				echo $string;
       		 			?>
                        </li>
            </ul>	
        </div><!-- mainmenu -->
