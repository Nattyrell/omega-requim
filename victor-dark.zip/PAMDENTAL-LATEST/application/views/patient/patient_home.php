<?php $this->load->view('patient/patient_header');?>
<?php
    /** CHECK VARIABLES HERE - */
    //echo '<pre>';
    //print_r($this->session->all_userdata()) ;
    //print_r($current_checkups) ;
    //echo '</pre>';
?>
<script type="text/javascript" charset="utf-8">
    $(document).ready(function() {
        $('#example').dataTable({
                "bJQueryUI": true,
                "sPaginationType": "full_numbers"
                });
        $("#at-a-glance").colorbox({maxWidth:"75%", initialWidth:"75%", maxHeight:"400px", initialHeight:"400px", inline:true, href:"#AtAGlance"});
    });
</script>
<style type="text/css">
    tr.top td { border-top: thin solid black; }
    tr.bottom td { border-bottom: thin solid black; }
    tr.row td:first-child { border-left: thin solid black; }
    tr.row td:last-child { border-right: thin solid black; }
</style>
<?php $patient_data = $patient_info->row_array()?>
<div id="content">
  <div style="clear: both; padding-top: 5px; padding-bottom: 5px"><?php echo $this->session->flashdata('show_message')? '<div class="error">'.$this->session->flashdata('show_message').'</div>' :'';?></div>
  <div class="personal_info">
      <?php if($patient_data):?>
    <ul>
      <li>
        <div class="left">PATIENT NAME:</div>
        <div class="right"><?php echo $patient_data['name']?></div>
      </li>
      <li>
        <div class="left">PAM USERNAME:</div>
        <div class="right"><?php echo $patient_data['username']?></div>
      </li>
      <li>
        <div class="left">PATIENT ID:</div>
        <div class="right"><?php echo $patient_data['patient_uin']?></div>
      </li>
      <li>
        <div class="left">Ins. Remaining (US$):</div>
        <div class="right"><font color="#FF2437"><?php echo $patient_data['p_total_insurance']?></font></div>
      </li>
      <li class="last">
        <div align="middle">
            <?php 
                echo anchor('patient/profile-pdf', 'Download PDF');
                $this->db->select('is_primary');
                $this->db->where('patient_id', $this->session->userdata('patient_id'));
                $query = $this->db->get('patient_registration')->row_array();
                if($query){
                if($query['is_primary']=='Y')
                    //echo nbs(1).'|'.nbs(1).anchor('patient/secondry-patient-registration-form', 'Add Secondry Patient');
                    echo nbs(1).'|'.nbs(1)?><a href="#" onclick="$.colorbox({href:'<?php echo base_url()?>patient/user-agreement-primary', maxWidth:'800px', maxHeight:'500px'});">Add Secondry Patient</a>
                <?php }?>
        </div>
      </li>
    </ul>
      <?php endif?>
  </div>
  <div style="clear: both; margin-left: 80px; border-style: solid; border-color: #E63522; border-width: 1px; width: 80%"></div>
  <div style="clear: both; margin-top: 25px"></div>
  
  <div style="float:left; width:80%">
      <h2 class="prepend-2" style=" padding-left: 80px">Pending Treatment Plans</h2>
    <div style="clear: both; margin-top: 5px"></div>
    <div style="float: left; width:100%; padding-left: 80px">
      <table border="0" cellspacing='0' cellpadding='0' id="example" class="display" style="width:100%;">
          <thead>
          <tr>
            <th>S.No.</th>
            <th>Treatment ID</th>
            <?php
                /* ADDED 1-12-2012 Rohitashva Singh */
                if($this->patients->is_patient_registered['is_primary']=='Y'):?>
                <th>Patient UIN</th>
                <th>Patient Name</th>
            <?php
                endif;
                /* -------------------------------- */
            ?>
            <th>Date</th>
            <th>Time</th>
            <th>Status</th>
            <th>Action</th>
          </tr>
          </thead>
          <tbody>
        <?php
                if($current_checkups){
                    $i=1;
                foreach ($current_checkups AS $row):
                ?>
                <tr>
                    <td align = "middle"><?php echo $i.'.'?></td>
                    
                    <td align = "middle"><?php echo $row['treatment_uin']?></td>
                
<!--                    <td align = "middle"><?php printf ('%04d', $this->session->userdata('patient_id'))?></td>-->
                    
                    <?php
                        /* ADDED 1-12-2012 Rohitashva Singh */
                        if($this->patients->is_patient_registered['is_primary']=='Y'):?>
                        <td align = "middle"><?php echo $row['patient_uin']?></td>
                    
                        <td align = "middle"><?php echo $row['name']?></td>
                    <?php
                        endif;
                        /* --------------------------------- */
                    ?>
                    
                    <td align = "middle"><?php echo $row['date']?></td>
                
                    <td align = "middle"><?php echo $row['time']?></td>
                
                    <td align = "middle"><?php echo $row['status']?></td>
                
                    <td align = "middle">
                        <a href="<?php echo base_url()?>patient/view-checkup/<?php echo base64_encode($row['patient_checkup_id'])?>/<?php echo base64_encode($row['patient_id'])?>">View</a>
                        <!--COMMENTED 5-12-2012 10:01 PM-->
                        <?php 
                        /*if($row['paid_for']!='Y'){?>
                            <span id="pay-bill-<?php echo $row['patient_checkup_id']?>" style="display: ">&nbsp;|&nbsp;<a href="<?php echo base_url()?>patient/pay-for-treatment/<?php echo base64_encode($row['patient_checkup_id'])?>/<?php echo base64_encode($row['patient_id'])?>">Pay Bill</a></span>
                        <?php
                        } 
                        else if($row['paid_for']=='Y'){?>
                            <span id="get-appointment-<?php echo $row['patient_checkup_id']?>" style="display: ''">
                                &nbsp;|&nbsp;<a href="<?php echo base_url()?>patient/appointment/<?php echo base64_encode($row['patient_checkup_id'])?>">Get Appointment</a>
                            </span>
                        <?php
                        }*/?>
                    </td>
                </tr>    
                <?php
                $i++;
                endforeach;
                }
                //else echo '<tr><td align = "middle" colspan="6"><h3>.....NO PENDING TREATMENTS......</h3></td></tr>';
                ?>
        </tbody>
    </table>
      <div style="clear: both; margin-top: 5px"></div>
      Treatment Plans&nbsp;<a href="#" id="at-a-glance">at a glance</a>
   </div>
  </div>
  <div style="clear: both; padding-top: 25px"></div>
  <div style="display: none;">
       <div id="AtAGlance">
            <table style="padding: 10px" border="1">
                <thead>
                    <tr>
                        <th>Treatment ID</th>
                        <?php
                        if($this->patients->is_patient_registered['is_primary']=='Y'):?>
                            <th>Patient UIN</th>
                            <th>Patient Name</th>
                        <?php endif;?>
                        <th>Services</th>
                        <th>Treatment Pros.</th>
                        <th>Treatment Cons.</th>
                        <th>Total Payable Amount</th>
                    </tr>
                </thead>
                <tbody style="border-style: solid; border-color: #E63522; border-width: 1px;">
                <?php if($current_checkups){
                    foreach($current_checkups AS $row):
                ?>
                    <tr class="bottom row">
                        <td><?php echo $row['treatment_uin']?></td>
                        <?php
                        if($this->patients->is_patient_registered['is_primary']=='Y'):?>
                            <td align = "middle"><?php echo $row['patient_uin']?></td>
                            <td align = "middle"><?php echo $row['name']?></td>
                        <?php endif;?>
                        <td>
                        <?php
                            echo $this->patients->services_per_checkup($row['patient_checkup_id'])
                        ?>
                        </td>
                        <td><?php echo $row['treatment_pros']?></td>
                        <td><?php echo $row['treatment_cons']?></td>
                        <td>
                            <font color="#FF2437">
                            <?php
                                $patient_grand_total = $this->patients->get_checkup_price($row['patient_id'], $row['patient_checkup_id']);
                                echo '$'.$patient_grand_total['patient_grand_total'];
                            ?>
                            </font>
                        </td>
                    </tr>
                    
                 <?php endforeach;
                }
                else echo '<tr><td colspan="5">No data available.</td></tr>';
                 ?>
                </tbody>
            </table>
    </div>
</div>
</div>
<?php $this->load->view('patient/patient_footer');?>