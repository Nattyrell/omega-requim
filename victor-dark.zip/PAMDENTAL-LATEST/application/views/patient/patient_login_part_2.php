<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
        <head>
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <meta name="language" content="en" />
        <title><?php echo url_title(@$title);?></title>
        <link rel="stylesheet" type="text/css" href="<?php echo base_url()?>/css/front/screen.css" media="screen, projection" />
        <link rel="stylesheet" type="text/css" href="<?php echo base_url()?>/css/front/print.css" media="print" />
        <!--[if lt IE 8]>
	<link rel="stylesheet" type="text/css" href="<?php echo base_url()?>/css/front/ie.css" media="screen, projection" />
	<![endif]-->

        <link rel="stylesheet" type="text/css" href="<?php echo base_url()?>/css/front/main.css" />
        <link rel="stylesheet" type="text/css" href="<?php echo base_url()?>/css/front/form.css" />
        <link rel="stylesheet" type="text/css" href="<?php echo base_url()?>/css/front/plugins/buttons/screen.css" />
        <?php 
		echo @$css;
    	echo @$js;
	?>
        <script type ="text/javascript">
			var site_base_path='<?php echo base_url();?>';
        </script>
        </head>

        <body>
<div class="container" id="page">
	<?php
		$query=$this->db->get('dentist_login');
		$office = $query->row();
	?>
	<div id="header">
		<div id="logo" class="span-1"><?php echo '<b>'.$office->clinic_name.'</b><br />';?>PAM DENTAL </div>
        <span class="right span-4" style="font-size:13px !important;line-height:1.875em;">
			<?php 

				  echo @$office->first_name.' '.@$office->middle_initial.' '.@$office->last_name.'<br />';
				  echo $office->address_street;
				  echo (@$office->address_apartment_number!='')? ',&nbsp;'.@$office->address_apartment_number.'<br />' : '<br />';
				  echo @$office->address_city;
				  echo ' '.@$office->address_state;
				  echo ' '.@$office->address_zipcode.'<br />';
				  echo '<b>Phone :</b> '.@$office->phone ?>
        </span>
	</div>
        <!-- header -->

<div id="mainmenu">
          <ul>
    <li>&nbsp;</li>
  </ul>
        </div>
<!-- mainmenu -->

<div id="content">
          <div class="form">
    <form name="patient-login-form" id="patient-login-form" method="post" action="<?php echo base_url()?>patient/login" enctype="multipart/form-data">
              <fieldset>
        <legend>Patient Login</legend>
        <div><?php echo $this->session->flashdata('login_error')? '<div class="error">'.$this->session->flashdata('login_error').'</div>' :'';?></div>
        <div>&nbsp;</div>
        <div>
                  <label>PATIENT UIN: <span class="required">*</span></label>
                </div>
        <div>
                  <input type="text" class="text" id="p_uin" name= "p_uin" maxlength="255" size="32" value="<?php echo set_value('p_uin'); ?>"/>
                </div>
        <div><font color="#FF2437"><?php echo form_error('p_uin')?></font></div>
        <div></div>

        <p class="buttons">
                  <button class="button positive" type="submit" name="login">Log In</button>
                </p>
        <div>&nbsp;</div>
      </fieldset>
            </form>
  </div>
          <div style="clear: both; padding-top: 10px"></div>
        </div>
<?php $this->load->view('patient/patient_footer');?>
