<?php $this->load->view('patient/patient_header');?>
<?php
/* TEST VARIABLES HERE - */
//echo '<pre>';
//print_r($get_checkup_for_pay);
//echo '</pre>';
$treatment_uin = $this->db->select('treatment_uin')->from('patient_checkup')->where('patient_checkup_id', base64_decode($this->uri->segment(3)))->get()->row_array();
?>
<div id="content">
  <div id="loader" >
    <div id="center"> <img src="<?php echo base_url()?>images/patient/ajax-loader.gif" /> </div>
  </div>
  <h2 style="padding-left: 0px;">TREATMENT:&nbsp;<?php echo @$treatment_uin['treatment_uin']?></h2>
  <form id="pay_for_treatment_form" name="pay_for_treatment_form" method="post" action="<?php echo base_url() ?>patient/pay_for_treatment/<?php echo $this->uri->segment(3)?>/<?php echo $this->uri->segment(4)?>">
    <input type="hidden" value="<?php echo base64_decode($this->uri->segment(3)); ?>" name="patient_checkup_id" />
    <table id="pay_for_treatment_table" name="pay_for_treatment_table" border="1" cellspacing="0" cellpadding="3" width="100%">
      <tr>
        <!--<th>Sr. No.</th>-->
        <!--<th>Tooth Description</th>
        <th>ADA Code Description</th>-->
        <th>Service</th>
        <th>Fee(US$)</th>
        <th>Estimated Insurance Coverage(US$)</th>
        <th>Annual Deductible(US$)</th>
        <th>Estimated Patient Portion(US$)</th>
        <!--<th>Pros.</th>
        <th>Cons.</th>-->
      </tr>
      <?php
      if($get_checkup_for_pay && $get_checkup_price_for_pay):
          $i=1;
          foreach($get_checkup_for_pay as $row):
              ?>
      <tr>
        <!--<td align="middle"><?php echo $i.'.'?></td>-->
        <!--<td align="middle"><?php echo $row['tooth_des']?></td>
        <td align="middle"><?php echo $row['ada_code_desc']?></td>-->
        <td align="middle">
        <?php 
          //$treatment_options = $this->patients->get_treatment_option_values($row['ada_code_id']);
        ?>
          <!--<table align="left">
            <?php
              //if($treatment_options):
              //foreach($treatment_options as $r):?>
            <tr>
              <td width="20%">
                <?php
                  //$checked = $r['treat_id'] == $row['rec_treatment_id'] ? 'checked = "checked"' : ''
                ?>
                <input type ="radio" name="treat[<?php echo $i;?>]" value="<?php echo $r['treat_id']?>" <?php echo $checked?> onchange="change_treatment(this.value, <?php echo $i?>);"></td>
              <td width="80%"><?php echo $r['description']?></td>
            </tr>
            <?php 
            //endforeach;
            //endif;
            ?>
          </table>-->
          <?php
            $query = $this->db->select('description')
                          ->from('treatment_options')
                          ->where('treat_id', $row['rec_treatment_id'])
                          ->get()
                          ->row_array();
            echo $query['description']
          ?>
          <input type ="hidden" name="treat[<?php echo $i;?>]" value="<?php echo $row['rec_treatment_id']?>" size="8">
        </td>
        <!--<td align="middle"><input type="text" name="treat_price[]" id="treat_price_<?php echo $i?>" size="8" value="<?php echo $row['treatment_price']?>" readonly="readonly"></td>
        <td align="middle"><input type="text" name="treat_insurance[]" id="treat_insurance_<?php echo $i?>" size="8" value="<?php echo $row['treatment_insurance']?>" readonly="readonly"></td>
        <td align="middle"><input type="text" name="treat_deductible[]" id="treat_deductible_<?php echo $i?>" size="8" value="<?php echo $row['treatment_deductable']?>" readonly="readonly"></td>-->
        <td align="middle"><?php echo $row['treatment_price']?></td>
        <td align="middle"><?php echo $row['ins_covered_per']?></td>
        <td align="middle"><?php echo $row['annual_deductible']?></td>
        <td align="middle"><?php echo $row['patient_fee']?></td>
        <!--<td>
          <a href="#" class="big-link" data-reveal-id="myModal_pros_<?php echo $i;?>" data-animation="fade">View</a>
          <div id="myModal_pros_<?php echo $i;?>" class="reveal-modal">
            <h2><u>Treatment Pros.</u></h2>
            <span id="pros_<?php echo $i?>"></span> <?php echo $row['treatment_pros']?> <a class="close-reveal-modal">&#215;</a> </div>
        </td>
        <td>
          <a href="#" class="big-link" data-reveal-id="myModal_cons_<?php echo $i;?>" data-animation="fade">View</a>
          <div id="myModal_cons_<?php echo $i;?>" class="reveal-modal">
            <h2><u>Treatment Cons.</u></h2>
            <span id="cons_<?php echo $i?>"></span> <?php echo $row['treatment_cons']?> <a class="close-reveal-modal">&#215;</a> </div>
        </td>-->
      </tr>
      <?php 
        $i++;
        endforeach;
      ?>
      <!--<tr>
        <td align="middle" colspan="4"></td>
        <td align="middle"><input type="text" name="total_price" id="total_price" size="8" value="<?php echo $get_checkup_price_for_pay['total_price']?>" readonly="readonly"></td>
        <td align="middle"><input type="text" name="total_insurance" id="total_insurance" size="8" value="<?php echo $get_checkup_price_for_pay['total_insurance']?>" readonly="readonly"></td>
        <td align="middle"><input type="text" name="total_deductible" id="total_deductible" size="8" value="<?php echo $get_checkup_price_for_pay['total_deductible']?>" readonly="readonly"></td>
        <td align="middle" colspan="2">&nbsp;</td>
      </tr>-->
      <tr>
        <td align="middle" colspan="5">&nbsp;</td>
      </tr>
      <tbody style="background-color: #F5F5F5; border: 1px solid #CCCCCC">
        <tr>
          <td align="middle" colspan="4">
            <font color="#FF2437"><h3>Patient Grand Total&nbsp;-&nbsp;</h3></font>
          </td>
          <td align="middle">
            <?php echo '$'?>
            <input type="text" name="total" id="total" size="8" value="<?php echo $get_checkup_price_for_pay['patient_grand_total']?>" readonly="readonly">
          </td>
        </tr>
      </tbody>
      <tr>
        <td align="middle" colspan="5"><button class="button positive" type="submit" id="submit" name="submit">Proceed with payment</button></td>
      </tr>
      <?php endif;?>
    </table>
  </form>
  <div style="clear: both; padding-top: 25px"></div>
  <style type="text/css">
    #loader
    {
      background-color: #e8e8e8;
        width: 100%;
        height: auto;
        bottom: 0px;
        top: 0px;
        left: 0;
        position: absolute;
        opacity: 0.5;
        filter: progid:DXImageTransform.Microsoft.Alpha(opacity=80);
        display:none;
    }
    #center {
        position: absolute;
        width: 100px;
        height: 50px;
        top: 50%;
        left: 50%;
        margin-top: -25px;
        margin-left: -50px;
        z-index:5;
    }
    </style>
  <script type="text/javascript">
    //function change_treatment(treat_id, id){
    //    $.ajax({url:"<?php echo base_url()?>patient/treatment_detail", type: "POST", data:'treat_id='+treat_id, beforeSend: function(){$('#loader').show();}, complete: function(){$('#loader').hide();}, success:function(result){
    //      var obj = jQuery.parseJSON(result);
    //      $('#treat_price_'+id).val(obj.price);
    //      $('#treat_insurence_'+id).val(obj.treatment_insurence);
    //      $('#treat_deductible_'+id).val(obj.treatment_deductable);
    //      $('#pros_'+id).html(obj.pros);
    //      $('#cons_'+id).html(obj.cons);
    //      //var myForm = document.forms.pay_for_treatment_form;
    //      //var myControls = myForm.elements['treat_price[]'];
    //      var price='0.00';
    //      var ins='0.00';
    //      var ded='0.00';
    //      var m = <?php echo $i?> - parseInt('1');
    //      //alert(m);
    //      //for (var j=1;j<=myControls.length;j++)
    //      for (var j=1;j<=m;j++)
    //      {
    //        price = parseFloat(price)+parseFloat($('#treat_price_'+j).val());
    //        ins = parseFloat(ins)+parseFloat($('#treat_insurance_'+j).val());
    //        ded = parseFloat(ded)+parseFloat($('#treat_deductible_'+j).val());
    //      }
    //      $('#total_price').val(price);
    //      $('#total_insurance').val(ins);
    //      $('#total_deductible').val(ded);
    //      $('#total').val(parseFloat(price)-parseFloat(ins)-parseFloat(ded));
    //  }});
    //}
  </script> 
</div>
<?php $this->load->view('patient/patient_footer');?>
