<?php $this->load->view('patient/patient_header');?>
<div id="content">
                <div style="clear: both; padding-top: 5px; padding-bottom: 5px"><?php echo $this->session->flashdata('pay_error0')? '<div class="error">'.$this->session->flashdata('pay_error0').'</div>' :'';?></div>
                <div style="clear: both; padding-top: 5px; padding-bottom: 5px"><?php echo $this->session->flashdata('pay_error1')? '<div class="error">'.$this->session->flashdata('pay_error1').'</div>' :'';?></div>
		<h2>PAY FOR YOUR TREATMENT</h2>
		<form method="post" action="<?php echo base_url() ?>patient/proceed_with_payment/<?php echo $this->uri->segment(3).'/'.$this->uri->segment(4)?>" name="perform">
                  <input type='hidden' name='paymentType' value="" />
                  <input type='hidden' name='patient_checkup_id' value="<?php echo $this->session->userdata('patient_checkup_id') ?>" />
                  <input type='hidden' name='treat_ids' value="<?php echo join(',',$this->session->userdata('treat_ids')) ?>" />
                      <table width='600'>
                        <tr>
                          <td align='right'>First Name:</td>
                          <td align='left'><input type='text' size='30' maxlength='3' name='first_name' value="<?php echo set_value('first_name', $result['first_name'])?>"></td>
                          <td><font size=2 color="#FF2437"><?php echo form_error('first_name')?></font></td>
                        </tr>
                        <tr>
                          <td align='right'>Last Name:</td>
                          <td align='left'><input type='tex't size='30' maxlength='32' name='last_name' value="<?php echo set_value('last_name', $result['last_name'])?>"></td>
                           <td><font size=2 color="#FF2437"><?php echo form_error('last_name')?></font></td>
                        </tr>
                        <tr>
                          <td align='right'>Card Type:</td>
                          <td align='left'>
                              <select name='card_type'>
                              <option value='' <?php echo set_select('card_type', '', TRUE); ?>>Please Select</option>
                              <option value='Visa' <?php echo set_select('card_type', 'Visa'); ?>>Visa</option>
                              <option value='MasterCard' <?php echo set_select('card_type', 'MasterCard'); ?>>MasterCard</option>
                              <option value='Discover' <?php echo set_select('card_type', 'Discover'); ?>>Discover</option>
                              <option value='Amex' <?php echo set_select('card_type', 'Amex'); ?>>American Express</option>
                            </select>
                          </td>
                         <td><font size=2 color="#FF2437"><?php echo form_error('card_type')?></font></td>                            
                        </tr>
                        <tr>
                          <td align='right'>Card Number:</td>
                          <td align='left'><input type='text' size='19' maxlength='19' name='card_number' value="<?php echo set_value('card_number', ''); ?>"></td>
                           <td><font size=2 color="#FF2437"><?php echo form_error('card_number')?></font></td>
                        </tr>
                        <tr>
                          <td align='right'>Expiration Date:</td>
                          <td align='left'>
                              <p>
                                <select name='expDateMonth'>
                                  <option value='1' <?php echo set_select('expDateMonth', '1', TRUE); ?>>01</option>
                                  <option value='2' <?php echo set_select('expDateMonth', '2'); ?>>02</option>
                                  <option value='3' <?php echo set_select('expDateMonth', '3'); ?>>03</option>
                                  <option value='4' <?php echo set_select('expDateMonth', '4'); ?>>04</option>
                                  <option value='5' <?php echo set_select('expDateMonth', '5'); ?>>05</option>
                                  <option value='6' <?php echo set_select('expDateMonth', '6'); ?>>06</option>
                                  <option value='7' <?php echo set_select('expDateMonth', '7'); ?>>07</option>
                                  <option value='8' <?php echo set_select('expDateMonth', '8'); ?>>08</option>
                                  <option value='9' <?php echo set_select('expDateMonth', '9'); ?>>09</option>
                                  <option value='10' <?php echo set_select('expDateMonth', '10'); ?>>10</option>
                                  <option value='11' <?php echo set_select('expDateMonth', '11'); ?>>11</option>
                                  <option value='12' <?php echo set_select('expDateMonth', '12'); ?>>12</option>
                                </select>
                                <select name='expDateYear'>
                                  <option value="<?php echo date('Y')?>" <?php echo set_select('expDateYear', date('Y'), TRUE); ?>><?php echo date('Y')?></option>
                                  <?php for ($y=1;$y<=10;$y++){?>
                                    <option value="<?php echo date('Y')+$y?>" <?php echo set_select('expDateYear', date('Y')+$y); ?>><?php echo date('Y')+$y?></option>
                                  <?php }?>
                                </select>
                            </p>
                          </td>
                             <td>
                                 <font size=2 color="#FF2437"><?php echo form_error('expDateMonth')?></font><br/>
                                 <font size=2 color="#FF2437"><?php echo form_error('expDateYear')?></font>
                             </td>
                        </tr>
                        <tr>
                          <td align='right'>Card Verification Number:</td>
                          <td align='left'><input type='text' size='3' maxlength='4' name='card_verification_number' value='<?php echo set_value('card_verification_number', ''); ?>'></td>
                           <td><font size=2 color="#FF2437"><?php echo form_error('card_verification_number')?></font></td>
                        </tr>
                        <tr>
                          <td align='right'><br>
                            <b>Billing Address:</b></td>
                        </tr>
                        <tr>
                          <td align='right'>Address 1:</td>
                          <td align='left'><input type='text' size='25' maxlength='100' name='address1' value="<?php echo set_value('card_verification_number', $result['p_address_street']); ?>"></td>
                           <td><font size=2 color="#FF2437"><?php echo form_error('address1')?></font></td>
                        </tr>
                        <tr>
                          <td align='right'>Address 2:</td>
                          <td align='left'><input type='text'  size='25' maxlength='100' name='address2' value="<?php echo @$_POST['address2'] ? @$_POST['address2'] : $result['p_address_apartment_number'] ?>">
                            (optional)</td>
                        </tr>
                        <tr>
                          <td align='right'>City:</td>
                          <td align='left'><input type='text' size='25' maxlength='40' name='city' value="<?php echo set_value('city', $result['p_address_city']); ?>"></td>
                           <td><font size=2 color="#FF2437"><?php echo form_error('city')?></font></td>
                        </tr>
                        <tr>
                          <td align='right'>State:</td>
                          <td align='left'>
                              <select name="state" id="state">
                              <option id="0" value='' <?php echo set_select('state', '', TRUE); ?>>Please Select</option>
                              <?php
                                $states = array();
                                foreach($us_states->result_array() AS $row){
                                   $states[$row['id']] = $row['state'];
                                }
                                //echo form_dropdown('state', $states, '');

                                foreach($states AS $key=>$val):?>
                                    <option id="<?php echo $key?>" value="<?php echo $key?>" <?php echo set_select('state', $key); ?>><?php echo $val?></option>
                                <?php
                                endforeach;
                                ?>
                            </select>
                         <td><font size=2 color="#FF2437"><?php echo form_error('state')?></font></td>
                        </tr>
                        <tr>
                          <td align='right'>ZIP Code:</td>
                          <td align='left'><input type='text' size='10' maxlength='10' name='zip' value="<?php echo set_value('zip', $result['p_address_zipcode']); ?>">
                            (5 or 9 digits)</td>
                           <td><font size=2 color="#FF2437"><?php echo form_error('zip')?></font></td>  
                        </tr>
                        <tr>
                          <td align='right'>Country:</td>
                          <td align='left'><input type='text' size='10' readonly="readonly" name='country' value="<?php echo set_value('country', 'United States'); ?>" /></td>
                           <td><font size=2 color="#FF2437"><?php echo form_error('country')?></font></td>
                        </tr>
                        <tr>
                          <td align='right'><br>
                            Amount:</td>
                          <td align='left'><br>
                            <input type='text' size='4' maxlength='7' name='amount' readonly="readonly" value="<?php echo set_value('amount', $this->session->userdata('total_amount')); ?>">
                            USD</td>
                          <td><font size=2 color="#FF2437"><?php echo form_error('amount')?></font></td>  
                        </tr>
                        <tr>
                          <td/>
                          <td><input type='submit' name="submit" value='Submit'></td>
                        </tr>
                      </table>
		</form>
            
      </div>      
<?php $this->load->view('patient/patient_footer');?>
