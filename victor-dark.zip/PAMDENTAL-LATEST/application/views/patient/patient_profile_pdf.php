<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
<style>
body {
	font-family: verdana;
	font-size:10px;
	text-align:justify;
	margin:0px 40pt;
}
.underline {
	text-decoration:underline;
	font-weight:bold;
	text-align:center;
}
.table {
	margin-top: 2em;
	border-color:#000;
	border-style:solid;
}
table #innerblock {
	margin:0px;
	padding:0px 0px 0px 5px;
	border-collapse: collapse;
	border: 1pt solid black;
	border-top:none;
	border-left:none;
}
thead {
	background-color: #eeeeee;
}
tbody {
	background-color: #ffffee;
}
th, td {
	padding: 3pt;
}
table.collapse {
	border-collapse: collapse;
	border: 1px solid black;
}
table.collapse td {
	border: 1px solid black;
}
table.collapse th {
	border: 1px solid black;
}
#spacing {
	margin:3pt 0pt 3pt 4pt !important;
	line-height:17px;
}
</style>
</head>
<body>
<div style=" margin-left:25px; margin-right:25px">
  <p align="center" style="font-size:20px;"><b><u>PAM DENTAL</u></b></p>
  <p></p>
  <?php
    $states = array();
    foreach($us_states as $row):
        $states[$row['id']] = $row['state'];
    endforeach;
    $states[''] = 'N.A';
    $states[0] = 'N.A';

	$gender=array('M'=>'Male','F'=>'Female');	
	$marital_status=array('1'=>'Married','2'=>'Single','3'=>'Child');	
	$spouse=array('S'=>'the patient\'s spouse','P'=>'the person responsible for payment','PR'=>'the person responsible for payment');	
	
    ?>
  <table cellspacing="0" cellpadding="0" border="0" width="100%">
    <tr>
      <td colspan="4"><h2 class="underline">Patient Information</h2></td>
    </tr>
    <tr>
      <td colspan="2">Patient Name: <?php echo $result['first_name'].' '.$result['middle_initial'].' '.$result['last_name']  ?></td>
      <td colspan="2">Registration Date: <?php echo $result['registration_date'] ?></td>
    </tr>
    <tr>
      <td colspan="2">Username: <?php echo $result['username'] ?></td>
      <td colspan="2">Email: <?php echo $result['email'] ?></td>
    </tr>
    <tr>
      <td colspan="2">Gender: <?php echo $gender[$result['p_sex']] ?></td>
      <td colspan="2">Marital Status: <?php echo ($result['p_marital_status'])? ($result['p_marital_status']==4)? $result['p_marital_status_other'] : $marital_status[$result['p_marital_status']] : '' ?></td>
    </tr>
    <tr>
      <td>Socail Security#: <?php echo $result['p_ssn'] ?></td>
      <td>Driving License#: <?php echo $result['p_dln'] ?></td>
      <td colspan="2">Date of Birth: <?php echo $result['p_dob'] ?></td>
    </tr>
    <tr>
      <td>Address: <?php echo $result['p_address_street'].' '.$result['p_address_apartment_number'] ?></td>
      <td>City: <?php echo $result['p_address_city'] ?></td>
      <td>State: <?php echo $states[$result['p_address_state_id']] ?></td>
      <td>Zip Code: <?php echo $result['p_address_zipcode'] ?></td>
    </tr>
    <tr>
      <td>Phone: <?php echo ($result['p_phone_home'])? $result['p_phone_home'] : ''; ?></td>
      <td>Work: <?php echo ($result['p_phone_work'])? $result['p_phone_work'] : ''?></td>
      <td colspan="2">Cell: <?php echo $result['p_phone_cell'] ?></td>
    </tr>
    <tr>
      <td colspan="4">Practice Reference: <?php echo $result['p_practice_reference'] ?></td>
    </tr>
    <tr>
      <td colspan="4"><h2 class="underline">Spouse or Responsible Party Information</h2></td>
    </tr>
    <tr>
      <td colspan="4">The following is for: <?php echo $spouse[$result['srp_following_is_for']] ?></td>
    </tr>
    <tr>
      <td colspan="4">Name: <?php echo $result['srp_first_name'].' '.$result['srp_middle_initial'].' '.$result['srp_last_name'] ?></td>
    </tr>
    <tr>
      <td colspan="2">Gender: <?php echo $gender[$result['srp_sex']] ?></td>
      <td colspan="2">Marital Status: <?php echo ($result['srp_marital_status'])? ($result['srp_marital_status']==4)? $result['srp_marital_status_other'] : $marital_status[$result['srp_marital_status']] : '' ?></td>
    </tr>
    <tr>
      <td colspan="2">Social Security#: <?php echo $result['srp_ssn'] ?></td>
      <td colspan="2">Date of Birth: <?php echo $result['srp_dob'] ?></td>
    </tr>
    <tr>
      <td>Address: <?php echo $result['srp_address_street'].'<br/>'.$result['srp_address_apartment_number'] ?></td>
      <td>City: <?php echo $result['srp_address_city'] ?></td>
      <td>State: <?php echo $states[$result['srp_address_state_id']] ?></td>
      <td>Zip Code: <?php echo $result['srp_address_zipcode'] ?></td>
    </tr>
    <tr>
      <td colspan="2">Phone: <?php echo ($result['srp_phone_home'])? $result['srp_phone_home'].' (H)' : ''; echo ($result['srp_phone_work'])? $result['srp_phone_work'].' (O)' : ''?></td>
      <td colspan="2">Phone Ext: <?php echo $result['srp_phone_ext'] ?></td>
    </tr>
    <tr>
      <td colspan="4">Best Time To Call: <?php echo $result['srp_best_time_call'] ?></td>
    </tr>
    <tr>
      <td colspan="2"><h2>Employment Information: </h2></td>
      <td colspan="2">The following is for: <?php echo @$spouse[$result['e_following_is_for']] ?></td>
    </tr>
    <tr>
      <td colspan="2">Employer's Name: <?php echo $result['e_name'] ?></td>
      <td colspan="2">Occupation: <?php echo $result['e_occupation'] ?></td>
    </tr>
    <tr>
      <td>Address: <?php echo $result['e_address_street'] ?></td>
      <td>City: <?php echo $result['e_address_city'] ?></td>
      <td>State: <?php echo $states[$result['e_address_state_id']] ?></td>
      <td>Zip Code: <?php echo $result['e_address_zipcode'] ?></td>
    </tr>
    <tr>
      <td>Total Insurance Remaining</td>
      <td><?php echo $result['p_total_insurance'] ?></td>
    </tr>
  </table>
  <p></p>
  <table cellspacing="0" cellpadding="0" border="0" width="100%">
    <tr>
      <td colspan="4"><h2 class="underline">Insurance Information - Primary Insurance</h2></td>
    </tr>
    <tr>
      <td colspan="2">Name of Insured: <?php echo $result['pi_first_name'].' '.$result['pi_middle_initial'].' '.$result['pi_last_name'] ?></td>
      <td colspan="2">Is insured a patient: <?php echo $result['pi_is_insured_patient'] ?></td>
    </tr>
    <tr>
      <td colspan="2">Insured's Birth Date: <?php echo $result['pi_dob'] ?></td>
      <td>ID #: <?php echo $result['pi_id'] ?></td>
      <td>Group #: <?php echo $result['pi_group'] ?></td>
    </tr>
    <tr>
      <td>Insured's Address: <?php echo $result['pi_address_street'] ?></td>
      <td>City: <?php echo $result['pi_address_city'] ?></td>
      <td>State: <?php echo $states[$result['pi_address_state_id']] ?></td>
      <td>Zip Code: <?php echo $result['pi_address_zipcode'] ?></td>
    </tr>
    <tr>
      <td colspan="4">Insured's Employer Name: <?php echo $result['pi_emp_name'] ?></td>
    </tr>
    <tr>
      <td>Insured's Employer Address: <?php echo $result['pi_emp_address_street'] ?></td>
      <td>Insured's Employer City: <?php echo $result['pi_emp_address_city'] ?></td>
      <td>Insured's Employer State: <?php echo $states[$result['pi_emp_address_state_id']] ?></td>
      <td>Insured's Employer Zip Code: <?php echo $result['pi_emp_address_zipcode'] ?></td>
    </tr>
    <tr>
      <td colspan="4">Patient's relationship to insured: <?php echo $result['pi_patient_relation'] ?></td>
    </tr>
    <tr>
      <td colspan="4">Ins. Plan Name and Address: <?php echo $result['pi_insurance_plan_address'] ?></td>
    </tr>
    <tr>
      <td colspan="4"><h2 class="underline">Insurance Information - Secondry Insurance</h2></td>
    </tr>
    <tr>
      <td colspan="2">Name of Insured: <?php echo $result['si_first_name'].' '.$result['si_middle_initial'].' '.$result['si_last_name'] ?></td>
      <td colspan="2">Is insured a patient: <?php echo $result['si_is_insured_patient'] ?></td>
    </tr>
    <tr>
      <td colspan="2">Insured's Birth Date: <?php echo $result['si_dob'] ?></td>
      <td>ID #: <?php echo $result['si_id'] ?></td>
      <td>Group #: <?php echo $result['si_group'] ?></td>
    </tr>
    <tr>
      <td>Insured's Address: <?php echo $result['si_address_street'] ?></td>
      <td>City: <?php echo $result['si_address_city'] ?></td>
      <td>State: <?php echo $states[$result['si_address_state_id']] ?></td>
      <td>Zip Code: <?php echo $result['si_address_zipcode'] ?></td>
    </tr>
    <tr>
      <td colspan="4">Insured's Employer Name: <?php echo $result['si_emp_name'] ?></td>
    </tr>
    <tr>
      <td>Insured's Employer Address: <?php echo $result['si_emp_address_street'] ?></td>
      <td>Insured's Employer City: <?php echo $result['si_emp_address_city'] ?></td>
      <td>Insured's Employer State: <?php echo $states[$result['si_emp_address_state_id']] ?></td>
      <td>Insured's Employer Zip Code: <?php echo $result['si_emp_address_zipcode'] ?></td>
    </tr>
    <tr>
      <td colspan="4">Patient's relationship to insured: <?php echo $result['si_patient_relation'] ?></td>
    </tr>
    <tr>
      <td colspan="4">Ins. Plan Name and Address: <?php echo $result['si_insurance_plan_address'] ?></td>
    </tr>
  </table>
  <p></p>
  <table cellspacing="0" cellpadding="0" border="0" width="100%" class="collapse">
    <tr>
      <td colspan="2"><h2 class="underline">Health Conditions</h2></td>
    </tr>
    <?php
                      $arr_health_con = unserialize($result['p_health_condition']);
                      if(!empty($arr_health_con)){
                        $health_con = implode("', '", $arr_health_con);
                        $health_con = str_replace("'\'", '', $arr_health_con);
                        $res = $this->patients->select_health_con($health_con);
                        if($res){$i=0;
                            foreach($res as $row):?>
    <tr>
      <td><?php echo $i+=1;?></td>
      <td><?php echo $row['description']?></td>
    </tr>
    <?php 
                            endforeach;
                        }
                        else echo '<tr><td colspan="2">N.A.</td></tr>';
                      }
                      else echo '<tr><td colspan="2">N.A.</td></tr>';
                      ?>
  </table>
   <p></p>
  <table cellspacing="0" cellpadding="0" border="0" width="100%" class="collapse">
    <tr>
      <td colspan="2"><h2 class="underline">Medical & Dental Health Information</h2></td>
    </tr>
	<tr><td colspan="2">Physicians /Health Professionals, Names & Phone Numbers </td></tr>
    <tr><td>Name: <?php echo $result['physician_health_prof_name_1'] ?></td><td>Phone: <?php echo $result['physician_health_prof_phone_1'] ?></td></tr>
    <tr><td>Name: <?php echo $result['physician_health_prof_name_2'] ?></td><td>Phone: <?php echo $result['physician_health_prof_phone_2'] ?></td></tr>
    <tr><td>Name: <?php echo $result['physician_health_prof_name_3'] ?></td><td>Phone: <?php echo $result['physician_health_prof_phone_3'] ?></td></tr>
    <tr><td>Name: <?php echo $result['physician_health_prof_name_4'] ?></td><td>Phone: <?php echo $result['physician_health_prof_phone_4'] ?></td></tr>
  </table>
   <p></p>
  <table cellspacing="0" cellpadding="0" border="0" width="100%" class="collapse">
    <tr>
      <td colspan="2"><h2 class="underline">Other Medicines or Neutricuticals</h2></td>
    </tr>
    <?php
                      $arr_other_med = unserialize($result['p_health_condition']);
                      if(!empty($arr_health_con)){
                        $other_med = implode("', '", $arr_other_med);
                        $other_med = str_replace("'\'", '', $arr_other_med);
                        $res = $this->patients->select_other_medicines($other_med);
                        if($res){
                            foreach($res as $row):?>
    <tr>
      <td><?php echo $row['description']?></td>
      <td><b>Yes</b></td>
    </tr>
    <?php 
                            endforeach;
                        }
                         else echo '<tr><td colspan="2">N.A.</td></tr>';
                      }
                       else echo '<tr><td colspan="2">N.A.</td></tr>';
                      ?>
  </table>
   <p></p>
  <table width="100%" cellpadding="0" cellspacing="0" border="0">
    <tr>
      <td colspan="2"><h2 class="underline">Consents:</h2></td>
    </tr>
    <tr>
      <td valign="top">-</td>
      <td valign="top">I consent to: medical/dental history review, dental exam, X-rays, photos, and any treatment as indicated on my examination form, or treatment plan, including the use of local anesthetics, and oral sedation as necessary. I authorize Dr. Lee Ostler and/or dental staff to take photographs (pictures) relevant to the diagnosis of and explanation of dental conditions or problems. These images will be used as a record of my condition, care and treatment, to assist in diagnosis and treatment planning, and in communication with dental laboratories who may assist in my care.</td>
    </tr>
    <tr>
      <td>-</td>
      <td>I understand that The Center for Dental Health is a private fee-for-service practice, is not a party to any health plan insurers, that all services will be charged directly to the patient/responsible party, and that responsibility for payment for dental services provided by this office for myself or my dependent is solely mine, with full payment due and payable at the time of services rendered, unless other financial arrangements have been agreed upon. As a condition of treatment in this office, financial arrangements must be made in advance to the delivery of services.Consent for and acceptace of services will constitute agreement to this understanding.</td>
    </tr>
  </table>
   <p></p>
  <table cellpadding="0" cellspacing="0" border="0" width="100%">
    <tr>
      <td width="60%">__________________________</td>
      <td width="20%">__________________________</td>
      <td width="20%">__________________________</td>
    </tr>
    <tr>
      <td width="60%">Signature of patient, parent or guardian (online-type name on form)</td>
      <td width="20%">Date</td>
      <td width="20%">Relationship to Patient</td>
    </tr>
  </table>
</div>
</body>
</html>