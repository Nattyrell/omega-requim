<?php $this->load->view('patient/patient_header');?>
<script type ="text/javascript">
    $(document).ready(function() { 
        $(function(){
        $(".someClass").tipTip();
        });
    });
</script>
<script type ="text/javascript">
	$(function() {
		$( "#dob" ).datepicker({
			showOn: "button",
			buttonImage: "<?php echo base_url()?>images/patient/datepicker/calendar.gif",
			buttonImageOnly: true,
                        changeMonth: true,
			changeYear: true,
                        dateFormat: "yy-mm-dd",
                        yearRange: "c-100:c+0"
		});
	});
        
        $(function() {
		$( "#srp-dob" ).datepicker({
			showOn: "button",
			buttonImage: "<?php echo base_url()?>images/patient/datepicker/calendar.gif",
			buttonImageOnly: true,
                        changeMonth: true,
			changeYear: true,
                        dateFormat: "yy-mm-dd",
                        yearRange: "c-100:c+0"
		});
	});
        
        $(function() {
		$( "#pi-dob" ).datepicker({
			showOn: "button",
			buttonImage: "<?php echo base_url()?>images/patient/datepicker/calendar.gif",
			buttonImageOnly: true,
                        changeMonth: true,
			changeYear: true,
                        dateFormat: "yy-mm-dd",
                        yearRange: "c-100:c+0"
		});
	});
        
        $(function() {
		$( "#si-dob" ).datepicker({
			showOn: "button",
			buttonImage: "<?php echo base_url()?>images/patient/datepicker/calendar.gif",
			buttonImageOnly: true,
                        changeMonth: true,
			changeYear: true,
                        dateFormat: "yy-mm-dd",
                        yearRange: "c-100:c+0"
		});
	});
</script>
<style type="text/css">
#ui-datepicker-div {
	font-size: 100%;
}
</style>
<style type="text/css">
.section {
	background-color: #F5F9F8
}
</style>

<div id="content">
<div style="padding-top: 10px; padding-bottom: 10px"><?php echo ($this->session->flashdata('profile_updated'))? '<div class="error"><code>'.$this->session->flashdata('profile_updated').'</code></div>' : ''; ?></div>
  <form id="patient-registration-form-edit" name="patient-registration-form-edit" method="post" action="<?php echo base_url()?>patient/patient-registration-form-edit" enctype="multipart/form-data">
    <?php /*?>Patient Information<?php */?>
    <fieldset class="section">
      <legend>Patient Information</legend>
      <div style="clear: both; padding-top: 5px"></div>
      <div style="float:left; width:200px">
        <label>First Name</label>
        <input type="text" id="first-name" name= "first-name" maxlength="255" size="16" readonly="true" value="<?php echo set_value('first-name',$result['first_name'])?>"/>
      </div>
      <div style="float:left; width:200px; padding-left: 5px;">
        <label>Last Name</label>
        <input type="text" id="last-name" name= "last-name" maxlength="255" size="16" readonly="true" value="<?php echo set_value('last-name',$result['last_name'])?>"/>
      </div>
      <div style="float:left; width:100px; padding-left: 5px;">
        <label>MI</label>
        <input type="text" id="middle-initial" name= "middle-initial" maxlength="1" size="4" readonly="true" value="<?php echo set_value('middle-initial',$result['middle_initial'])?>"/>
      </div>
      <div style="float:left; width:200px; padding-left: 50px">
        <label>Date</label>
        <input type="text" id="date" name= "date" size="16" readonly="true" value="<?php echo date('m-d-Y');?>"/>
      </div>
      <div style="clear: both; padding-top: 25px"></div>
      <div style="float: left">
        <div style="float: left; width:50px;">
          <label>Male</label>
        </div>
        <div style="float: left; width:50px; padding-left: 5px">
          <input type="radio" id="male" name="sex" value="M" <?php echo set_radio('sex', 'M',($result['p_sex']=='M')? true : false); ?>>
        </div>
      </div>
      <div style="clear: both; padding-top: 5px"></div>
      <div style="float: left">
        <div style="float: left; width:50px;">
          <label>Female</label>
        </div>
        <div style="float: left; width:50px; padding-left: 5px">
          <input type="radio" id="female" name="sex" value="F" <?php echo set_radio('sex', 'F',($result['p_sex']=='F')? true : false); ?>>
        </div>
      </div>
      <div style="clear: both; padding-top: 5px"></div>
      <div style="float: left"><font size=2 color="#FF2437"><?php echo form_error('sex')?></font></div>
      <div style="clear: both; padding-top: 25px"></div>
      <div style="float: left">
        <?php 
                foreach($patient_status AS $key => $val):?>
        <div style="float: left; width:100px;">
          <label><?php echo $val?></label>
        </div>
        <div style="float: left; width:100px; padding-left: 5px">
          <input type="radio" id="status_<?php echo $key?>" name="status" value="<?php echo $key?>" <?php echo set_radio('status', $key,($result['p_marital_status']==$key)? true : false); ?>>
        </div>
        <div style="clear: both; padding-top: 5px"></div>
        <?php endforeach;?>
      </div>
      <div style="clear: both; padding-top: 5px"></div>
      <div style="float: left"><font size=2 color="#FF2437"><?php echo form_error('status')?></font></div>
      <div style="clear: both; padding-top: 5px"></div>
      <div style="float:left">
        <div style="float: left; width:150px;">
          <label>If Other (above)</label>
        </div>
        <div style="float: left; width:150px; padding-left: 5px">
          <input type="text" name="martial-status-other" maxlength="25" id="martial-status-other" size="16" value="<?php echo @$_POST ? @$_POST['martial-status-other'] : $result['p_marital_status_other']?>">
        </div>
      </div>
      <div style="clear: both; padding-top: 25px"></div>
      <div style="float:left;">
        <div style="float: left; width:150px;">
          <label>Social Security #</label>
        </div>
        <div style="float: left; width:150px; padding-left: 5px">
          <input type="text" name="ssn" id="ssn" maxlength="50" size="16" value="<?php echo set_value('ssn',$result['p_ssn'])?>">
        </div>
      </div>
      <div style="clear: both; padding-top: 5px"></div>
      <div style="float: left"><font size=2 color="#FF2437"><?php echo form_error('ssn')?></font></div>
      <div style="clear: both; padding-top: 25px"></div>
      <div style="float:left;">
        <div style="float: left; width:150px;">
          <label>Drivers Lic.#</label>
        </div>
        <div style="float: left; width:150px; padding-left: 5px">
          <input type="text" name="dln" id="dln" maxlength="50" size="16" value="<?php echo set_value('dln',$result['p_dln'])?>">
        </div>
      </div>
      <div style="clear: both; padding-top: 5px"></div>
      <div style="float: left"><font size=2 color="#FF2437"><?php echo form_error('dln')?></font></div>
      <div style="clear: both; padding-top: 25px"></div>
      <div style="float:left;">
        <div style="float: left; width:150px;">
          <label>Birth Date</label>
        </div>
        <div style="float: left; width:150px; padding-left: 5px">
          <input type="text" name="dob" id="dob" size="16" value="<?php echo set_value('dob',$result['p_dob'])?>">
        </div>
      </div>
      <div style="clear: both; padding-top: 5px"></div>
      <div style="float: left"><font size=2 color="#FF2437"><?php echo form_error('dob')?></font></div>
      <div style="clear: both; padding-top: 25px"></div>
      <div style="float:left">
        <div style="float: left; width:150px;">
          <label>Phone (Home)</label>
        </div>
        <div style="float: left; width:150px; padding-left: 5px">
          <input type="tel" name="phone-home" id="phone-home" maxlength="50" size="32" value="<?php echo set_value('phone-home',$result['p_phone_home'])?>">
        </div>
      </div>
      <div style="clear: both; padding-top: 5px"></div>
      <div style="float: left"><font size=2 color="#FF2437"><?php echo form_error('phone-home')?></font></div>
      <div style="clear: both; padding-top: 25px"></div>
      <div style="float:left">
        <div style="float: left; width:150px;">
          <label>Phone (Work)</label>
        </div>
        <div style="float: left; width:150px; padding-left: 5px">
          <input type="tel" name="phone-work" id="phone-work" maxlength="50" size="32" value="<?php echo set_value('phone-work',$result['p_phone_work'])?>">
        </div>
      </div>
      <div style="clear: both; padding-top: 5px"></div>
      <div style="float: left"><font size=2 color="#FF2437"><?php echo form_error('phone-work')?></font></div>
      <div style="clear: both; padding-top: 25px"></div>
      <div style="float:left">
        <div style="float: left; width:150px;">
          <label>Phone (Cell)</label>
        </div>
        <div style="float: left; width:150px; padding-left: 5px">
          <input type="tel" name="phone-cell" id="phone-cell" maxlength="50" size="32" value="<?php echo set_value('phone-cell',$result['p_phone_cell'])?>">
        </div>
      </div>
      <div style="clear: both; padding-top: 5px"></div>
      <div style="float: left"><font size=2 color="#FF2437"><?php echo form_error('phone-cell')?></font></div>
      <div style="clear: both; padding-top: 25px"></div>
      <div style="float:left">
        <div style="float: left; width:150px;">
          <label>Email</label>
        </div>
        <div style="float: left; width:150px; padding-left: 5px">
          <input type="email" name="email" id="email" maxlength="50" size="32" value="<?php echo set_value('email',$result['email'])?>">
        </div>
      </div>
      <div style="clear: both; padding-top: 5px"></div>
      <div style="float: left"><font size=2 color="#FF2437"><?php echo form_error('email')?></font></div>
      <div style="clear: both; padding-top: 25px"></div>
      <fieldset>
        <legend>Address</legend>
        <div style="clear: both; padding-top: 5px"></div>
        <div style="float:left">
          <div style="float:left; width: 150px">
            <label>Street</label>
          </div>
          <div style="float:left; width: 150px">
            <input type="text" name="street" id="street" maxlength="255" size="32" value="<?php echo set_value('street',$result['p_address_street'])?>">
          </div>
        </div>
        <div style="clear: both; padding-top: 5px"></div>
        <div style="float: left"><font size=2 color="#FF2437"><?php echo form_error('street')?></font></div>
        <div style="clear: both; padding-top: 5px"></div>
        <div style="float:left">
          <div style="float:left; width: 150px">
            <label>Apartment #</label>
          </div>
          <div style="float:left; width: 150px">
            <input type="text" name="apartment-number" id="apartment-number" maxlength="50" size="16" value="<?php echo set_value('apartment-number',$result['p_address_apartment_number'])?>">
          </div>
        </div>
        <div style="clear: both; padding-top: 5px"></div>
        <div style="float: left"><font size=2 color="#FF2437"><?php echo form_error('apartment-number')?></font></div>
        <div style="clear: both; padding-top: 5px"></div>
        <div style="float:left">
          <div style="float:left; width: 150px">
            <label>City</label>
          </div>
          <div style="float:left; width: 150px">
            <input type="text" name="city" id="city" maxlength="255" size="16" value="<?php echo set_value('city',$result['p_address_city'])?>">
          </div>
        </div>
        <div style="clear: both; padding-top: 5px"></div>
        <div style="float: left"><font size=2 color="#FF2437"><?php echo form_error('city')?></font></div>
        <div style="clear: both; padding-top: 5px"></div>
        <div style="float:left">
          <div style="float:left; width: 150px">
            <label>State</label>
          </div>
          <div style="float:left; width: 150px">
            <select name="state" id="state">
              <option id="0" value="" <?php echo set_select('state', ''); ?>>Please Select</option>
              <?php
                            $states = array();
                            foreach($us_states->result_array() AS $row){
                               $states[$row['id']] = $row['state_abbr'];
                            }
                            //echo form_dropdown('state', $states, '');
                            
                            foreach($states AS $key=>$val):?>
              <option id="<?php echo $key?>" value="<?php echo $key?>" <?php echo set_select('state', $key,($result['p_address_state_id']==$key)? TRUE : false); ?>><?php echo $val?></option>
              <?php
                            endforeach;
                            ?>
            </select>
          </div>
        </div>
        <div style="clear: both; padding-top: 5px"></div>
        <div style="float: left"><font size=2 color="#FF2437"><?php echo form_error('state')?></font></div>
        
      </fieldset>
      <div style="clear: both; padding-top: 25px"></div>
      <div style="float:left">
        <div style="float: left; width:400px;">
          <label>Whom may we thank for referring you to our practice?</label>
        </div>
        <div style="float: left; width:150px; padding-left: 5px">
          <input type="text" name="practice-reference" id="practice-reference" maxlength="50" size="32" value="<?php echo $result['p_practice_reference'] ?>">
        </div>
      </div>
      <div style="clear: both; padding-top: 25px"></div>
    </fieldset>
    <div style="clear: both; padding-top: 25px"></div>
    <?php /*?>Spouse or Responsible Party Information<?php */?>
    <fieldset class="section">
      <legend>Spouse or Responsible Party Information</legend>
      <div style="clear: both; padding-top: 5px"></div>
      <div style="float: left">
        <div style="float:left; width:150px;">The following is for:</div>
        <div style="float:left; width:200px; padding-left: 5px;">
          <label>the patient's spouse</label>
          <input type="radio" name="srp-following-is-for" id="srp-following-is-for" value="S"<?php echo set_radio('srp-following-is-for', 'S',($result['srp_following_is_for']=='S')? TRUE : false); ?>>
        </div>
        <div style="float:left; width:300px; padding-left: 5px;">
          <label>the person responsible for payment</label>
          <input type="radio" name="srp-following-is-for" id="srp-following-is-for" value="P"<?php echo set_radio('srp-following-is-for', 'P',($result['srp_following_is_for']=='P')? TRUE : false); ?>>
        </div>
      </div>
      <div style="clear: both; padding-top: 5px"></div>
      <div style="float: left"><font size=2 color="#FF2437"><?php echo form_error('srp-following-is-for')?></font></div>
      <div style="clear: both; padding-top: 25px"></div>
      <div style="float: left">
        <div style="float:left; width:250px;">
          <label>First Name</label>
          <input type="text" name="srp-first-name" id="srp-first-name" maxlength="255" size="16" value="<?php echo set_value('srp-first-name',$result['srp_first_name']); ?>"/>
        </div>
        <div style="float:left; width:250px; padding-left: 5px">
          <label>Last Name</label>
          <input type="text" name="srp-last-name" id="srp-first-name" maxlength="255" size="16" value="<?php echo set_value('srp-last-name',$result['srp_last_name']); ?>"/>
        </div>
        <div style="float:left; width:150px; padding-left: 5px">
          <label>MI</label>
          <input type="text" name="srp-middle-initial" id="srp-middle-initial" maxlength="1" size="4" value="<?php echo set_value('srp-middle-initial',$result['srp_middle_initial']); ?>"/>
        </div>
      </div>
      <div style="clear: both; padding-top: 25px"></div>
      <div style="float: left">
        <div style="float: left; width:50px;">
          <label>Male</label>
        </div>
        <div style="float: left; width:50px; padding-left: 5px">
          <input type="radio" id="srp-male" name="srp-sex" value="M" <?php echo set_radio('srp-sex', 'M',($result['srp_sex']=='M')? true : false); ?>>
        </div>
      </div>
      <div style="clear: both; padding-top: 5px"></div>
      <div style="float: left">
        <div style="float: left; width:50px;">
          <label>Female</label>
        </div>
        <div style="float: left; width:50px; padding-left: 5px">
          <input type="radio" id="srp-female" name="srp-sex" value="F" <?php echo set_radio('srp-sex', 'F',($result['srp_sex']=='F')? true : false); ?>>
        </div>
      </div>
      <div style="clear: both; padding-top: 25px"></div>
      <div style="float: left">
        <?php 
                foreach($patient_status AS $key => $val):?>
        <div style="float: left; width:100px;">
          <label><?php echo $val?></label>
        </div>
        <div style="float: left; width:100px; padding-left: 5px">
          <input type="radio" id="srp_status_<?php echo $key?>" name="srp-status" value="<?php echo $key?>" <?php echo set_radio('srp-status', $key,($result['srp_marital_status']==$key)? true : false); ?>>
        </div>
        <div style="clear: both; padding-top: 5px"></div>
        <?php endforeach;?>
      </div>
      <div style="clear: both; padding-top: 5px"></div>
      <div style="float: left"><font size=2 color="#FF2437"><?php echo form_error('srp-status')?></font></div>
      <div style="clear: both; padding-top: 5px"></div>
      <div style="float:left">
        <div style="float: left; width:150px;">
          <label>If Other (above)</label>
        </div>
        <div style="float: left; width:150px; padding-left: 5px">
          <input type="text" name="srp-martial-status-other" maxlength="25" id="srp-martial-status-other" size="16" value="<?php echo set_value('srp-martial-status-other',$result['srp_marital_status_other']); ?>">
        </div>
      </div>
      <div style="clear: both; padding-top: 25px"></div>
      <div style="float:left;">
        <div style="float: left; width:150px;">
          <label>Social Security #</label>
        </div>
        <div style="float: left; width:150px; padding-left: 5px">
          <input type="text" name="srp-ssn" id="srp-ssn" maxlength="50" size="16" value="<?php echo set_value('srp-ssn',$result['srp_ssn'])?>">
        </div>
      </div>
      <div style="clear: both; padding-top: 5px"></div>
      <div style="float: left"><font size=2 color="#FF2437"><?php echo form_error('srp-ssn')?></font></div>
      <div style="clear: both; padding-top: 25px"></div>
      <div style="float:left;">
        <div style="float: left; width:150px;">
          <label>Birth Date</label>
        </div>
        <div style="float: left; width:150px; padding-left: 5px">
          <input type="text" name="srp-dob" id="srp-dob" size="16" value="<?php echo set_value('srp-dob',$result['srp_dob'])?>">
        </div>
      </div>
      <div style="clear: both; padding-top: 5px"></div>
      <div style="float: left"><font size=2 color="#FF2437"><?php echo form_error('srp-dob')?></font></div>
      <div style="clear: both; padding-top: 25px"></div>
      <div style="float:left">
        <div style="float: left; width:150px;">
          <label>Phone (Home)</label>
        </div>
        <div style="float: left; width:150px; padding-left: 5px">
          <input type="tel" name="srp-phone-home" id="srp-phone-home" maxlength="50" size="32" value="<?php echo set_value('srp-phone-home',$result['srp_phone_home'])?>">
        </div>
      </div>
      <div style="clear: both; padding-top: 5px"></div>
      <div style="float: left"><font size=2 color="#FF2437"><?php echo form_error('srp-phone-home')?></font></div>
      <div style="clear: both; padding-top: 25px"></div>
      <div style="float:left">
        <div style="float: left; width:150px;">
          <label>Phone (Work)</label>
        </div>
        <div style="float: left; width:150px; padding-left: 5px">
          <input type="tel" name="srp-phone-work" id="srp-phone-work" maxlength="50" size="32" value="<?php echo set_value('srp-phone-work',$result['srp_phone_work'])?>">
        </div>
      </div>
      <div style="clear: both; padding-top: 5px"></div>
      <div style="float: left"><font size=2 color="#FF2437"><?php echo form_error('srp-phone-work')?></font></div>
      <div style="clear: both; padding-top: 25px"></div>
      <div style="float:left">
        <div style="float: left; width:150px;">
          <label>Phone (Ext)</label>
        </div>
        <div style="float: left; width:150px; padding-left: 5px">
          <input type="tel" name="srp-phone-ext" id="phone-cell" maxlength="50" size="32" value="<?php echo set_value('srp-phone-ext',$result['srp_phone_ext'])?>">
        </div>
      </div>
      <div style="clear: both; padding-top: 5px"></div>
      <div style="float: left"><font size=2 color="#FF2437"><?php echo form_error('phone-ext')?></font></div>
      <div style="clear: both; padding-top: 25px"></div>
      <div style="float:left">
        <div style="float: left; width:150px;">
          <label>Best time to call</label>
        </div>
        <div style="float: left; width:150px; padding-left: 5px">
          <input type="tel" name="srp-best-time-call" id="srp-best-time-call" maxlength="50" size="32" value="<?php echo set_value('srp-best-time-call',$result['srp_best_time_call'])?>">
        </div>
      </div>
      <div style="clear: both; padding-top: 5px"></div>
      <div style="float: left"><font size=2 color="#FF2437"><?php echo form_error('srp-best-time-call')?></font></div>
      <div style="clear: both; padding-top: 25px"></div>
      <fieldset>
        <legend>Address</legend>
        <div style="clear: both; padding-top: 5px"></div>
        <div style="float:left">
          <div style="float:left; width: 150px">
            <label>Street</label>
          </div>
          <div style="float:left; width: 150px">
            <input type="text" name="srp-street" id="srp-street" maxlength="255" size="32" value="<?php echo set_value('srp-street',$result['srp_address_street'])?>">
          </div>
        </div>
        <div style="clear: both; padding-top: 5px"></div>
        <div style="float: left"><font size=2 color="#FF2437"><?php echo form_error('srp-street')?></font></div>
        <div style="clear: both; padding-top: 5px"></div>
        <div style="float:left">
          <div style="float:left; width: 150px">
            <label>Apartment #</label>
          </div>
          <div style="float:left; width: 150px">
            <input type="text" name="srp-apartment-number" id="srp-apartment-number" maxlength="50" size="16" value="<?php echo set_value('srp-apartment-number',$result['srp_address_apartment_number'])?>">
          </div>
        </div>
        <div style="clear: both; padding-top: 5px"></div>
        <div style="float: left"><font size=2 color="#FF2437"><?php echo form_error('srp-apartment-number')?></font></div>
        <div style="clear: both; padding-top: 5px"></div>
        <div style="float:left">
          <div style="float:left; width: 150px">
            <label>City</label>
          </div>
          <div style="float:left; width: 150px">
            <input type="text" name="srp-city" id="srp-city" maxlength="255" size="16" value="<?php echo set_value('srp-city',$result['srp_address_city'])?>">
          </div>
        </div>
        <div style="clear: both; padding-top: 5px"></div>
        <div style="float: left"><font size=2 color="#FF2437"><?php echo form_error('srp-city')?></font></div>
        <div style="clear: both; padding-top: 5px"></div>
        <div style="float:left">
          <div style="float:left; width: 150px">
            <label>State</label>
          </div>
          <div style="float:left; width: 150px">
            <select name="srp-state" id="srp-state">
              <option id="0" value="" <?php echo set_select('srp-state', '', TRUE); ?>>Please Select</option>
              <?php
                            $states = array();
                            foreach($us_states->result_array() AS $row){
                               $states[$row['id']] = $row['state_abbr'];
                            }
                            //echo form_dropdown('state', $states, '');
                            
                            foreach($states AS $key=>$val):?>
              <option id="<?php echo $key?>" value="<?php echo $key?>" <?php echo set_select('state', $key,($result['srp_address_state_id']==$key)? TRUE : false); ?>><?php echo $val?></option>
              <?php
                            endforeach;
                            ?>
            </select>
          </div>
        </div>
        <div style="clear: both; padding-top: 5px"></div>
        <div style="float: left"><font size=2 color="#FF2437"><?php echo form_error('srp-state')?></font></div>
      </fieldset>
      <div style="clear: both; padding-top: 25px"></div>
    </fieldset>
    <div style="clear: both; padding-top: 25px"></div>
    <?php /*?>Employment Information<?php */?>
    <fieldset class="section">
      <legend>Employment Information</legend>
      <div style="clear: both; padding-top: 5px"></div>
      <div style="float: left">
        <div style="float:left; width:150px;">The following is for:</div>
        <div style="float:left; width:200px; padding-left: 5px;">
          <label>the patient's spouse</label>
          <input type="radio" name="e-following-is-for" id="e-following-is-for" value="S"<?php echo set_radio('e-following-is-for', 'S',($result['e_following_is_for']=='S')? true : false); ?>>
        </div>
        <div style="float:left; width:300px; padding-left: 5px;">
          <label>the person responsible for payment</label>
          <input type="radio" name="e-following-is-for" id="e-following-is-for" value="P"<?php echo set_radio('e-following-is-for', 'P',($result['e_following_is_for']=='P')? true : false); ?>>
        </div>
      </div>
      <div style="clear: both; padding-top: 5px"></div>
      <div style="float: left"><font size=2 color="#FF2437"><?php echo form_error('e-following-is-for')?></font></div>
      <div style="clear: both; padding-top: 25px"></div>
      <div style="float:left">
        <div style="float: left; width:150px;">
          <label>Employer's Name</label>
        </div>
        <div style="float: left; width:150px; padding-left: 5px">
          <input type="text" name="e-name" id="e-name" maxlength="255" size="32" value="<?php echo set_value('e-name',$result['e_name'])?>">
        </div>
      </div>
      <div style="clear: both; padding-top: 5px"></div>
      <div style="float: left"><font size=2 color="#FF2437"><?php echo form_error('e-name')?></font></div>
      <div style="clear: both; padding-top: 25px"></div>
      <div style="float:left">
        <div style="float: left; width:150px;">
          <label>Occupation</label>
        </div>
        <div style="float: left; width:150px; padding-left: 5px">
          <input type="text" name="e-occupation" id="e-occupation" maxlength="255" size="32" value="<?php echo set_value('e-occupation',$result['e_occupation'])?>">
        </div>
      </div>
      <div style="clear: both; padding-top: 5px"></div>
      <div style="float: left"><font size=2 color="#FF2437"><?php echo form_error('e-occupation')?></font></div>
      <div style="clear: both; padding-top: 25px"></div>
      <fieldset>
        <legend>Address</legend>
        <div style="clear: both; padding-top: 5px"></div>
        <div style="float:left">
          <div style="float:left; width: 150px">
            <label>Street</label>
          </div>
          <div style="float:left; width: 150px">
            <input type="text" name="e-street" id="e-street" maxlength="255" size="32" value="<?php echo set_value('e-street',$result['e_address_street'])?>">
          </div>
        </div>
        <div style="clear: both; padding-top: 5px"></div>
        <div style="float: left"><font size=2 color="#FF2437"><?php echo form_error('e-street')?></font></div>
        <div style="clear: both; padding-top: 5px"></div>
        <div style="float:left">
          <div style="float:left; width: 150px">
            <label>City</label>
          </div>
          <div style="float:left; width: 150px">
            <input type="text" name="e-city" id="e-city" maxlength="255" size="16" value="<?php echo set_value('e-city',$result['e_address_city'])?>">
          </div>
        </div>
        <div style="clear: both; padding-top: 5px"></div>
        <div style="float: left"><font size=2 color="#FF2437"><?php echo form_error('e-city')?></font></div>
        <div style="clear: both; padding-top: 5px"></div>
        <div style="float:left">
          <div style="float:left; width: 150px">
            <label>State</label>
          </div>
          <div style="float:left; width: 150px">
            <select name="e-state" id="e-state">
              <option id="0" value="" <?php echo set_select('e-state', '', TRUE); ?>>Please Select</option>
              <?php
                            $states = array();
                            foreach($us_states->result_array() AS $row){
                               $states[$row['id']] = $row['state_abbr'];
                            }
                            //echo form_dropdown('state', $states, '');
                            
                            foreach($states AS $key=>$val):?>
              <option id="<?php echo $key?>" value="<?php echo $key?>" <?php echo set_select('e-state', $key); ?>><?php echo $val?></option>
              <?php
                            endforeach;
                            ?>
            </select>
          </div>
        </div>
        <div style="clear: both; padding-top: 5px"></div>
        <div style="float: left"><font size=2 color="#FF2437"><?php echo form_error('e-state')?></font></div>
      </fieldset>
      <div style="clear: both; padding-top: 25px"></div>
    </fieldset>
    <div style="clear: both; padding-top: 25px"></div>
    <?php /*?>Insurance Information - Primary Insurance<?php */?>
    <fieldset class="section">
      <legend>Insurance Information - Primary Insurance</legend>
      <div style="clear: both; padding-top: 5px"></div>
      <div style="float:left">
        <div style="float:left; width:150px;">Name of Insured:&nbsp;</div>
        <div style="float:left; width:200px; padding-left: 10px;">
          <label>First Name</label>
          <input type="text" id="pi-first-name" name= "pi-first-name" maxlength="255" size="16" value="<?php echo set_value('pi-first-name',$result['pi_first_name']); ?>"/>
        </div>
        <div style="float:left; width:200px; padding-left: 5px;">
          <label>Last Name</label>
          <input type="text" id="pi-last-name" name= "pi-last-name" maxlength="255" size="16" value="<?php echo set_value('pi-last-name',$result['pi_last_name']); ?>"/>
        </div>
        <div style="float:left; width:200px; padding-left: 5px;">
          <label>MI</label>
          <input type="text" id="pi-middle-initial" name= "pi-middle-initial" maxlength="1" size="4" value="<?php echo set_value('pi-middle-initial',$result['pi_middle_initial']); ?>"/>
        </div>
      </div>
      <div style="clear: both; padding-top: 25px"></div>
      <div style="float:left">
        <div style="float:left; width:150px">Is insured a patient?</div>
        <div style="float:left; width:50px; padding-left: 25px">
          <label>Yes</label>
          <input type="radio" name="pi-is-insured-patient" id="pi-is-insured-patient" value="Y" <?php echo set_radio('pi-is-insured-patient', 'Y', ($result['pi_is_insured_patient']=='Y')? true : false); ?>>
        </div>
        <div style="float:left; width:50px; padding-left: 5px">
          <label>No</label>
          <input type="radio" name="pi-is-insured-patient" id="pi-is-insured-patient" value="N" <?php echo set_radio('pi-is-insured-patient', 'N', ($result['pi_is_insured_patient']=='N')? true : false); ?>>
        </div>
      </div>
      <div style="clear: both; padding-top: 5px"></div>
      <div style="float: left"><font size=2 color="#FF2437"><?php echo form_error('pi-is-insured-patient')?></font></div>
      <div style="clear: both; padding-top: 25px"></div>
      <div style="float:left;">
        <div style="float: left; width:150px;">
          <label>Insured's Birth Date</label>
        </div>
        <div style="float: left; width:150px; padding-left: 5px">
          <input type="text" name="pi-dob" id="pi-dob" size="16" value="<?php echo set_value('pi-dob',$result['pi_dob'])?>">
        </div>
      </div>
      <div style="clear: both; padding-top: 5px"></div>
      <div style="float: left"><font size=2 color="#FF2437"><?php echo form_error('pi-dob')?></font></div>
      <div style="clear: both; padding-top: 25px"></div>
      <div style="float:left;">
        <div style="float: left; width:150px;">
          <label>ID&nbsp;#</label>
        </div>
        <div style="float: left; width:150px; padding-left: 5px">
          <input type="text" name="pi-id" id="pi-id" size="16" value="<?php echo set_value('pi-id',$result['pi_id'])?>">
        </div>
      </div>
      <div style="clear: both; padding-top: 5px"></div>
      <div style="float: left"><font size=2 color="#FF2437"><?php echo form_error('pi-id')?></font></div>
      <div style="clear: both; padding-top: 25px"></div>
      <div style="float:left;">
        <div style="float: left; width:150px;">
          <label>Group&nbsp;#</label>
        </div>
        <div style="float: left; width:150px; padding-left: 5px">
          <input type="text" name="pi-group" id="pi-group" size="16" value="<?php echo set_value('pi-group',$result['pi_group'])?>">
        </div>
      </div>
      <div style="clear: both; padding-top: 5px"></div>
      <div style="float: left"><font size=2 color="#FF2437"><?php echo form_error('pi-group')?></font></div>
      <div style="clear: both; padding-top: 25px"></div>
      <fieldset>
        <legend>Insured's Address</legend>
        <div style="clear: both; padding-top: 5px"></div>
        <div style="float:left">
          <div style="float:left; width: 150px">
            <label>Street</label>
          </div>
          <div style="float:left; width: 150px">
            <input type="text" name="pi-street" id="pi-street" maxlength="255" size="32" value="<?php echo set_value('pi-street',$result['pi_address_street'])?>">
          </div>
        </div>
        <div style="clear: both; padding-top: 5px"></div>
        <div style="float: left"><font size=2 color="#FF2437"><?php echo form_error('pi-street')?></font></div>
        <div style="clear: both; padding-top: 5px"></div>
        <div style="float:left">
          <div style="float:left; width: 150px">
            <label>City</label>
          </div>
          <div style="float:left; width: 150px">
            <input type="text" name="pi-city" id="pi-city" maxlength="255" size="16" value="<?php echo set_value('pi-city', $result['pi_address_city'])?>">
          </div>
        </div>
        <div style="clear: both; padding-top: 5px"></div>
        <div style="float: left"><font size=2 color="#FF2437"><?php echo form_error('pi-city')?></font></div>
        <div style="clear: both; padding-top: 5px"></div>
        <div style="float:left">
          <div style="float:left; width: 150px">
            <label>State</label>
          </div>
          <div style="float:left; width: 150px">
            <select name="pi-state" id="e-state">
              <option id="0" value="" <?php echo set_select('pi-state', '', TRUE); ?>>Please Select</option>
              <?php
                            $states = array();
                            foreach($us_states->result_array() AS $row){
                               $states[$row['id']] = $row['state_abbr'];
                            }
                            //echo form_dropdown('state', $states, '');
                            
                            foreach($states AS $key=>$val):?>
              <option id="<?php echo $key?>" value="<?php echo $key?>" <?php echo set_select('pi-state', $key); ?>><?php echo $val?></option>
              <?php
                            endforeach;
                            ?>
            </select>
          </div>
        </div>
        <div style="clear: both; padding-top: 5px"></div>
        <div style="float: left"><font size=2 color="#FF2437"><?php echo form_error('pi-state')?></font></div>
      </fieldset>
      <div style="clear: both; padding-top: 25px"></div>
      <div style="float:left;">
        <div style="float: left; width:200px;">
          <label>Insured's Employer Name</label>
        </div>
        <div style="float: left; width:150px; padding-left: 5px">
          <input type="text" name="pi-emp-name" id="pi-emp-name" maxlength="255" size="32" value="<?php echo set_value('pi-emp-name', $result['pi_emp_name'])?>">
        </div>
      </div>
      <div style="clear: both; padding-top: 5px"></div>
      <div style="float: left"><font size=2 color="#FF2437"><?php echo form_error('pi-emp-name')?></font></div>
      <div style="clear: both; padding-top: 25px"></div>
      <fieldset>
        <legend>Insured's Employer Address</legend>
        <div style="clear: both; padding-top: 5px"></div>
        <div style="float:left">
          <div style="float:left; width: 150px">
            <label>Street</label>
          </div>
          <div style="float:left; width: 150px">
            <input type="text" name="pi-emp-street" id="pi-emp-street" maxlength="255" size="32" value="<?php echo set_value('pi-emp-street', $result['pi_emp_address_street'])?>">
          </div>
        </div>
        <div style="clear: both; padding-top: 5px"></div>
        <div style="float: left"><font size=2 color="#FF2437"><?php echo form_error('pi-emp-street')?></font></div>
        <div style="clear: both; padding-top: 5px"></div>
        <div style="float:left">
          <div style="float:left; width: 150px">
            <label>City</label>
          </div>
          <div style="float:left; width: 150px">
            <input type="text" name="pi-emp-city" id="pi-emp-city" maxlength="255" size="16" value="<?php echo set_value('pi-emp-city', $result['pi_emp_address_city'])?>">
          </div>
        </div>
        <div style="clear: both; padding-top: 5px"></div>
        <div style="float: left"><font size=2 color="#FF2437"><?php echo form_error('pi-emp-city')?></font></div>
        <div style="clear: both; padding-top: 5px"></div>
        <div style="float:left">
          <div style="float:left; width: 150px">
            <label>State</label>
          </div>
          <div style="float:left; width: 150px">
            <select name="pi-emp-state" id="e-state">
              <option id="0" value="" <?php echo set_select('pi-emp-state', '', TRUE); ?>>Please Select</option>
              <?php
                            $states = array();
                            foreach($us_states->result_array() AS $row){
                               $states[$row['id']] = $row['state_abbr'];
                            }
                            //echo form_dropdown('state', $states, '');
                            
                            foreach($states AS $key=>$val):?>
              <option id="<?php echo $key?>" value="<?php echo $key?>" <?php echo set_select('pi-emp-state', $key); ?>><?php echo $val?></option>
              <?php
                            endforeach;
                            ?>
            </select>
          </div>
        </div>
        <div style="clear: both; padding-top: 5px"></div>
        <div style="float: left"><font size=2 color="#FF2437"><?php echo form_error('pi-emp-state')?></font></div>
      </fieldset>
      <div style="clear: both; padding-top: 25px"></div>
      <div style="float:left">
        <div style="float: left; width:200px">Patient's relationship to insured:</div>
        <div style="float: left; width:250px; padding-left: 50px">
          <?php foreach ($patient_relationship_insured AS $key => $val): ?>
          <input type ="radio" name="pi-patient-relation" value="<?php echo $key?>">
          <label><?php echo $val?></label>
          <?php endforeach;?>
        </div>
      </div>
      <div style="float:left; width:200px; padding-left: 50px">
        <input type="text" name="pi-patient-relation-other" id="pi-patient-relation-other" maxlength="25" size="16" value="<?php echo set_value('pi-patient-relation-other', $result['pi_patient_relation_other'])?>">
        <label>If other</label>
      </div>
      <div style="clear: both; padding-top: 25px"></div>
      <div style="float:left;">
        <div style="float: left; width:200px;">
          <label>Ins.Plan Name and Address</label>
        </div>
        <div style="float: left; width:150px; padding-left: 5px">
          <input type="text" name="pi-insurance-plan-address" id="pi-insurance-plan-address" maxlength="255" size="32" value="<?php echo set_value('pi-insurance-plan-address', $result['pi_insurance_plan_address'])?>">
        </div>
      </div>
      <div style="clear: both; padding-top: 25px"></div>
    </fieldset>
    <div style="clear: both; padding-top: 25px"></div>
    <?php /*?>Insurance Information - Secondary Insurance<?php */?>
    <fieldset class="section">
      <legend>Insurance Information - Secondary Insurance</legend>
      <div style="clear: both; padding-top: 5px"></div>
      <div style="float:left">
        <div style="float:left; width:150px;">Name of Insured:&nbsp;</div>
        <div style="float:left; width:200px; padding-left: 10px;">
          <label>First Name</label>
          <input type="text" id="si-first-name" name= "si-first-name" maxlength="255" size="16" value="<?php echo set_value('si-first-name', $result['si_first_name']); ?>"/>
        </div>
        <div style="float:left; width:200px; padding-left: 5px;">
          <label>Last Name</label>
          <input type="text" id="si-last-name" name= "si-last-name" maxlength="255" size="16" value="<?php echo set_value('si-last-name', $result['si_last_name']); ?>"/>
        </div>
        <div style="float:left; width:200px; padding-left: 5px;">
          <label>MI</label>
          <input type="text" id="si-middle-initial" name= "si-middle-initial" maxlength="1" size="4" value="<?php echo set_value('si-middle-initial', $result['si_middle_initial']); ?>"/>
        </div>
      </div>
      <div style="clear: both; padding-top: 25px"></div>
      <div style="float:left">
        <div style="float:left; width:150px">Is insured a patient?</div>
        <div style="float:left; width:50px; padding-left: 25px">
          <label>Yes</label>
          <input type="radio" name="si-is-insured-patient" id="si-is-insured-patient" value="Y" <?php echo set_radio('si-is-insured-patient', 'Y', ($result['si_is_insured_patient']=='Y')? true : false); ?>>
        </div>
        <div style="float:left; width:50px; padding-left: 5px">
          <label>No</label>
          <input type="radio" name="si-is-insured-patient" id="si-is-insured-patient" value="N" <?php echo set_radio('si-is-insured-patient', 'N', ($result['si_is_insured_patient']=='Y')? true : false); ?>>
        </div>
      </div>
      <div style="clear: both; padding-top: 5px"></div>
      <div style="float: left"><font size=2 color="#FF2437"><?php echo form_error('si-is-insured-patient')?></font></div>
      <div style="clear: both; padding-top: 25px"></div>
      <div style="float:left;">
        <div style="float: left; width:150px;">
          <label>Insured's Birth Date</label>
        </div>
        <div style="float: left; width:150px; padding-left: 5px">
          <input type="text" name="si-dob" id="si-dob" size="16" value="<?php echo set_value('si-dob', $result['si_dob'])?>">
        </div>
      </div>
      <div style="clear: both; padding-top: 5px"></div>
      <div style="float: left"><font size=2 color="#FF2437"><?php echo form_error('si-dob')?></font></div>
      <div style="clear: both; padding-top: 25px"></div>
      <div style="float:left;">
        <div style="float: left; width:150px;">
          <label>ID&nbsp;#</label>
        </div>
        <div style="float: left; width:150px; padding-left: 5px">
          <input type="text" name="si-id" id="si-id" size="16" value="<?php echo set_value('si-id', $result['si_id'])?>">
        </div>
      </div>
      <div style="clear: both; padding-top: 5px"></div>
      <div style="float: left"><font size=2 color="#FF2437"><?php echo form_error('si-id')?></font></div>
      <div style="clear: both; padding-top: 25px"></div>
      <div style="float:left;">
        <div style="float: left; width:150px;">
          <label>Group&nbsp;#</label>
        </div>
        <div style="float: left; width:150px; padding-left: 5px">
          <input type="text" name="si-group" id="si-group" size="16" value="<?php echo set_value('si-group', $result['si_group'])?>">
        </div>
      </div>
      <div style="clear: both; padding-top: 5px"></div>
      <div style="float: left"><font size=2 color="#FF2437"><?php echo form_error('si-group')?></font></div>
      <div style="clear: both; padding-top: 25px"></div>
      <fieldset>
        <legend>Insured's Address</legend>
        <div style="clear: both; padding-top: 5px"></div>
        <div style="float:left">
          <div style="float:left; width: 150px">
            <label>Street</label>
          </div>
          <div style="float:left; width: 150px">
            <input type="text" name="si-street" id="si-street" maxlength="255" size="32" value="<?php echo set_value('si-street', $result['si_address_street'])?>">
          </div>
        </div>
        <div style="clear: both; padding-top: 5px"></div>
        <div style="float: left"><font size=2 color="#FF2437"><?php echo form_error('si-street')?></font></div>
        <div style="clear: both; padding-top: 5px"></div>
        <div style="float:left">
          <div style="float:left; width: 150px">
            <label>City</label>
          </div>
          <div style="float:left; width: 150px">
            <input type="text" name="si-city" id="si-city" maxlength="255" size="16" value="<?php echo set_value('si-city', $result['si_address_city'])?>">
          </div>
        </div>
        <div style="clear: both; padding-top: 5px"></div>
        <div style="float: left"><font size=2 color="#FF2437"><?php echo form_error('si-city')?></font></div>
        <div style="clear: both; padding-top: 5px"></div>
        <div style="float:left">
          <div style="float:left; width: 150px">
            <label>State</label>
          </div>
          <div style="float:left; width: 150px">
            <select name="si-state" id="e-state">
              <option id="0" value="" <?php echo set_select('si-state', '', TRUE); ?>>Please Select</option>
              <?php
                            $states = array();
                            foreach($us_states->result_array() AS $row){
                               $states[$row['id']] = $row['state_abbr'];
                            }
                            //echo form_dropdown('state', $states, '');
                            
                            foreach($states AS $key=>$val):?>
              <option id="<?php echo $key?>" value="<?php echo $key?>" <?php echo set_select('si-state', $key); ?>><?php echo $val?></option>
              <?php
                            endforeach;
                            ?>
            </select>
          </div>
        </div>
        <div style="clear: both; padding-top: 5px"></div>
        <div style="float: left"><font size=2 color="#FF2437"><?php echo form_error('si-state')?></font></div>
      </fieldset>
      <div style="clear: both; padding-top: 25px"></div>
      <div style="float:left;">
        <div style="float: left; width:200px;">
          <label>Insured's Employer Name</label>
        </div>
        <div style="float: left; width:150px; padding-left: 5px">
          <input type="text" name="si-emp-name" id="si-emp-name" maxlength="255" size="32" value="<?php echo set_value('si-emp-name', $result['si_emp_name'])?>">
        </div>
      </div>
      <div style="clear: both; padding-top: 5px"></div>
      <div style="float: left"><font size=2 color="#FF2437"><?php echo form_error('si-emp-name')?></font></div>
      <div style="clear: both; padding-top: 25px"></div>
      <fieldset>
        <legend>Insured's Employer Address</legend>
        <div style="clear: both; padding-top: 5px"></div>
        <div style="float:left">
          <div style="float:left; width: 150px">
            <label>Street</label>
          </div>
          <div style="float:left; width: 150px">
            <input type="text" name="si-emp-street" id="si-emp-street" maxlength="255" size="32" value="<?php echo set_value('si-emp-street', $result['si_emp_address_street'])?>">
          </div>
        </div>
        <div style="clear: both; padding-top: 5px"></div>
        <div style="float: left"><font size=2 color="#FF2437"><?php echo form_error('si-emp-street')?></font></div>
        <div style="clear: both; padding-top: 5px"></div>
        <div style="float:left">
          <div style="float:left; width: 150px">
            <label>City</label>
          </div>
          <div style="float:left; width: 150px">
            <input type="text" name="si-emp-city" id="si-emp-city" maxlength="255" size="16" value="<?php echo set_value('si-emp-city', $result['si_emp_address_city'])?>">
          </div>
        </div>
        <div style="clear: both; padding-top: 5px"></div>
        <div style="float: left"><font size=2 color="#FF2437"><?php echo form_error('si-emp-city')?></font></div>
        <div style="clear: both; padding-top: 5px"></div>
        <div style="float:left">
          <div style="float:left; width: 150px">
            <label>State</label>
          </div>
          <div style="float:left; width: 150px">
            <select name="si-emp-state" id="e-state">
              <option id="0" value="" <?php echo set_select('si-emp-state', '', TRUE); ?>>Please Select</option>
              <?php
                            $states = array();
                            foreach($us_states->result_array() AS $row){
                               $states[$row['id']] = $row['state_abbr'];
                            }
                            //echo form_dropdown('state', $states, '');
                            
                            foreach($states AS $key=>$val):?>
              <option id="<?php echo $key?>" value="<?php echo $key?>" <?php echo set_select('si-emp-state', $key); ?>><?php echo $val?></option>
              <?php
                            endforeach;
                            ?>
            </select>
          </div>
        </div>
        <div style="clear: both; padding-top: 5px"></div>
        <div style="float: left"><font size=2 color="#FF2437"><?php echo form_error('si-emp-state')?></font></div>
      </fieldset>
      <div style="clear: both; padding-top: 25px"></div>
      <div style="float:left">
        <div style="float: left; width:200px">Patient's relationship to insured:</div>
        <div style="float: left; width:250px; padding-left: 50px">
          <?php foreach ($patient_relationship_insured AS $key => $val): ?>
          <input type ="radio" name="si-patient-relation" value="<?php echo $key?>">
          <label><?php echo $val?></label>
          <?php endforeach;?>
        </div>
      </div>
      <div style="float:left; width:200px; padding-left: 50px">
        <input type="text" name="si-patient-relation-other" id="si-patient-relation-other" maxlength="25" size="16" value="<?php echo set_value('si-patient-relation-other', $result['si_patient_relation_other'])?>">
        <label>If other</label>
      </div>
      <div style="clear: both; padding-top: 25px"></div>
      <div style="float:left;">
        <div style="float: left; width:200px;">
          <label>Ins.Plan Name and Address</label>
        </div>
        <div style="float: left; width:150px; padding-left: 5px">
          <input type="text" name="si-insurance-plan-address" id="si-insurance-plan-address" maxlength="255" size="32" value="<?php echo set_value('si-insurance-plan-address', $result['si_insurance_plan_address'])?>">
        </div>
      </div>
      <div style="clear: both; padding-top: 25px"></div>
    </fieldset>
    <div style="clear: both; padding-top: 25px"></div>
    <?php /*?>Medical & Dental Health Information<?php */?>
    <fieldset class="section">
      <legend>Medical & Dental Health Information</legend>
      <div style="clear: both; padding-top: 5px"></div>
      <fieldset>
        <legend>Physicians /Health Professionals, Names & Phone Numbers</legend>
        <?php for($i=1; $i<=4; $i++){?>
        <div style="clear: both; padding-top: 5px"></div>
        <div style="float:left">
          <div style="float:left; width:300px">
            <label><?php echo $i?>.&nbsp;Name</label>
            <input type="text" name="physician-health-prof-name-<?php echo $i?>" id="physician-health-prof-name-<?php echo $i?>" maxlength="255" size="32" value="<?php echo @$_POST ? @$_POST['physician-health-prof-name-'.$i] : $result['physician_health_prof_name_'.$i]?>">
          </div>
          <div style="float:left; width:300px; padding-left: 10px">
            <label>Phone</label>
            <input type="tel" name="physician-health-prof-phone-<?php echo $i?>" id="physician-health-prof-phone-<?php echo $i?>" maxlength="255" size="32" value="<?php echo @$_POST ? @$_POST['physician-health-prof-phone-'.$i] : $result['physician_health_prof_phone_'.$i]?>">
          </div>
        </div>
        <?php }?>
      </fieldset>
      <div style="clear: both; padding-top: 25px"></div>
      <?php $health_array = unserialize($result['p_health_condition']); ?>
      <fieldset class="section">
        <legend>Health Condition&nbsp;<a href="#" class="someClass" title="Please select appropriate health conditions.">?&nbsp;</a></legend>
        <div style="clear: both; padding-top: 5px"></div>
        <div style="float:left">
          <?php foreach ($patient_health_conditions->result_array() AS $row):?>
          <div style="float:left; width:10px"> <?php echo $row['health_con_id'].'.'?> </div>
          <div style="float:left; width:400px; padding-left: 50px">
            <label><?php echo $row['description']?></label>
          </div>
          <div style="float:left; width:100px; padding-left: 50px">
            <input type="checkbox" name="patient-health-condition[]" id="patient-health-condition_<?php echo $row['health_con_id']?>" value="<?php echo $row['health_con_id']?>" <?php echo set_radio('patient-health-condition[]', $row['health_con_id'],(in_array($row['health_con_id'], $health_array))? true: false); ?>>
          </div>
          <div style="clear: both; padding-top: 5px"></div>
          <?php endforeach;?>
        </div>
        <div style="clear: both; padding-top: 5px"></div>
        <div style="float: left"><font size=2 color="#FF2437"><?php echo form_error('patient-health-condition[]')?></font></div>
      </fieldset>
      <div style="clear: both; padding-top: 25px"></div>
      <fieldset style="section">
        <legend>Medications & Dosages You Are Currently Taking (please check spelling)</legend>
        <?php for ($i=1; $i<=6; $i++){?>
        <div style="clear: both; padding-top: 5px"></div>
        <div style="float: left">
          <div style="float:left; width:100px">
            <label><?php echo $i?>.&nbsp;</label>
          </div>
          <div style="float:left; width:200px; padding-left: 25px">
            <input type="text" name="med-dosage-<?php echo $i?>" id="med-dosage-<?php echo $i?>" maxlength="255" size="32" value="<?php echo @$_POST ? @$_POST['med-dosage-'.$i] : $result['med_dosage_'.$i]?>">
          </div>
        </div>
        <?php }?>
        <div style="clear: both; padding-top: 5px"></div>
      </fieldset>
      <div style="clear: both; padding-top: 25px"></div>
      <fieldset class="section">
        <legend>Other Medicines or Neutricuticals&nbsp;<a href="#" class="someClass" title="Please select.">?&nbsp;</a></legend>
        <div style="clear: both; padding-top: 5px"></div>
        <div style="float:left">
          <?php $medicines_array = unserialize($result['p_other_medicines']); foreach ($patient_other_medicines_or_neutricuticals->result_array() AS $row):?>
          <div style="float:left; width:10px"> <?php echo $row['other_medicine_id'].'.'?> </div>
          <div style="float:left; width:400px; padding-left: 50px">
            <label><?php echo $row['description']?></label>
          </div>
          <div style="float:left; width:100px; padding-left: 50px">
            <input type="checkbox" name="patient_other_medicines_or_neutricuticals[]" id="patient_other_medicines_or_neutricuticals_<?php echo $row['other_medicine_id']?>" value="<?php echo $row['other_medicine_id']?>" <?php echo set_radio('patient_other_medicines_or_neutricuticals[]', $row['other_medicine_id'], (in_array($row['other_medicine_id'], $medicines_array))? true : false); ?>>
          </div>
          <div style="clear: both; padding-top: 5px"></div>
          <?php endforeach;?>
        </div>
        <div style="clear: both; padding-top: 5px"></div>
        <div style="float: left"><font size=2 color="#FF2437"><?php echo form_error('patient_other_medicines_or_neutricuticals[]')?></font></div>
      </fieldset>
      <div style="clear: both; padding-top: 25px"></div>
    </fieldset>
    <div style="clear: both; padding-top: 25px"></div>
    <div align="middle">
     <button class="button positive" type="submit" id="submit" name="submit">Update</button>
    </div>
    <div style="clear: both; padding-top: 25px"></div>
  </form>
</div>
<?php $this->load->view('patient/patient_footer');?>
