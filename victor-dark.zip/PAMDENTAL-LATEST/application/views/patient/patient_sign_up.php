<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
        <head>
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <meta name="language" content="en" />
        <title><?php echo url_title(@$title);?></title>
        <link rel="stylesheet" type="text/css" href="<?php echo base_url()?>/css/front/screen.css" media="screen, projection" />
        <link rel="stylesheet" type="text/css" href="<?php echo base_url()?>/css/front/print.css" media="print" />
        <!--[if lt IE 8]>
	<link rel="stylesheet" type="text/css" href="<?php echo base_url()?>/css/front/ie.css" media="screen, projection" />
	<![endif]-->

        <link rel="stylesheet" type="text/css" href="<?php echo base_url()?>/css/front/main.css" />
        <link rel="stylesheet" type="text/css" href="<?php echo base_url()?>/css/front/form.css" />
        <link rel="stylesheet" type="text/css" href="<?php echo base_url()?>/css/front/plugins/buttons/screen.css" />

        <script type ="text/javascript">
			var site_base_path='<?php echo base_url();?>';
        </script>
        <script type ="text/javascript">
    $(document).ready(function() { 
        $(function(){
        $(".someClass").tipTip();
        });
    });
</script>
        </head>

        <body>
<div class="container" id="page">
	<?php
		$query=$this->db->get('dentist_login');
		$office = $query->row();
	?>
	<div id="header">
		<div id="logo" class="span-1"><?php echo '<b>'.$office->clinic_name.'</b><br />';?>PAM DENTAL </div>
        <span class="right span-4" style="font-size:13px !important;line-height:1.875em;">
			<?php 

				  echo @$office->first_name.' '.@$office->middle_initial.' '.@$office->last_name.'<br />';
				  echo $office->address_street;
				  echo (@$office->address_apartment_number!='')? ',&nbsp;'.@$office->address_apartment_number.'<br />' : '<br />';
				  echo @$office->address_city;
				  echo ' '.@$office->address_state;
				  echo ' '.@$office->address_zipcode.'<br />';
				  echo '<b>Phone :</b> '.@$office->phone ?>
        </span>
	</div>
        <!-- header -->

<div id="mainmenu">
          <ul>
    <li>&nbsp;</li>
  </ul>
        </div>
<!-- mainmenu -->

<div id="content">


    <form name="patient-sign-up-form" id="patient-sign-up-form" method="post" action="<?php echo base_url()?>patient/patient-sign-up" enctype="multipart/form-data">
    <fieldset>
        
        <legend>Create your personal account</legend>
        
        <div style="clear: both; padding-top: 25px"></div>
        
        <div style="float: left; width: 150px"><label>First Name<font color="#FF2437">*</font></label></div>
        <div style="float: left; width: 250px"><input type="text" id="first-name" name= "first-name" maxlength="255" size="16" value="<?php echo set_value('first-name'); ?>"/></div>
        <div style="float: left; width: 250px"><font size=2 color="#FF2437"><?php echo form_error('first-name')?></font></div>
        <div style="clear: both; padding-top: 5px"></div>
        
        <div style="float: left; width: 150px"><label>Last Name<font color="#FF2437">*</font></label></div>
        <div style="float: left; width: 250px"><input type="text" id="last-name" name= "last-name" maxlength="255" size="16" value="<?php echo set_value('last-name'); ?>"/></div>
        <div style="float: left; width: 250px"><font size=2 color="#FF2437"><?php echo form_error('last-name')?></font></div>
        <div style="clear: both; padding-top: 5px"></div>
        
        <div style="float: left; width: 150px"><label>Middle Initial</label></div>
        <div style="float: left; width: 250px"><input type="text" id="middle-initial" name= "middle-initial" maxlength="1" size="4" value="<?php echo set_value('middle-initial'); ?>"/></div>
        <div style="float: left; width: 250px"><font size=2 color="#FF2437"><?php echo form_error('middle-initial')?></font></div>
        
        <div style="clear: both; padding-top: 25px"></div>
        
        <div style="float: left; width: 150px"><label>Email address<font color="#FF2437">*</font></label></div>
        <div style="float: left; width: 250px"><input type="email" id="email" name= "email" maxlength="255" size="32" value="<?php echo set_value('email'); ?>"/></div>
        <div style="float: left; width: 250px"><font size=2 color="#FF2437"><?php echo form_error('email')?></font></div>
        
        <div style="clear: both; padding-top: 25px"></div>
        
        <div style="float: left; width: 150px"><label>PAM User ID <font color="#FF2437">*</font></label></div>
        <div style="float: left; width: 250px"><input type="text" id="username" name= "username" maxlength="255" size="32" value="<?php echo set_value('username'); ?>"/>&nbsp;<a href="#" class="someClass" title="User ID must be at least 6 characters long.">?</a></div>
        <div style="float: left; width: 250px"><font size=2 color="#FF2437"><?php echo form_error('username')?></font></div>
        
        <div style="clear: both; padding-top: 25px"></div>
        
        <div style="float: left; width: 150px"><label>Password<font color="#FF2437">*</font></label></div>
        <div style="float: left; width: 250px"><input type="password" id="password" name= "password" maxlength="255" size="32" value="<?php echo set_value('password'); ?>"/></div>
        <div style="float: left; width: 250px"><font size=2 color="#FF2437"><?php echo form_error('password')?></font></div>
        
        <div style="clear: both; padding-top: 25px"></div>
        
        <div style="float: left; width: 150px"><label>Confirm Password<font color="#FF2437">*</font></label></div>
        <div style="float: left; width: 250px"><input type="password" id="confirm-password" name= "confirm-password" maxlength="255" size="32" value="<?php echo set_value('confirm-password'); ?>"/></div>
        <div style="float: left; width: 250px"><font size=2 color="#FF2437"><?php echo form_error('confirm-password')?></font></div>
        
        <div style="clear: both; padding-top: 25px"></div>
        
        <div style="float: left; width: 150px"><button class="buttonj positive" type="submit" name="submit" id="submit">Proceed</button></div>
        
        
    </fieldset>
    </form>
    
    <div style="clear: both; padding-top: 10px"></div>
    
    <div align="middle" style="float:left; width:500px"><p>Existing users, click <a href="<?php echo base_url()?>patient">here</a> to Login</p></div>
</div>
<?php $this->load->view('patient/patient_footer');?>
