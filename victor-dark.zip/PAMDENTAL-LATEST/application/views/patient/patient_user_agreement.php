<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <meta name="language" content="en" />
        <title><?php echo url_title(@$title);?></title>
        <link rel="stylesheet" type="text/css" href="<?php echo base_url()?>css/front/screen.css" media="screen, projection" />
        <link rel="stylesheet" type="text/css" href="<?php echo base_url()?>css/front/print.css" media="print" />
        <!--[if lt IE 8]>
	<link rel="stylesheet" type="text/css" href="<?php echo base_url()?>css/front/ie.css" media="screen, projection" />
	<![endif]-->

        <link rel="stylesheet" type="text/css" href="<?php echo base_url()?>css/front/main.css" />
        <link rel="stylesheet" type="text/css" href="<?php echo base_url()?>css/front/form.css" />
        <link rel="stylesheet" type="text/css" href="<?php echo base_url()?>css/front/plugins/buttons/screen.css" />
	    <link rel="shortcut icon" type="image/x-icon" href="<?php echo base_url()?>images/favicon.ico" />
        <?php 
		    echo @$css;
		    echo @$js;
	    ?>
        <script type ="text/javascript">
			var site_base_path='<?php echo base_url();?>';
        </script>
    </head>

<body>
    <div class="container" id="page">
	    <div style="padding: 10px">
        <form name='patient-user-agreement' id='user-agreement' method="post" action="<?php echo base_url()?>patient/user-agreement">
            <table name="user-agreement" id="user-agreement" style="width: 100%">
            <thead>
                <tr>
                    <td>
                        <div align="center">
                            <font style="font-size: 1.2em;  font-weight: bold; color: #FF0000;">
                                <u>Consent for Internet Communications</u>
                            </font>
                        </div>
                    </td>
                </tr>
            </thead>
            <tbody>
                <tr><td>&nbsp;</td></tr>
                <tr>
                    <td>
                    <div style=" font-family: monospace;">
                    I grant my permission to the dental practice to upload and store confidential patient information
                    (including account information, appointment information and clinical information) to the secured web
                    site for the dental practice. I understand that, for security purposes, the site requires a user ID and
                    password for access and use. I also understand the dental practice and I are responsible for maintaining
                    the strict confidentiality of any ID and password assigned to me; and that the dental practice is not
                    liable for any charges, damages, or losses that may be incurred or suffered as a result of my failure to
                    maintain confidentiality. I understand the dental practice is not liable for any harm related to the theft
                    of my ID and password, my disclosure of my ID and password, or my authorization to allow another
                    person or entity to access and use the dental practice website with my ID and password. I also agree
                    to immediately notify the dental practice of any unauthorized use of my ID or of any other need to
                    deactivate my ID due to security concerns.
                    <br/><br/> 
                    I also understand that State and Federal laws, as well as ethical and licensure requirements impose
                    obligations with respect to patient confidentiality that limit the ability to make use of certain services
                    or to transmit certain information to third parties. I understand the dental practice will represent
                    and warrant that they will, at all times during the terms of the Agreement and thereafter, comply
                    with all laws directly or indirectly applicable that may now or hereafter govern the gathering, use,
                    transmission, processing, receipt, reporting, disclosure, maintaining, and storage of my information,
                    and use their best efforts to cause all persons or entities under their direction or control to comply with
                    such laws. I agree that the dental practice has the right to monitor, retrieve, store, upload and use my
                    information in connection with the operation of such service, and is acting on my behalf in uploading
                    my patient information. I understand the dental practice will use commercially reasonable efforts to
                    maintain the confidentiality of all patient information that is uploaded to the website on my behalf.
                    I understand the dental practice CANNOT AND DOES NOT ASSUME ANY RESPONSIBILITY
                    OF MY USE OR MISUSE OF PATIENT INFORMATION OR OTHER INFORMATION
                    TRANSMITTED, MONITORED, STORED, UPLOADED OR RECEIVED USING THE SITE OR
                    THE SERVICES.
                    </div>
                    </td>
                </tr>
                <tr><td>&nbsp;</td></tr>
                <tr>
                    <td>
                        <div align="center">
                        <button class="button positive" type="submit" name="user_agreement_agree">I Agree</button>
                        </div>
                    </td>
                </tr>
            </tbody>
            </table>
        </form>
        </div>
    </div>
</body>
</html>