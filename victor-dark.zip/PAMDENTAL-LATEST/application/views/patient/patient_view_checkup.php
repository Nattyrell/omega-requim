<?php $this->load->view('patient/patient_header');?>

<div id="content">
    <?php
    /** TEST VARIABLES HERE - */
    //echo '<pre>';
    //print_r($patient_data);
    //print_r($get_checkup);
    //echo $patient_checkup_id = base64_decode($this->uri->segment(3));
    //echo br(1);
    //echo $patient_id = base64_decode($this->uri->segment(4));
    //echo '</pre>';
    /** ---------------------- */
    ?>
    <fieldset>
    <legend>Treatment Plan</legend>
    <table name="treatment-plan" id="treatment-plan" width="100%" cellspacing="5" cellpadding="10">
        <tr>
            <td width="50%" align="left">
                <?php /** MAKE DYNAMIC */?>
                <b>Express Denture Care</b><br/>
                18009 Hwy 99, Suite C<br/>
                Lynwood WA 98037<br/>
                <b>Phone:</b>&nbsp;425-672-8494
            </td>
            <td width="50%" align="right">
                <table>
                    <tr>
                        <th>PATIENT NAME:&nbsp;</th>
                        <td><?php echo $patient_data['name']?></td>
                    </tr>
                </table>
            </td>
        </tr>
        <tr>
            <td colspan="2">&nbsp;</td>
        </tr>
        <tr>
            <td align="left">
                <table>
                    <tr>
                        <th>
                            GUARANTOR NAME AND MAILING ADDRESS
                        </th>
                    </tr>
                    <tr>
                        <td><?php echo $guarantor_data['name']?></td>
                    </tr>
                    <tr>
                        <td>
                        <?php
                            $states = array();
                            foreach($us_states->result_array() AS $row){
                                $states[$row['id']] = $row['state'];
                            }
                            $contact_address = $guarantor_data['p_address_apartment_number'].nbs(1).$guarantor_data['p_address_street'].', '.$guarantor_data['p_address_city'].nbs(1).$states[$guarantor_data['p_address_state_id']].nbs(1).$guarantor_data['p_address_zipcode'];
                            echo $contact_address;
                        ?>
                        </td>
                    </tr>
                </table>
            </td>
            <td align="right" style="vertical-align:top">
                <b><?php echo $get_checkup_detail['date'];?>
            </td>
        </tr>
    </table>
    </fieldset>
    <div style="clear: both; padding-top: 25px"></div>
    <fieldset>
    <legend><?php echo 'TREATMENT:'.'&nbsp;'.$get_checkup_detail['treatment_uin']?></legend>
        <table name="view-checkup" id="view-checkup" width="100%" cellspacing="5">
                <tr>
                    <th align="middle">Sr. No.</th>
                    <th align="middle">Tooth Description</th>
                    <th align="middle">ADA Code</th>
                    <th align="middle">Service</th>
                    <th align="middle">Service Fee</th>
                    <!--<th align="middle">INS. Fee</th>-->
                    <th align="middle">Est. Insurance Coverage</th>
                    <th align="middle">INS. Covered %</th>
                    <th align="middle">Annual Deductible </th>
                    <th align="middle">Patient Fee</th>
    <!--                <th width="5%" align="middle">Pros.</th>
                    <th width="5%" align="middle">Cons.</th>-->
                </tr>
            </tbody>
            <?php
            $i=1;
            foreach ($get_checkup AS $row):?>
            <tr>
                <td align="middle"><?php echo $i?></td>
                <td align="middle"><?php echo $row['tooth_desc']?></td>
                <td align="middle"><?php echo $row['ada_code']?></td>
                <td align="middle"><?php echo $row['recommended_treatment_desc']?></td>
                <!--<td align="middle"><?php /*echo '$'.$row['price']*/?></td>
                <td align="middle"><?php /*echo '$'.$row['insurance']*/?></td>-->
                <td align="middle"><?php echo '$'.$row['t_price']?></td>
                <td align="middle"><?php echo '$'.$row['e_insurance_coverage']?></td>
                <td align="middle"><?php echo $row['ins_covered_per']?></td>
                <td align="middle"><?php echo '$'.$row['annual_deductible']?></td>
                <td align="middle"><?php echo '$'.$row['patient_fee']?></td>
    <!--            <td align="middle">
                    <a style=" cursor: pointer" href="#" class="big-link" data-reveal-id="myModal_pros_<?php echo $i;?>" data-animation="fade">View</a>
                    <div id="myModal_pros_<?php echo $i;?>" class="reveal-modal">
                            <h1><font color="#FF2437"><?php echo $row['recommended_treatment_desc']?></font></h1>
                            <h2><u>Pros.</u></h2>
                            <?php echo $row['pros']?>
                            <a class="close-reveal-modal">&#215;</a>
                    </div>
                </td>
                <td align="middle">
                    <a style=" cursor: pointer" href="#" class="big-link" data-reveal-id="myModal_cons_<?php echo $i;?>" data-animation="fade">View</a>
                    <div id="myModal_cons_<?php echo $i;?>" class="reveal-modal">
                            <h1><font color="#FF2437"><?php echo $row['recommended_treatment_desc']?></font></h1>
                            <h2><u>Cons.</u></h2>
                            <?php echo $row['cons']?>
                            <a class="close-reveal-modal">&#215;</a>
                    </div>
                </td>-->
            </tr>   
            <?php
            $i++;
            endforeach;
            ?>
            <tr>
                <td align="middle" colspan="9">&nbsp;</td>
            </tr>
            
            <tbody bgcolor="#FFFFEF">
                <tr>
                    <td align="middle" colspan="8"><font color="#FF2437"><h2>Patient Grand Total</h2></font></td>
                    <td align="middle" ><font color="#FF2437"><h2><?php echo '$'.@$get_checkup_price['patient_grand_total']?></h2></font></td>
                </tr>
            </tbody>
        </table>

        <div style="clear: both; padding-top: 25px"></div>

        <table name="dentist-notes-desc" id="dentist-notes-desc" width="100%" border="0" cellspacing="0" cellpadding="3" style="margin-bottom:50px;">
        <tbody bgcolor="#FFFFEF">
          <tr>
            <th align="middle" valign="middle" width="20%"> Notes </th>
            <td width="10%">&nbsp;</td>
            <td align="left" valign="middle" width="70%"><?php echo $get_checkup_detail['notes'];?></td>
          </tr>
        </tbody>
        <tr>
          <td colspan="2">&nbsp;</td>
        </tr>
        <tbody bgcolor="#FFFFEF">
          <tr>
            <th align="middle" valign="middle" width="20%">Treatment Pros.</th>
            <td width="10%">&nbsp;</td>
            <td align="left" valign="middle" width="70%">
                <?php 
                    //echo $get_checkup_detail['patient_description'];
                    echo $get_checkup_detail['treatment_pros'];
                ?>
            </td>
          </tr>
        </tbody>
        <tr>
          <td colspan="2">&nbsp;</td>
        </tr>
        <tbody bgcolor="#FFFFEF">
          <tr>
            <th align="middle" valign="middle" width="20%">Treatment Cons.</th>
            <td width="10%">&nbsp;</td>
            <td align="left" valign="middle" width="70%">
                <?php 
                    echo $get_checkup_detail['treatment_cons'];
                ?>
            </td>
          </tr>
        </tbody>
        <tr>
          <td colspan="2">&nbsp;</td>
        </tr>
        <tbody bgcolor="#FFFFEF">
          <tr>
            <th align="middle" valign="middle" width="20%">Est. Treatment Time (HH:MM)</th>
            <td width="10%">&nbsp;</td>
            <td align="left" valign="middle" width="70%">
                <?php 
                    echo $get_checkup_detail['treatment_time'];
                ?>
            </td>
          </tr>
        </tbody>
        <tr>
          <td colspan="2">&nbsp;</td>
        </tr>
        <tbody bgcolor="#FFFFEF">
          <tr>
            <th align="middle" valign="middle" width="20%">Recommended by Dentist on</th>
            <td width="10%">&nbsp;</td>
            <td align="left" valign="middle" width="70%"><?php echo $get_checkup_detail['date'].', '.nbs(1).$get_checkup_detail['time'];?></td>
          </tr>
        </tbody>
        <tr>
          <td colspan="2">&nbsp;</td>
        </tr>
        <tbody bgcolor="#FFFFEF">
          <tr>
            <th align="middle" valign="middle" width="20%">Status</th>
            <td width="10%">&nbsp;</td>
            <td align="left" valign="middle" width="70%"><?php echo $get_checkup_detail['status'];?></td>
          </tr>
        </tbody>
        <tr>
          <td colspan="2">&nbsp;</td>
        </tr>
        <tr>
          <td colspan="2">&nbsp;</td>
        </tr>
        <tbody style="border: 1px solid #CCCCCC;">
          <tr>
            <td width="40%">
                <?php
                /** CHECK IF PATIENT HAS NOT PAID FOR THE TREATMENT PLAN */
                if($get_checkup_detail['status']!= 'Pending' && $get_checkup_detail['paid_for'] == 'N'):?>
                    <a style="text-decoration: none" href="<?php echo base_url()?>patient/pay-for-treatment/<?php echo $this->uri->segment(3).'/'.$this->uri->segment(4)?>"><button class="button positive">Pay Bill</button></a>
                <?php endif?>
            </td>
            <td width="20%">&nbsp;</td>
            <td width="40%">
                <?php
                /** CHECK IF PATIENT HAS PAID FOR THE TREATMENT PLAN AND NOT YET AVAILED APPOINTMENT*/
                if($get_checkup_detail['status']!= 'Pending' && $get_checkup_detail['paid_for'] == 'Y' && $get_checkup_detail['appointment_taken'] == 'N'):?>
                    <a style="text-decoration: none" href="<?php echo base_url()?>patient/appointment/<?php echo $this->uri->segment(3)?>"><button class="button positive">Schedule Appointment</button></a>
                <?php endif?>
            </td>
          </tr>
        </tbody>
        </table>
    </fieldset>
    <div style="clear: both; padding-top: 25px"></div>
</div>
<?php $this->load->view('patient/patient_footer');?>
