<?php 
if (!$link = mysql_connect('localhost', 'root', '')) {
    echo 'Could not connect to mysql';
    exit;
}

if (!mysql_select_db('pam_dental', $link)) {
    echo 'Could not select database';
    exit;
}
if(isset($_REQUEST['action']))
{ 
	switch($_REQUEST['action'])
	{ 
    	case 'save':
		{ 
			$sql='INSERT INTO `schedule` (`schedule_status`, `visit_date`, `start_time`, `end_time`, `patient_id`, `visit_type`, `visit_note`, `added_date`) 
				  VALUES ("PENDING", "'.$_POST['visit_date'].'", "'.$_POST['start_time'].'", "'.$_POST['end_time'].'", "'.$_POST['patient_id'].'", "'.$_POST['visit_type'].'", "'.$_POST['visit_note'].'", NOW());';
			mysql_query($sql);	  
			echo mysql_insert_id();
      		exit; 
  		} 
		
		case 'update':  
		{ 
			$sql='UPDATE `schedule` SET `start_time` =  "'.$_POST['start_time'].'", `end_time` = "'.$_POST['end_time'].'",
										`visit_type` = "'.$_POST['visit_type'].'", `visit_note` = "'.$_POST['visit_note'].'"
										 WHERE schedule_id = "'.$_POST['schedule_id'].'"';
			mysql_query($sql);	  
			echo 'Appointment Updated Successfully';
			exit; 
 		} 
		
  		case 'delete':
		{ 
			 $sql = 'DELETE 
			 		 FROM schedule WHERE schedule_id = "'.$_POST['schedule_id'].'"';
			  $result = mysql_query($sql);		
			  echo 'Appointment Deleted Successfully'; 
			 exit; 
 		} 
 		case 'get_event':  
		{ 
 			 exit; 
 		} 
 	} 
} 
?>