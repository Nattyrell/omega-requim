<?php
if (!$link = mysql_connect('localhost', 'root', '')) {
    echo 'Could not connect to mysql';
    exit;
}

if (!mysql_select_db('pam_dental', $link)) {
    echo 'Could not select database';
    exit;
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
  <meta http-equiv="content-type" content="text/html; charset=UTF-8" />
  <title>Demo 3 - jQuery Week Calendar</title>

  <link rel='stylesheet' type='text/css' href='libs/css/smoothness/jquery-ui-1.8.11.custom.css' />
  <link rel="stylesheet" type="text/css" href="libs/jquery.weekcalendar.css" />
  <link rel="stylesheet" type="text/css" href="skins/default.css" />
  <link rel="stylesheet" type="text/css" href="skins/gcalendar.css" />
<style>
body {
	font-family: Tahoma, Geneva, Helvetica, sans-serif;
	font-size: 83.33%;
}

h1 {
	padding: 0.5em;
	font-size: 1.6em;
} 

h2 {
	margin: 0.5em 0;
	font-size: 1.4em;	
}

p {
	margin: 0.5em;	
}

.ui-widget {
	font-size: 1em;	
}

#calendar_new_entry_form, #about {
	display: none;
	z-index: 10;
}

#about_button_container {
	position: absolute;
	top: 0em;
	right: 0em;	
	padding: 0.5em 2em;
	background: #ddf;
	border: 1px solid #bbd;
	width: 25em;
	text-align: center;
}

.wc-header td {
/*	background: url(images/header-bg.png) repeat-x;*/
}

#calendar_new_entry_form label {
	display: block;
	margin-top: 1em;
	margin-bottom: 0.5em;
	z-index: 10;
}

form ul {
	padding: 0.3em;
}

select, input[type='text'], textarea {
	width: 250px;
	padding: 3px;
}

input[type='text'] {
	width: 245px;
}

UL
{
	list-style: none;
	padding: 0;
}

ul.formatted,ol.formatted {
	display: block;
	margin: 1em 0.5em;
}

ul.formatted li,ol.formatted li {
	margin: 5px 30px;
	display: auto;
}

ul.formatted li {
	list-style:none;
	list-style-type: disc;
}

ol.formatted li {
	list-style:none;
	list-style-type: decimal;
}
#switcher{float:left;}

</style>


  <script type='text/javascript' src='libs/jquery-1.4.4.min.js'></script>
  <script type='text/javascript' src='libs/jquery-ui-1.8.11.custom.min.js'></script>
  <script type='text/javascript' src='libs/jquery-ui-i18n.js'></script>

  <script type="text/javascript" src="libs/date.js"></script>
  <script type="text/javascript" src="libs/jquery.weekcalendar.js"></script>
  <script type="application/javascript">
	var commonAjaxHandler = './event.php';
	$(document).ready(function() { 
  		$('#calendar_wrapper').weekCalendar({
			timeslotsPerHour : 4,    
			switchDisplay: {'Daily Calendar': 1, 'Weekly Calendar': 7},
			businessHours :{start: 0, end: 24, limitDisplay: true },
			allowCalEventOverlap : false,
     		overlapEventsSeparate: true,
			draggable : function(calEvent, $event) {
        		return false;
    		},
    		resizable : function(calEvent, $event) {
        		return false;
    		},
			//'data':'./calendar.php?action=get_events',  
			data : function(start, end, callback) {
         		callback(getEventData());
    		},
			 eventRender : function(calEvent, $event) {
				 if ((calEvent.patient_id !=1)) {
					$event.css("backgroundColor", "red");
					$event.find(".wc-time").css({
					   "backgroundColor" : "red",
					   "border" : "1px solid #888"
					});
				 }
			  },
	   		'height':function($calendar){ 
      			 return $(window).height() - $("h1").outerHeight() - 1;
    		},
			// Function for adding new appointment
    		'eventNew':function(calEvent, $event) { 
        		 var $dialogContent = $("#calendar_new_entry_form");
        		// resetForm($dialogContent);
         		var startField = $dialogContent.find("select[name='start']").val(calEvent.start);
         		var endField = $dialogContent.find("select[name='end']").val(calEvent.end);
         		var titleField = $dialogContent.find("input[name='title']");
         		var bodyField = $dialogContent.find("textarea[name='body']");
		 		var $this=$(this); 
         		$dialogContent.dialog({
            		title: "Add Appointment",
            		close: function() {
              	 		$dialogContent.dialog("destroy");
               			$dialogContent.hide();
               			$('#calendar_wrapper').weekCalendar("removeUnsavedEvents");
            		},
            		buttons: {
               			save : function() {
                  			calEvent.start = new Date(startField.val());
                  			var st = new Date(startField.val());
                  			var sm = parseInt(st.getMonth()) + 1;
                  			var visit_date = st.getFullYear() + '-' + sm + '-' + st.getDate() + '';

						    var start_time = st.getHours() + ':' + st.getMinutes() + ':' + st.getSeconds();
						    calEvent.end = new Date(endField.val());
						    var et = new Date(endField.val());
						    var end_time = et.getHours() + ':' + et.getMinutes() + ':' + et.getSeconds();
						    //alert(end_time);
						   calEvent.title = $("#patientName").val();
						   calEvent.body = $("#visitNote").val();
						   calEvent.patient_id = $("#patientId").val();
						   calEvent.visit_type = $("#visitType").val();
						   calEvent.visit_note = $("#visitNote").val();
                 
				  			$.post(commonAjaxHandler,{action:'save', visit_date:visit_date, start_time:start_time, end_time:end_time, patient_id:calEvent.patient_id, visit_type:calEvent.visit_type,visit_note:calEvent.visit_note,},function(data){ 
								$this.dialog('close'); 
								//	alert(data);
								id = parseInt(data);
								
							})
							alert("Schedule Added Successfully");
							calEvent.id = id;	
					  //$("#calendar_wrapper").weekCalendar("refresh");

							$('#calendar_wrapper').weekCalendar("removeUnsavedEvents");
							$('#calendar_wrapper').weekCalendar("updateEvent", calEvent);
							$dialogContent.dialog("close");
               			},//end of save button
               			
						cancel : function() {
                  			$dialogContent.dialog("close");
		               }
            		}//End of button line 135-169
         		}).show();
		        $dialogContent.find(".date_holder").text($('#calendar_wrapper').weekCalendar("formatDate", calEvent.start));
        		setupStartAndEndTimeFields(startField, endField, calEvent, $('#calendar_wrapper').weekCalendar("getTimeslotTimes", calEvent.start));
    		},
			
			noEvents : function() {

      		},
			
			'eventClick':function(calEvent, $event) { 
      			//calendar_edit_entry(calEvent,$event); 
				//alert(JSON.stringify(calEvent));
				if (calEvent.readOnly || (calEvent.patient_id !=1)) {
					alert('This time is busy');
           			 return;
        		}
				 var $dialogContent = $("#calendar_new_entry_form");
        		resetForm($dialogContent);
         		var startField = $dialogContent.find("select[name='start']").val(calEvent.start);
         		var endField = $dialogContent.find("select[name='end']").val(calEvent.end);
         		var titleField = $dialogContent.find("input[name='title']");
         		var bodyField = $dialogContent.find("textarea[name='body']");
		 		var $this=$(this); 
				$dialogContent.dialog({
				  title: "Edit - " + calEvent.title,
				  close: function() {
				   $dialogContent.dialog("destroy");
				  // removeVisitNote();
				   $dialogContent.hide();
				   $('#calendar_wrapper').weekCalendar("removeUnsavedEvents");
				},
           		buttons: {
					save : function() {
		                  calEvent.start = new Date(startField.val());
                		  calEvent.end = new Date(endField.val());
		                  var st = new Date(startField.val());
        		          var sm = parseInt(st.getMonth()) + 1;
                		  var visit_date = st.getFullYear() + '-' + sm + '-' + st.getDate() + '';
                  
						  var start_time = st.getHours() + ':' + st.getMinutes() + ':' + st.getSeconds();
						  calEvent.end = new Date(endField.val());
						  var et = new Date(endField.val());
						  var end_time = et.getHours() + ':' + et.getMinutes() + ':' + et.getSeconds();
                  
						  calEvent.title = $("#patientName").val();
						  calEvent.body = $("#visitNote").val();
						  calEvent.patient_id = $("#patientId").val();
						  calEvent.visit_type = $("#visitType").val();
						  calEvent.visit_note = $("#visitNote").val();
						  var schedule_id = calEvent.id;
		                $.post(commonAjaxHandler,{action:'update', schedule_id:schedule_id, visit_date:visit_date, start_time:start_time, end_time:end_time, patient_id:calEvent.patient_id, visit_type:calEvent.visit_type,visit_note:calEvent.visit_note,},function(data){ 
								$this.dialog('close'); 
									alert(data);
								//id = parseInt(data);
							})
						
						  $('#calendar_wrapper').weekCalendar("updateEvent", calEvent);
						  $dialogContent.dialog("close");
					//	  removeVisitNote();*/
               		},// end of save
				    "delete" : function() {
	    	              $('#calendar_wrapper').weekCalendar("removeEvent", calEvent.id);
    	                  $dialogContent.dialog("close");
               		},
					"cancel" : function() {
						  $dialogContent.dialog("close");
						  //removeVisitNote();
					   }
					}
				 }).show();
				//	alert(calEvent.visit_note);
				 // set values from database
				 document.getElementById('patientName').value = calEvent.title;
				 document.getElementById('patientId').value = calEvent.patient_id;
				 document.getElementById('visitType').value = calEvent.visit_type;
				 document.getElementById('visitNote').value = calEvent.visit_note;
				 //alert(document.getElementById('visitNote').value);
				 var startField = $dialogContent.find("select[name='start']").val(calEvent.start);
				 var endField = $dialogContent.find("select[name='end']").val(calEvent.end);
				 $dialogContent.find(".date_holder").text($('#calendar_wrapper').weekCalendar("formatDate", calEvent.start));
				 setupStartAndEndTimeFields(startField, endField, calEvent, $('#calendar_wrapper').weekCalendar("getTimeslotTimes", calEvent.start));
				 $(window).resize().resize(); //fixes a bug in modal overlay size ??
         

    		}
  });
  
	//function for getting event data
	function getEventData() {
      var year = new Date().getFullYear();
      var month = new Date().getMonth();
      var day = new Date().getDate();
      return {
      	events : [
		<?php
			  $sql = 'SELECT s.*, concat(p.first_name, " ", p.last_name) as patient_name 
					  FROM schedule s 
					  left join patient_login p 
					  ON s.patient_id=p.patient_login_id';
			  $result = mysql_query($sql) or die(mysql_error());	
			  $ret = array();

			  while($row = mysql_fetch_assoc($result))
			  {
				  $ret[] = $row;
			  }	 
			  
			  foreach($ret as $key=>$app)
			  {
				$visit_date = strtotime($app['visit_date']);
				$year = date('Y', $visit_date);
				$month = date('n', $visit_date);
				$day = date('j', $visit_date);
				$ret[$key]['year'] = (int)($year);
				$ret[$key]['month'] = (int)($month);
				$ret[$key]['day'] = (int)($day);
			  }
			  $dat['appointments'] = $ret;	
      	
			  foreach($dat['appointments'] as $app):
			  		$visit_date = strtotime($app['visit_date']);
					$st = strtotime($app['start_time']);
					$et = strtotime($app['end_time']);
					
					$year = date('Y', $visit_date);
					$month = date('n', $visit_date);
					$day = date('j', $visit_date);
					$sh = date('G', $st);
					$eh = date('G', $et);
					$sm = date('i', $st);
					$em = date('i', $et);
	  	
				?>
            	{
				<?php if($app['patient_id'] == 1)
						{
					 ?>	
				  "id":parseInt(<?php echo $app['schedule_id']?>),
				  "start": new Date(<?php echo $year?>, <?php echo $month-1?>, <?php echo $day?>, <?php echo $sh?>, <?php echo $sm?>),
				  "end": new Date(<?php echo $year?>, <?php echo $month-1?>, <?php echo $day?>, <?php echo $eh?>, <?php echo $em?>),
				  "title":"<?php echo $app['patient_name'];?><a href='http://www.yahoo.com'>Review</a>",
				  "patient_id" : "<?php echo $app['patient_id'];?>",
	              "visit_type" : "<?php echo $app['visit_type'];?>",
               	  "visit_note" : "<?php echo $app['visit_note'];?>"
				 <?php 
				}
				else
				{
				?> 
				   "id":parseInt(<?php echo $app['schedule_id']?>),
					 "start": new Date(<?php echo $year?>, <?php echo $month-1?>, <?php echo $day?>, <?php echo $sh?>, <?php echo $sm?>),
					 "end": new Date(<?php echo $year?>, <?php echo $month-1?>, <?php echo $day?>, <?php echo $eh?>, <?php echo $em?>),
					 "title":"BUSY"
				  <?php } ?>
	            },
						
				<?php	
				
				endforeach;
?>
      	]
         
      };
   }
 
 function resetForm($dialogContent) {
      $dialogContent.find("input").val("");
      $dialogContent.find("textarea").val("");
      removeVisitNote();
   }
   
   function removeVisitNote()
{
  document.getElementById('visitNote').value='';
}
     /*
    * Sets up the start and end time fields in the calendar event
    * form for editing based on the calendar event being edited
    */
   function setupStartAndEndTimeFields($startTimeField, $endTimeField, calEvent, timeslotTimes) {

      $startTimeField.empty();
      $endTimeField.empty();

      for (var i = 0; i < timeslotTimes.length; i++) {
         var startTime = timeslotTimes[i].start;
         var endTime = timeslotTimes[i].end;
         var startSelected = "";
         if (startTime.getTime() === calEvent.start.getTime()) {
            startSelected = "selected=\"selected\"";
         }
         var endSelected = "";
         if (endTime.getTime() === calEvent.end.getTime()) {
            endSelected = "selected=\"selected\"";
         }
         $startTimeField.append("<option value=\"" + startTime + "\" " + startSelected + ">" + timeslotTimes[i].startFormatted + "</option>");
         $endTimeField.append("<option value=\"" + endTime + "\" " + endSelected + ">" + timeslotTimes[i].endFormatted + "</option>");

         $timestampsOfOptions.start[timeslotTimes[i].startFormatted] = startTime.getTime();
         $timestampsOfOptions.end[timeslotTimes[i].endFormatted] = endTime.getTime();

      }
      $endTimeOptions = $endTimeField.find("option");
      $startTimeField.trigger("change");
   }

   var $endTimeField = $("select[name='end']");
   var $endTimeOptions = $endTimeField.find("option");
   var $timestampsOfOptions = {start:[],end:[]};

   //reduces the end time options to be only after the start time options.
   $("select[name='start']").change(function() {
      var startTime = $timestampsOfOptions.start[$(this).find(":selected").text()];
      var currentEndTime = $endTimeField.find("option:selected").val();
      $endTimeField.html(
            $endTimeOptions.filter(function() {
               return startTime < $timestampsOfOptions.end[$(this).text()];
            })
            );

      var endTimeSelected = false;
      $endTimeField.find("option").each(function() {
         if ($(this).val() === currentEndTime) {
            $(this).attr("selected", "selected");
            endTimeSelected = true;
            return false;
         }
      });

      if (!endTimeSelected) {
         //automatically select an end date 2 slots away.
         $endTimeField.find("option:eq(1)").attr("selected", "selected");
      }

   });
});
</script>
</head>
<body> 
  <div id="calendar_wrapper" style="height:750px"></div> 
  <div id="calendar_new_entry_form">
  <form>
    <input type="hidden">
    <input type="hidden" name="patient_id" id="patientId" value="2"/>
    <ul>
      <li> <span>
        <label for="title">Patient: Patient Name<input type="hidden" name="patientName" id="patientName" value="Patient Name"/></label>
        </span> </li>
      <li> <span>
        <label for="visit_type">Visit Type: </label>
        </span> <span class="visit_type">
        <select name="visit_type" id="visitType">
          <option value="Consultation">Consultation</option>
          <option value="Check-up">Check-up</option>
          <option value="Cleaning">Cleaning</option>
          <option value="Whitening">Whitening</option>
          <option value="Filling / one tooth">Filling / one tooth</option>
        </select>
        </span> </li>
      <li>
        <label><span>Visit Date: </span><span class="date_holder"></span> </label>
      </li>
      <li>
        <label for="start">Start: </label>
        <select name="start">
          <option value="">Select Start Time</option>
        </select>
      </li>
      <li>
        <label for="end">End: </label>
        <select name="end">
          <option value="">Select End Time</option>
        </select>
      </li>
      <li>
        <label for="body">Visit Note: </label>
        <span id="visitnotetext">
        <textarea name="visit_note" id="visitNote"></textarea>
        </span> </li>
    </ul>
  </form>
</div>
 </body>
</html>