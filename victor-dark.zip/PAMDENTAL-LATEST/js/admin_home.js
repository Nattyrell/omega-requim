// JavaScript Document

function change_colour_patient()
{
	document.getElementById('patient').style.color = "#F58220";
}

function restore_colour_patient()
{
	document.getElementById('patient').style.color = "#555";
}

function change_colour_schedule()
{
	document.getElementById('appointment').style.color = "#009900";
}

function restore_colour_schedule()
{
	document.getElementById('appointment').style.color = "#555";
}

function change_colour_billing()
{
	document.getElementById('billing').style.color = "#FF0000";
}

function restore_colour_billing()
{
	document.getElementById('billing').style.color = "#555";
}

function change_colour_ada_code()
{
	document.getElementById('ada_code').style.color = "#662F58";
}

function restore_colour_ada_code()
{
	document.getElementById('ada_code').style.color = "#555";
}

function change_colour_teeth_list()
{
	document.getElementById('teeth_list').style.color = "#F58220";
}
function restore_colour_teeth_list()
{
	document.getElementById('teeth_list').style.color = "#555";
}
function change_colour_dentist()
{
	document.getElementById('dentist').style.color = "#F58220";
}
function restore_colour_dentist()
{
	document.getElementById('dentist').style.color = "#555";
}

function change_colour_frontoffice()
{
	document.getElementById('frontoffice').style.color = "#009900";
}

function restore_colour_frontoffice()
{
	document.getElementById('frontoffice').style.color = "#555";
}

function change_colour_settings()
{
	document.getElementById('settings').style.color = "#FF0000";
}
function restore_colour_settings()
{
	document.getElementById('settings').style.color = "#555";
}