/*
SQLyog Ultimate v8.55 
MySQL - 5.5.24-log : Database - pam_dental
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
/*Table structure for table `ada_code_treatment_options` */

CREATE TABLE `ada_code_treatment_options` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ada_code_id` int(11) NOT NULL COMMENT 'ADA Code ID',
  `treat_id` int(11) NOT NULL COMMENT 'Treatment ID',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=94 DEFAULT CHARSET=latin1;

/*Data for the table `ada_code_treatment_options` */

insert  into `ada_code_treatment_options`(`id`,`ada_code_id`,`treat_id`) values (1,1,1),(2,1,2),(3,1,3),(4,2,4),(5,2,5),(6,2,6),(7,3,7),(8,3,8),(9,3,9),(10,4,10),(11,4,11),(12,4,12),(13,5,13),(14,5,14),(15,5,15),(16,6,16),(17,6,17),(18,6,18),(19,7,19),(20,7,20),(21,7,21),(22,8,22),(23,8,23),(24,8,24),(25,9,25),(26,9,26),(27,9,27),(28,10,28),(29,10,29),(30,10,30),(31,11,31),(32,11,32),(33,11,33),(34,12,34),(35,12,35),(36,12,36),(37,13,37),(38,13,38),(39,13,39),(40,14,40),(41,14,41),(42,14,42),(43,15,43),(44,15,44),(45,15,45),(46,16,46),(47,16,47),(48,16,48),(49,17,49),(50,17,50),(51,17,51),(52,18,52),(53,18,53),(54,18,54),(55,19,55),(56,19,56),(57,19,57),(58,20,58),(59,20,59),(60,20,60),(61,21,61),(62,21,62),(63,21,63),(64,22,64),(65,22,65),(66,22,66),(67,23,67),(68,23,68),(69,23,69),(70,24,70),(71,24,71),(72,24,72),(73,25,73),(74,25,74),(75,25,75),(76,26,76),(77,26,77),(78,26,78),(79,27,79),(80,27,80),(81,27,81),(82,28,82),(83,28,83),(84,28,84),(85,29,85),(86,29,86),(87,29,87),(88,30,88),(89,30,89),(90,30,90),(91,31,91),(92,31,92),(93,31,93);

/*Table structure for table `ada_codes` */

CREATE TABLE `ada_codes` (
  `ada_code_id` int(11) NOT NULL AUTO_INCREMENT,
  `ada_code` varchar(10) CHARACTER SET utf8 NOT NULL COMMENT 'ADA Code',
  `description` text NOT NULL COMMENT 'ADA Code description',
  `test` int(11) DEFAULT NULL,
  PRIMARY KEY (`ada_code_id`)
) ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=latin1;

/*Data for the table `ada_codes` */

insert  into `ada_codes`(`ada_code_id`,`ada_code`,`description`,`test`) values (1,'D0277','Vertical Bitewings ',NULL),(2,'D0150','Comprehensive Oral Evaluation',NULL),(3,'D0363','Cone Bean ',NULL),(4,'D1110','Prophylaxis ',NULL),(5,'D1120','Prophylaxis - Child',NULL),(6,'D1351','Sealant per tooth',NULL),(7,'D2330','Resin ',NULL),(8,'D2331','Resin ',NULL),(9,'D2332','Resin ',NULL),(10,'D2335','Resin ',NULL),(11,'D2962','Veneer (Lab)',NULL),(12,'D2540','Onlay ',NULL),(13,'D2542','Onlay ',NULL),(14,'D2543','Onlay ',NULL),(15,'D2544','Onlay ',NULL),(16,'D2642','Onlay ',NULL),(17,'D2643','Onlay ',NULL),(18,'D2644','Onlay ',NULL),(19,'D2740','Crown- porcelain/ceramic substructure',NULL),(20,'D2752','Crown- porcelain fused to noble metal',NULL),(21,'D6058','Abutment supported porcelain/ceramic',NULL),(22,'D6242','Pontic ',NULL),(23,'D6752','Retainer crow-porcelain fused to noble meta',NULL),(24,'D2950','Crown buildup, Including any pins',NULL),(25,'D3310','Root Canal Therapy ',NULL),(26,'D3320','Root Canal Therapy ',NULL),(27,'D3330','Root Canal Therapy ',NULL),(28,'D4341','Perio scale & root planning ',NULL),(29,'D4342','Perio scale & root planning ',NULL),(30,'D4910','Periodontal maintenance',NULL),(31,'D7210','Extraction ',NULL);

/*Table structure for table `admin_login` */

CREATE TABLE `admin_login` (
  `admin_login_id` int(11) NOT NULL AUTO_INCREMENT,
  `first_name` varchar(50) NOT NULL COMMENT 'First Name',
  `last_name` varchar(50) NOT NULL COMMENT 'Last Name',
  `middle_initial` varchar(50) DEFAULT NULL COMMENT 'Middle Initial',
  `email` varchar(50) NOT NULL COMMENT 'Email address',
  `username` varchar(50) NOT NULL COMMENT 'ADMIN Username',
  `password` varchar(50) NOT NULL COMMENT 'Password (md5 Encrypted)',
  `sign_up_date` datetime NOT NULL COMMENT 'Sign up date',
  `last_login` datetime NOT NULL COMMENT 'Last login date',
  PRIMARY KEY (`admin_login_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

/*Data for the table `admin_login` */

insert  into `admin_login`(`admin_login_id`,`first_name`,`last_name`,`middle_initial`,`email`,`username`,`password`,`sign_up_date`,`last_login`) values (1,'Admin','Admin','A','admin@pam.com','admin','5f4dcc3b5aa765d61d8327deb882cf99','2012-10-22 13:33:00','2012-10-22 13:33:00');

/*Table structure for table `billing` */

CREATE TABLE `billing` (
  `billing_id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'ID (Primary Key)',
  `patient_login_id` int(11) NOT NULL COMMENT 'Patient Login ID (Foreign Key)',
  `treat_id` int(11) NOT NULL COMMENT 'Treatment ID',
  `treatment_price` float(7,2) NOT NULL COMMENT 'Treatment Price (In US $)',
  `insurance` float(7,2) NOT NULL COMMENT 'Insurance (In US $)',
  `deductable` float(7,2) NOT NULL COMMENT 'Deductable (In US $)',
  `total_amount_paid` float(7,2) NOT NULL COMMENT 'Total Amount Paid by Patient (In US $)',
  `billing_date` datetime NOT NULL COMMENT 'Date of Billing',
  PRIMARY KEY (`billing_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `billing` */

/*Table structure for table `dentist_login` */

CREATE TABLE `dentist_login` (
  `dentist_login_id` int(11) NOT NULL AUTO_INCREMENT,
  `first_name` varchar(50) NOT NULL COMMENT 'First Name',
  `last_name` varchar(50) NOT NULL COMMENT 'Last Name',
  `middle_initial` varchar(50) DEFAULT NULL COMMENT 'Middle Initial',
  `email` varchar(50) NOT NULL COMMENT 'Email address',
  `username` varchar(50) NOT NULL COMMENT 'Dentist Username',
  `password` varchar(50) NOT NULL COMMENT 'Password (md5 Encrypted)',
  `sign_up_date` datetime NOT NULL COMMENT 'Sign up date',
  `last_login` datetime NOT NULL COMMENT 'Last login',
  PRIMARY KEY (`dentist_login_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

/*Data for the table `dentist_login` */

insert  into `dentist_login`(`dentist_login_id`,`first_name`,`last_name`,`middle_initial`,`email`,`username`,`password`,`sign_up_date`,`last_login`) values (1,'Dentist','Dentist','D','info@pamdental.com','dentist','5f4dcc3b5aa765d61d8327deb882cf99','2012-10-22 16:19:00','2012-10-25 05:47:33');

/*Table structure for table `front_office_login` */

CREATE TABLE `front_office_login` (
  `front_office_login_id` int(11) NOT NULL AUTO_INCREMENT,
  `first_name` varchar(50) NOT NULL COMMENT 'First Name',
  `last_name` varchar(50) NOT NULL COMMENT 'Last Name',
  `middle_initial` varchar(50) DEFAULT NULL COMMENT 'Middle Initial',
  `email` varchar(50) NOT NULL COMMENT 'Email address',
  `username` varchar(50) NOT NULL COMMENT 'Username',
  `password` varchar(50) NOT NULL COMMENT 'Password (md5 Encrypted)',
  `sign_up_date` datetime NOT NULL COMMENT 'Sign up date',
  `last_login` datetime NOT NULL COMMENT 'Last login',
  PRIMARY KEY (`front_office_login_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `front_office_login` */

/*Table structure for table `health_conditions` */

CREATE TABLE `health_conditions` (
  `health_con_id` int(11) NOT NULL AUTO_INCREMENT,
  `description` text NOT NULL COMMENT 'Health condition description',
  PRIMARY KEY (`health_con_id`)
) ENGINE=InnoDB AUTO_INCREMENT=52 DEFAULT CHARSET=latin1;

/*Data for the table `health_conditions` */

insert  into `health_conditions`(`health_con_id`,`description`) values (1,'Allergies or Sinus Problems'),(2,'Latex Sensitivity'),(3,'Medication Allergy'),(4,'&nbsp;&nbsp;&nbsp;&nbsp;Local anesthetics'),(5,'&nbsp;&nbsp;&nbsp;&nbsp;Penicillin ? Other Antibiotics'),(6,'&nbsp;&nbsp;&nbsp;&nbsp;Aspirin - Tylenol (circle)'),(7,'&nbsp;&nbsp;&nbsp;&nbsp;Codeine or other Narcotics'),(8,'&nbsp;&nbsp;&nbsp;&nbsp;Valium or Sedatives'),(9,'Asthma/ Emphysema / Lung Problems'),(10,'Cardiovascular Disease'),(11,'&nbsp;&nbsp;&nbsp;&nbsp;Blood Pressure Problems'),(12,'&nbsp;&nbsp;&nbsp;&nbsp;pAnemia'),(13,'&nbsp;&nbsp;&nbsp;&nbsp;Irregular Heart Beat'),(14,'&nbsp;&nbsp;&nbsp;&nbsp;Chest Pain with Exertion'),(15,'&nbsp;&nbsp;&nbsp;&nbsp;Rheumatic Fever'),(16,'&nbsp;&nbsp;&nbsp;&nbsp;Heart Murmur'),(17,'&nbsp;&nbsp;&nbsp;&nbsp;Are you required to Pre-Medicate'),(18,'&nbsp;&nbsp;&nbsp;&nbsp;Heart Attack, Heart Surgery, Angioplasty, Heart Stint, etc'),(19,'&nbsp;&nbsp;&nbsp;&nbsp;Stroke'),(20,'&nbsp;&nbsp;&nbsp;&nbsp;Blood Problems or Hemophilia'),(21,'Nervous System'),(22,'&nbsp;&nbsp;&nbsp;&nbsp;High Stress or Ulcers'),(23,'&nbsp;&nbsp;&nbsp;&nbsp;Depression'),(24,'&nbsp;&nbsp;&nbsp;&nbsp;Dental Phobia Fear'),(25,'&nbsp;&nbsp;&nbsp;&nbsp;Psychosis'),(26,'Infectious Diseases'),(27,'&nbsp;&nbsp;&nbsp;&nbsp;Liver Disease or Hepatitis'),(28,'&nbsp;&nbsp;&nbsp;&nbsp;Tuberculosis'),(29,'&nbsp;&nbsp;&nbsp;&nbsp;AIDS or HIV Positive'),(30,'&nbsp;&nbsp;&nbsp;&nbsp;Veneral Disease'),(31,'&nbsp;&nbsp;&nbsp;&nbsp;Other Infections'),(32,'&nbsp;&nbsp;&nbsp;&nbsp;Sore or Enlarged Lymph Nodes'),(33,'Diabetes'),(34,'Epilepsy'),(35,'Cancer / Radiation Tx / Chemo Tx'),(36,'Kidney Disease'),(37,'Jaw Joint Problems'),(38,'Headaches or Migraines'),(39,'Mouth Sores or Biopsies'),(40,'Chronic Fatigue'),(41,'Ongoing or Recurrent Illnesses'),(42,'Glaucoma'),(43,'Weight Loss/Gain'),(44,'Arthritis or Rheumatism'),(45,'Joint or Bone Surgeries'),(46,'Tobacco Use: Packs/day'),(47,'&nbsp;&nbsp;&nbsp;&nbsp;Hospital or Surgery in past 5 years'),(48,'<b>Women</b>: Are you Pregnant'),(49,'&nbsp;&nbsp;&nbsp;&nbsp;Are you planning a pregnancy?'),(50,'&nbsp;&nbsp;&nbsp;&nbsp;Are you a nursing mother?'),(51,'&nbsp;&nbsp;&nbsp;&nbsp;Are you taking birth control pills?');

/*Table structure for table `other_medicines_or_neutricuticals` */

CREATE TABLE `other_medicines_or_neutricuticals` (
  `other_medicine_id` int(11) NOT NULL AUTO_INCREMENT,
  `description` text NOT NULL COMMENT 'Description - Other Medicines or Neutricuticals',
  PRIMARY KEY (`other_medicine_id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

/*Data for the table `other_medicines_or_neutricuticals` */

insert  into `other_medicines_or_neutricuticals`(`other_medicine_id`,`description`) values (1,'Are you taking Tagamet or Antacids?'),(2,'Do you take any herbal supplements?'),(3,'Do you take diet pills?'),(4,'Do you take vitamins?'),(5,'Complications after dental tx or surgery?'),(6,'Do you take aspirin or other blood thiners?'),(7,'Do you use antidepressants or sleeping pills?');

/*Table structure for table `patient_checkup` */

CREATE TABLE `patient_checkup` (
  `patient_checkup_id` int(11) NOT NULL AUTO_INCREMENT,
  `patient_login_id` int(11) NOT NULL COMMENT 'Patient Login ID (Foreign Key)',
  `patient_description` text NOT NULL,
  `notes` text NOT NULL,
  `date` datetime NOT NULL,
  `status` enum('Approved','Canceled','Pending') NOT NULL DEFAULT 'Pending',
  PRIMARY KEY (`patient_checkup_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

/*Data for the table `patient_checkup` */

insert  into `patient_checkup`(`patient_checkup_id`,`patient_login_id`,`patient_description`,`notes`,`date`,`status`) values (1,2,'Test Patient Description........','Test Notes........','2012-10-21 09:50:10','Pending'),(2,1,'test','test','2012-10-23 16:14:56','Pending');

/*Table structure for table `patient_checkup_relation` */

CREATE TABLE `patient_checkup_relation` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `patient_checkup_id` int(11) NOT NULL COMMENT 'ID from ''patient_checkup'' table (Foreign Key)',
  `tooth_id` int(11) NOT NULL,
  `ada_code_id` int(11) NOT NULL,
  `treat_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

/*Data for the table `patient_checkup_relation` */

insert  into `patient_checkup_relation`(`id`,`patient_checkup_id`,`tooth_id`,`ada_code_id`,`treat_id`) values (1,1,8,11,32),(2,2,0,0,0),(3,2,3,2,5),(4,2,6,2,6),(5,2,8,4,12),(6,2,7,3,8),(7,2,10,3,8);

/*Table structure for table `patient_log` */

CREATE TABLE `patient_log` (
  `log_id` int(11) NOT NULL AUTO_INCREMENT,
  `patient_login_id` int(11) NOT NULL COMMENT 'Patient Login ID (Foreign Key)',
  `datetime` datetime NOT NULL COMMENT 'Date & Time',
  `ip_address` varchar(50) NOT NULL COMMENT 'IP Address',
  `activity` text NOT NULL COMMENT 'Activity',
  PRIMARY KEY (`log_id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;

/*Data for the table `patient_log` */

insert  into `patient_log`(`log_id`,`patient_login_id`,`datetime`,`ip_address`,`activity`) values (1,1,'2012-10-22 07:57:43','::1','A new patient signs up with PAM DENTAL.'),(2,1,'2012-10-22 07:59:57','::1','Patient signs out.'),(3,1,'2012-10-23 16:09:03','::1','Patient logs into PAM.'),(4,1,'2012-10-23 16:09:07','::1','Patient logs out of PAM.'),(5,1,'2012-10-24 09:50:04','::1','Patient logs into PAM.'),(6,1,'2012-10-25 14:59:17','::1','Patient logs into PAM.'),(7,1,'2012-10-25 15:31:00','::1','Patient logs out of PAM.'),(8,1,'2012-10-26 06:29:01','::1','Patient logs into PAM.');

/*Table structure for table `patient_login` */

CREATE TABLE `patient_login` (
  `patient_login_id` int(11) NOT NULL AUTO_INCREMENT,
  `first_name` varchar(50) NOT NULL COMMENT 'Patient First Name',
  `last_name` varchar(50) NOT NULL COMMENT 'Patient Last Name',
  `middle_initial` varchar(50) DEFAULT NULL COMMENT 'Patient Middle Initial',
  `email` varchar(50) NOT NULL COMMENT 'Patient Email Address',
  `username` varchar(50) NOT NULL COMMENT 'Patient Username',
  `password` varchar(50) NOT NULL COMMENT 'Patient Password (md5 Encrypted)',
  `sign_up_date` datetime NOT NULL COMMENT 'Date of Sign Up',
  `is_registered` enum('Y','N') NOT NULL DEFAULT 'N' COMMENT 'Registration Form filled? Y - Yes, N - No',
  `last_login` datetime NOT NULL COMMENT 'Date & Time of Last Successful Login',
  PRIMARY KEY (`patient_login_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

/*Data for the table `patient_login` */

insert  into `patient_login`(`patient_login_id`,`first_name`,`last_name`,`middle_initial`,`email`,`username`,`password`,`sign_up_date`,`is_registered`,`last_login`) values (1,'Rohitashva','Rathore','S','rohitashvarathore@gmail.com','rohit*123','9b155486e4c056795dc4774ff16dd7fa','2012-10-22 07:57:43','Y','2012-10-26 06:29:01');

/*Table structure for table `patient_registration` */

CREATE TABLE `patient_registration` (
  `patient_id` int(11) NOT NULL AUTO_INCREMENT,
  `patient_login_id` int(11) NOT NULL COMMENT 'Patient Login ID (Foreign Key)',
  `registration_date` datetime NOT NULL COMMENT 'Date of Registration',
  `p_sex` enum('M','F') NOT NULL COMMENT 'Patient sex:''M'' - Male, ''F'' - Female',
  `p_marital_status` int(11) NOT NULL COMMENT 'Patient - Married, Single, Child or Other',
  `p_marital_status_other` varchar(225) DEFAULT NULL COMMENT 'Patient - If Other',
  `p_ssn` varchar(225) DEFAULT NULL COMMENT 'Patient - Social Security #',
  `p_dln` varchar(225) DEFAULT NULL COMMENT 'Patient - Driving License #',
  `p_dob` date NOT NULL,
  `p_address_street` varchar(225) NOT NULL,
  `p_address_apartment_number` varchar(225) DEFAULT NULL,
  `p_address_city` varchar(225) NOT NULL,
  `p_address_state_id` int(11) NOT NULL,
  `p_address_zipcode` varchar(10) DEFAULT NULL,
  `p_phone_home` varchar(50) DEFAULT NULL,
  `p_phone_work` varchar(50) DEFAULT NULL,
  `p_phone_cell` varchar(50) DEFAULT NULL,
  `p_practice_reference` varchar(225) DEFAULT NULL,
  `p_health_condition` text NOT NULL COMMENT 'Patient - Health Condition',
  `p_other_medicines` text NOT NULL COMMENT 'Patient - Other Medicines or Neutricuticals',
  `p_total_insurance` float(7,2) DEFAULT '0.00' COMMENT 'Patient - Total insurance amount left',
  `srp_following_is_for` enum('S','P') DEFAULT NULL COMMENT '''S'' - Patient''s Spouse, ''P'' - Person responsible for payment',
  `srp_first_name` varchar(225) DEFAULT NULL COMMENT 'Spouse/Responsible party First Name',
  `srp_last_name` varchar(225) DEFAULT NULL COMMENT 'Spouse/Responsible party Last Name',
  `srp_middle_initial` varchar(50) DEFAULT NULL COMMENT 'Spouse/Responsible party Middle Initial',
  `srp_sex` enum('M','F') DEFAULT NULL COMMENT 'Spouse/Responsible party sex:''M'' - Male, ''F'' - Female',
  `srp_marital_status` int(11) DEFAULT NULL COMMENT 'Spouse/Responsible party - Married, Single, Child or Other',
  `srp_marital_status_other` varchar(225) DEFAULT NULL COMMENT 'Spouse/Responsible party - If Other',
  `srp_ssn` varchar(225) DEFAULT NULL COMMENT 'Social Security #',
  `srp_dob` date DEFAULT NULL COMMENT 'Date of Birth',
  `srp_phone_home` varchar(50) DEFAULT NULL,
  `srp_phone_work` varchar(50) DEFAULT NULL,
  `srp_phone_ext` varchar(50) DEFAULT NULL,
  `srp_address_street` varchar(225) DEFAULT NULL,
  `srp_address_apartment_number` varchar(225) DEFAULT NULL,
  `srp_address_city` varchar(225) DEFAULT NULL,
  `srp_address_state_id` int(11) DEFAULT NULL,
  `srp_address_zipcode` varchar(10) DEFAULT NULL,
  `srp_best_time_call` time DEFAULT NULL COMMENT 'Best time to call',
  `e_following_is_for` enum('P','PR') DEFAULT NULL COMMENT '''P'' - Patient, ''PR'' - The person responsible for payment ',
  `e_name` varchar(225) DEFAULT NULL COMMENT 'Employer name',
  `e_occupation` varchar(225) DEFAULT NULL COMMENT 'Employer occupation',
  `e_address_street` varchar(225) DEFAULT NULL,
  `e_address_city` varchar(225) DEFAULT NULL,
  `e_address_state_id` int(11) DEFAULT NULL,
  `e_address_zipcode` varchar(10) DEFAULT NULL,
  `pi_first_name` varchar(225) DEFAULT NULL COMMENT 'Primary insurance - First name',
  `pi_last_name` varchar(225) DEFAULT NULL COMMENT 'Primary insurance - Last name',
  `pi_middle_initial` varchar(50) DEFAULT NULL COMMENT 'Primary insurance - Middle initial',
  `pi_is_insured_patient` enum('Y','N') DEFAULT NULL COMMENT 'Is insured (''Y'' - Yes, ''N'' - No)',
  `pi_dob` date DEFAULT NULL COMMENT 'Date of Birth',
  `pi_id` varchar(225) DEFAULT NULL COMMENT 'ID #',
  `pi_group` varchar(225) DEFAULT NULL COMMENT 'Group #',
  `pi_address_street` varchar(225) DEFAULT NULL,
  `pi_address_city` varchar(225) DEFAULT NULL,
  `pi_address_state_id` int(11) DEFAULT NULL,
  `pi_address_zipcode` varchar(225) DEFAULT NULL,
  `pi_emp_name` varchar(225) DEFAULT NULL COMMENT 'Primary insured''s Employer Name',
  `pi_emp_address_street` varchar(225) DEFAULT NULL,
  `pi_emp_address_city` varchar(225) DEFAULT NULL,
  `pi_emp_address_state_id` int(11) DEFAULT NULL,
  `pi_emp_address_zipcode` varchar(10) DEFAULT NULL,
  `pi_patient_relation` int(11) DEFAULT NULL COMMENT 'Primary insurance - Patient''s relationship to insured',
  `pi_patient_relation_other` varchar(225) DEFAULT NULL COMMENT 'Primary Insurance - If Other relationship with patient',
  `pi_insurance_plan_address` varchar(225) DEFAULT NULL COMMENT 'Primary insurance - Plan Name and Address',
  `si_first_name` varchar(225) DEFAULT NULL COMMENT 'Secondary insurance - First name',
  `si_last_name` varchar(225) DEFAULT NULL COMMENT 'Secondary insurance - Last name',
  `si_middle_initial` varchar(50) DEFAULT NULL COMMENT 'Secondary insurance - Middle initial',
  `si_is_insured_patient` enum('Y','N') DEFAULT NULL COMMENT 'Is insured (''Y'' - Yes, ''N'' - No)',
  `si_dob` date DEFAULT NULL COMMENT 'Date of Birth',
  `si_id` varchar(225) DEFAULT NULL COMMENT 'ID #',
  `si_group` varchar(225) DEFAULT NULL COMMENT 'Group #',
  `si_address_street` varchar(225) DEFAULT NULL,
  `si_address_city` varchar(225) DEFAULT NULL,
  `si_address_state_id` int(11) DEFAULT NULL,
  `si_address_zipcode` varchar(10) DEFAULT NULL,
  `si_emp_name` varchar(225) DEFAULT NULL COMMENT 'Secondary insured''s Employer Name',
  `si_emp_address_street` varchar(225) DEFAULT NULL,
  `si_emp_address_city` varchar(225) DEFAULT NULL,
  `si_emp_address_state_id` int(50) DEFAULT NULL,
  `si_emp_address_zipcode` varchar(10) DEFAULT NULL,
  `si_patient_relation` int(11) DEFAULT NULL COMMENT 'Secondary insurance - Patient''s relationship to insured',
  `si_patient_relation_other` varchar(225) DEFAULT NULL COMMENT 'Secondary Insurance - If Other relationship with patient',
  `si_insurance_plan_address` varchar(225) DEFAULT NULL COMMENT 'Secondary insurance - Plan Name and Address',
  `physician_health_prof_name_1` varchar(225) DEFAULT NULL COMMENT 'Physician /Health Professional 1',
  `physician_health_prof_name_2` varchar(225) DEFAULT NULL COMMENT 'Physician /Health Professional 2',
  `physician_health_prof_name_3` varchar(225) DEFAULT NULL COMMENT 'Physician /Health Professional 3',
  `physician_health_prof_name_4` varchar(225) DEFAULT NULL COMMENT 'Physician /Health Professional 4',
  `physician_health_prof_phone_1` varchar(225) DEFAULT NULL COMMENT 'Physician /Health Professional Phone 1',
  `physician_health_prof_phone_2` varchar(225) DEFAULT NULL COMMENT 'Physician /Health Professional Phone 2',
  `physician_health_prof_phone_3` varchar(225) DEFAULT NULL COMMENT 'Physician /Health Professional Phone 3',
  `physician_health_prof_phone_4` varchar(225) DEFAULT NULL COMMENT 'Physician /Health Professional Phone 4',
  `health_condition_other_1` varchar(225) DEFAULT NULL,
  `health_condition_other_2` varchar(225) DEFAULT NULL,
  `med_dosage_1` varchar(225) DEFAULT NULL COMMENT 'Medications & Dosages 1',
  `med_dosage_2` varchar(225) DEFAULT NULL COMMENT 'Medications & Dosages 2',
  `med_dosage_3` varchar(225) DEFAULT NULL COMMENT 'Medications & Dosages 3',
  `med_dosage_4` varchar(225) DEFAULT NULL COMMENT 'Medications & Dosages 4',
  `med_dosage_5` varchar(225) DEFAULT NULL COMMENT 'Medications & Dosages 5',
  `med_dosage_6` varchar(225) DEFAULT NULL COMMENT 'Medications & Dosages 6',
  PRIMARY KEY (`patient_id`),
  UNIQUE KEY `patient_login_id` (`patient_login_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

/*Data for the table `patient_registration` */

insert  into `patient_registration`(`patient_id`,`patient_login_id`,`registration_date`,`p_sex`,`p_marital_status`,`p_marital_status_other`,`p_ssn`,`p_dln`,`p_dob`,`p_address_street`,`p_address_apartment_number`,`p_address_city`,`p_address_state_id`,`p_address_zipcode`,`p_phone_home`,`p_phone_work`,`p_phone_cell`,`p_practice_reference`,`p_health_condition`,`p_other_medicines`,`p_total_insurance`,`srp_following_is_for`,`srp_first_name`,`srp_last_name`,`srp_middle_initial`,`srp_sex`,`srp_marital_status`,`srp_marital_status_other`,`srp_ssn`,`srp_dob`,`srp_phone_home`,`srp_phone_work`,`srp_phone_ext`,`srp_address_street`,`srp_address_apartment_number`,`srp_address_city`,`srp_address_state_id`,`srp_address_zipcode`,`srp_best_time_call`,`e_following_is_for`,`e_name`,`e_occupation`,`e_address_street`,`e_address_city`,`e_address_state_id`,`e_address_zipcode`,`pi_first_name`,`pi_last_name`,`pi_middle_initial`,`pi_is_insured_patient`,`pi_dob`,`pi_id`,`pi_group`,`pi_address_street`,`pi_address_city`,`pi_address_state_id`,`pi_address_zipcode`,`pi_emp_name`,`pi_emp_address_street`,`pi_emp_address_city`,`pi_emp_address_state_id`,`pi_emp_address_zipcode`,`pi_patient_relation`,`pi_patient_relation_other`,`pi_insurance_plan_address`,`si_first_name`,`si_last_name`,`si_middle_initial`,`si_is_insured_patient`,`si_dob`,`si_id`,`si_group`,`si_address_street`,`si_address_city`,`si_address_state_id`,`si_address_zipcode`,`si_emp_name`,`si_emp_address_street`,`si_emp_address_city`,`si_emp_address_state_id`,`si_emp_address_zipcode`,`si_patient_relation`,`si_patient_relation_other`,`si_insurance_plan_address`,`physician_health_prof_name_1`,`physician_health_prof_name_2`,`physician_health_prof_name_3`,`physician_health_prof_name_4`,`physician_health_prof_phone_1`,`physician_health_prof_phone_2`,`physician_health_prof_phone_3`,`physician_health_prof_phone_4`,`health_condition_other_1`,`health_condition_other_2`,`med_dosage_1`,`med_dosage_2`,`med_dosage_3`,`med_dosage_4`,`med_dosage_5`,`med_dosage_6`) values (1,1,'2012-10-22 07:59:46','M',1,'','123456789','123456789','2012-10-11','Govind Niwas','162','Houston',3,NULL,'9828314649','9828314649','9828314649','','a:4:{i:0;s:1:\"1\";i:1;s:1:\"2\";i:2;s:1:\"3\";i:3;s:1:\"4\";}','a:3:{i:0;s:1:\"1\";i:1;s:1:\"2\";i:2;s:1:\"3\";}',0.00,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);

/*Table structure for table `schedule` */

CREATE TABLE `schedule` (
  `schedule_id` int(11) NOT NULL AUTO_INCREMENT,
  `schedule_status` enum('Pending','Reviewed','Canceled') NOT NULL,
  `visit_date` date NOT NULL,
  `start_time` time NOT NULL,
  `end_time` time NOT NULL,
  `patient_id` int(11) NOT NULL,
  `visit_type` enum('Consultation','Check-up','Cleaning','Whitening','Filling / one tooth') NOT NULL,
  `visit_note` text NOT NULL,
  `added_date` datetime NOT NULL,
  `last_modified` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `patient_checkup_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`schedule_id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;

/*Data for the table `schedule` */

insert  into `schedule`(`schedule_id`,`schedule_status`,`visit_date`,`start_time`,`end_time`,`patient_id`,`visit_type`,`visit_note`,`added_date`,`last_modified`,`patient_checkup_id`) values (3,'Pending','2012-10-24','11:15:00','11:45:00',1,'Consultation','test from CI','2012-10-23 09:52:27','0000-00-00 00:00:00',NULL),(4,'Reviewed','2012-10-24','08:45:00','09:15:00',1,'Consultation','testing','2012-10-23 15:38:59','0000-00-00 00:00:00',NULL),(5,'Pending','2012-10-24','07:00:00','07:30:00',1,'Consultation','','2012-10-23 15:39:14','0000-00-00 00:00:00',NULL),(6,'Pending','2012-10-22','09:45:00','10:15:00',1,'Consultation','test','2012-10-23 15:41:07','0000-00-00 00:00:00',NULL),(7,'Reviewed','2012-10-22','08:00:00','08:30:00',1,'Consultation','','2012-10-23 16:27:22','0000-00-00 00:00:00',NULL),(8,'Reviewed','2012-10-25','12:30:00','13:00:00',2,'Consultation','','2012-10-24 14:10:51','0000-00-00 00:00:00',NULL);

/*Table structure for table `teeth` */

CREATE TABLE `teeth` (
  `tooth_id` int(11) NOT NULL AUTO_INCREMENT,
  `description` text NOT NULL COMMENT 'Tooth description',
  PRIMARY KEY (`tooth_id`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=latin1;

/*Data for the table `teeth` */

insert  into `teeth`(`tooth_id`,`description`) values (1,'Upper-Central Incisor'),(2,'Upper-Lateral Incisor'),(3,'Upper-Canine (Cuspid)'),(4,'Upper-First Premolar (First bicuspid)'),(5,'Upper-Second premolar (Second bicuspid)'),(6,'Upper-First Molar'),(7,'Upper-Second Molar'),(8,'Upper-Third Molar (Wisdom Tooth)'),(9,'Lower-Central Incisor'),(10,'Lower-Lateral Incisor'),(11,'Lower-Canine (Cuspid)'),(12,'Lower-First Premolar (First bicuspid)'),(13,'Lower-Second premolar (Second bicuspid)'),(14,'Lower-First Molar'),(15,'Lower-Second Molar'),(16,'Lower-Third Molar (Wisdom Tooth)');

/*Table structure for table `treatment_options` */

CREATE TABLE `treatment_options` (
  `treat_id` int(11) NOT NULL AUTO_INCREMENT,
  `description` text NOT NULL COMMENT 'Treatment description',
  `price` float(7,2) NOT NULL COMMENT 'Treatment price (In US $)',
  `treatment_insurance` float(7,2) NOT NULL COMMENT 'Insurance for procedure/treatment (In US $)',
  `treatment_deductable` float(7,2) NOT NULL COMMENT 'Deductable for procedure/treatment (In US $)',
  `pros` text NOT NULL COMMENT 'Treatment pros.',
  `cons` text NOT NULL COMMENT 'Treatment cons.',
  PRIMARY KEY (`treat_id`)
) ENGINE=InnoDB AUTO_INCREMENT=94 DEFAULT CHARSET=latin1;

/*Data for the table `treatment_options` */

insert  into `treatment_options`(`treat_id`,`description`,`price`,`treatment_insurance`,`treatment_deductable`,`pros`,`cons`) values (1,'This is Dummy Content 1',93.00,0.00,0.00,'',''),(2,'This is Dummy Content 1b',93.00,0.00,0.00,'',''),(3,'This is Dummy Content 1c',93.00,0.00,0.00,'',''),(4,'This is Dummy Content 2',110.00,0.00,0.00,'',''),(5,'This is Dummy Content 2b',110.00,0.00,0.00,'',''),(6,'This is Dummy Content 2c',110.00,0.00,0.00,'',''),(7,'This is Dummy Content 3',300.00,0.00,0.00,'',''),(8,'This is Dummy Content 3b',300.00,0.00,0.00,'',''),(9,'This is Dummy Content 3c',300.00,0.00,0.00,'',''),(10,'This is Dummy Content 4',112.00,0.00,0.00,'',''),(11,'This is Dummy Content 4b',112.00,0.00,0.00,'',''),(12,'This is Dummy Content 4c',112.00,0.00,0.00,'',''),(13,'This is Dummy Content 5',71.00,0.00,0.00,'',''),(14,'This is Dummy Content 5b',71.00,0.00,0.00,'',''),(15,'This is Dummy Content 5c',71.00,0.00,0.00,'',''),(16,'This is Dummy Content 6',49.00,0.00,0.00,'',''),(17,'This is Dummy Content 6b',49.00,0.00,0.00,'',''),(18,'This is Dummy Content 6c',49.00,0.00,0.00,'',''),(19,'This is Dummy Content 7',182.00,0.00,0.00,'',''),(20,'This is Dummy Content 7b',182.00,0.00,0.00,'',''),(21,'This is Dummy Content 7c',182.00,0.00,0.00,'',''),(22,'This is Dummy Content 8',232.00,0.00,0.00,'',''),(23,'This is Dummy Content 8b',232.00,0.00,0.00,'',''),(24,'This is Dummy Content 8c',232.00,0.00,0.00,'',''),(25,'This is Dummy Content 9',276.00,0.00,0.00,'',''),(26,'This is Dummy Content 9b',276.00,0.00,0.00,'',''),(27,'This is Dummy Content 9c',276.00,0.00,0.00,'',''),(28,'This is Dummy Content 10',303.00,0.00,0.00,'',''),(29,'This is Dummy Content 10b',303.00,0.00,0.00,'',''),(30,'This is Dummy Content 10c',303.00,0.00,0.00,'',''),(31,'This is Dummy Content 11',1433.00,0.00,0.00,'',''),(32,'This is Dummy Content 11b',1433.00,0.00,0.00,'',''),(33,'This is Dummy Content 11c',1433.00,0.00,0.00,'',''),(34,'This is Dummy Content 12',1014.00,0.00,0.00,'',''),(35,'This is Dummy Content 12b',1014.00,0.00,0.00,'',''),(36,'This is Dummy Content 12c',1014.00,0.00,0.00,'',''),(37,'This is Dummy Content 13',1103.00,0.00,0.00,'',''),(38,'This is Dummy Content 13b',1103.00,0.00,0.00,'',''),(39,'This is Dummy Content 13c',1103.00,0.00,0.00,'',''),(40,'This is Dummy Content 14',1103.00,0.00,0.00,'',''),(41,'This is Dummy Content 14b',1103.00,0.00,0.00,'',''),(42,'This is Dummy Content 14c',1103.00,0.00,0.00,'',''),(43,'This is Dummy Content 15',1103.00,0.00,0.00,'',''),(44,'This is Dummy Content 15b',1103.00,0.00,0.00,'',''),(45,'This is Dummy Content 15c',1103.00,0.00,0.00,'',''),(46,'This is Dummy Content 16',1296.00,0.00,0.00,'',''),(47,'This is Dummy Content 16b',1296.00,0.00,0.00,'',''),(48,'This is Dummy Content 16c',1296.00,0.00,0.00,'',''),(49,'This is Dummy Content 17',1296.00,0.00,0.00,'',''),(50,'This is Dummy Content 17b',1296.00,0.00,0.00,'',''),(51,'This is Dummy Content 17c',1296.00,0.00,0.00,'',''),(52,'This is Dummy Content 18',1296.00,0.00,0.00,'',''),(53,'This is Dummy Content 18b',1296.00,0.00,0.00,'',''),(54,'This is Dummy Content 18c',1296.00,0.00,0.00,'',''),(55,'This is Dummy Content 19',1379.00,0.00,0.00,'',''),(56,'This is Dummy Content 19b',1379.00,0.00,0.00,'',''),(57,'This is Dummy Content 19c',1379.00,0.00,0.00,'',''),(58,'This is Dummy Content 20',551.00,0.00,0.00,'',''),(59,'This is Dummy Content 20b',551.00,0.00,0.00,'',''),(60,'This is Dummy Content 20c',551.00,0.00,0.00,'',''),(61,'This is Dummy Content 21',1544.00,0.00,0.00,'',''),(62,'This is Dummy Content 21b',1544.00,0.00,0.00,'',''),(63,'This is Dummy Content 21c',1544.00,0.00,0.00,'',''),(64,'This is Dummy Content 22',882.00,0.00,0.00,'',''),(65,'This is Dummy Content 22b',882.00,0.00,0.00,'',''),(66,'This is Dummy Content 22c',882.00,0.00,0.00,'',''),(67,'This is Dummy Content 23',882.00,0.00,0.00,'',''),(68,'This is Dummy Content 23b',882.00,0.00,0.00,'',''),(69,'This is Dummy Content 23c',882.00,0.00,0.00,'',''),(70,'This is Dummy Content 24',287.00,0.00,0.00,'',''),(71,'This is Dummy Content 24b',287.00,0.00,0.00,'',''),(72,'This is Dummy Content 24c',287.00,0.00,0.00,'',''),(73,'This is Dummy Content 25',772.00,0.00,0.00,'',''),(74,'This is Dummy Content 25b',772.00,0.00,0.00,'',''),(75,'This is Dummy Content 25c',772.00,0.00,0.00,'',''),(76,'This is Dummy Content 26',883.00,0.00,0.00,'',''),(77,'This is Dummy Content 26b',883.00,0.00,0.00,'',''),(78,'This is Dummy Content 26c',883.00,0.00,0.00,'',''),(79,'This is Dummy Content 27',1450.00,0.00,0.00,'',''),(80,'This is Dummy Content 27b',1450.00,0.00,0.00,'',''),(81,'This is Dummy Content 27c',1450.00,0.00,0.00,'',''),(82,'This is Dummy Content 28',265.00,0.00,0.00,'',''),(83,'This is Dummy Content 28b',265.00,0.00,0.00,'',''),(84,'This is Dummy Content 28c',265.00,0.00,0.00,'',''),(85,'This is Dummy Content 29',193.00,0.00,0.00,'',''),(86,'This is Dummy Content 29b',193.00,0.00,0.00,'',''),(87,'This is Dummy Content 29c',193.00,0.00,0.00,'',''),(88,'This is Dummy Content 30',193.00,0.00,0.00,'',''),(89,'This is Dummy Content 30b',193.00,0.00,0.00,'',''),(90,'This is Dummy Content 30c',193.00,0.00,0.00,'',''),(91,'This is Dummy Content 31',292.00,0.00,0.00,'',''),(92,'This is Dummy Content 31b',292.00,0.00,0.00,'',''),(93,'This is Dummy Content 31c',292.00,0.00,0.00,'','');

/*Table structure for table `us_states` */

CREATE TABLE `us_states` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `state` varchar(100) NOT NULL,
  `state_abbr` varchar(8) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=52 DEFAULT CHARSET=latin1;

/*Data for the table `us_states` */

insert  into `us_states`(`id`,`state`,`state_abbr`) values (1,'Alabama','AL'),(2,'Alaska','AK'),(3,'Arizona','AZ'),(4,'Arkansas','AR'),(5,'California','CA'),(6,'Colorado','CO'),(7,'Connecticut','CT'),(8,'Delaware','DE'),(9,'District of Columbia','DC'),(10,'Florida','FL'),(11,'Georgia','GA'),(12,'Hawaii','HI'),(13,'Idaho','ID'),(14,'Illinois','IL'),(15,'Indiana','IN'),(16,'Iowa','IA'),(17,'Kansas','KS'),(18,'Kentucky','KY'),(19,'Louisiana','LA'),(20,'Maine','ME'),(21,'Maryland','MD'),(22,'Massachusetts','MA'),(23,'Michigan','MI'),(24,'Minnesota','MN'),(25,'Mississippi','MS'),(26,'Missouri','MO'),(27,'Montana','MT'),(28,'Nebraska','NE'),(29,'Nevada','NV'),(30,'New Hampshire','NH'),(31,'New Jersey','NJ'),(32,'New Mexico','NM'),(33,'New York','NY'),(34,'North Carolina','NC'),(35,'North Dakota','ND'),(36,'Ohio','OH'),(37,'Oklahoma','OK'),(38,'Oregon','OR'),(39,'Pennsylvania','PA'),(40,'Rhode Island','RI'),(41,'South Carolina','SC'),(42,'South Dakota','SD'),(43,'Tennessee','TN'),(44,'Texas','TX'),(45,'Utah','UT'),(46,'Vermont','VT'),(47,'Virginia','VA'),(48,'Washington','WA'),(49,'West Virginia','WV'),(50,'Wisconsin','WI'),(51,'Wyoming','WY');

/*Table structure for table `patient_data` */

DROP TABLE IF EXISTS `patient_data`;

/*!50001 CREATE TABLE  `patient_data`(
 `patient_login_id` int(11) ,
 `first_name` varchar(50) ,
 `last_name` varchar(50) ,
 `middle_initial` varchar(50) ,
 `email` varchar(50) ,
 `username` varchar(50) ,
 `password` varchar(50) ,
 `registration_date` datetime ,
 `p_sex` enum('M','F') ,
 `p_ssn` varchar(225) ,
 `p_dln` varchar(225) ,
 `p_dob` date ,
 `p_address_street` varchar(225) ,
 `p_address_apartment_number` varchar(225) ,
 `p_address_city` varchar(225) ,
 `p_address_state_id` int(11) ,
 `p_address_zipcode` varchar(10) ,
 `p_phone_home` varchar(50) ,
 `p_total_insurance` float(7,2) 
)*/;

/*View structure for view patient_data */

/*!50001 DROP TABLE IF EXISTS `patient_data` */;
/*!50001 CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `patient_data` AS select `patient_login`.`patient_login_id` AS `patient_login_id`,`patient_login`.`first_name` AS `first_name`,`patient_login`.`last_name` AS `last_name`,`patient_login`.`middle_initial` AS `middle_initial`,`patient_login`.`email` AS `email`,`patient_login`.`username` AS `username`,`patient_login`.`password` AS `password`,`patient_registration`.`registration_date` AS `registration_date`,`patient_registration`.`p_sex` AS `p_sex`,`patient_registration`.`p_ssn` AS `p_ssn`,`patient_registration`.`p_dln` AS `p_dln`,`patient_registration`.`p_dob` AS `p_dob`,`patient_registration`.`p_address_street` AS `p_address_street`,`patient_registration`.`p_address_apartment_number` AS `p_address_apartment_number`,`patient_registration`.`p_address_city` AS `p_address_city`,`patient_registration`.`p_address_state_id` AS `p_address_state_id`,`patient_registration`.`p_address_zipcode` AS `p_address_zipcode`,`patient_registration`.`p_phone_home` AS `p_phone_home`,`patient_registration`.`p_total_insurance` AS `p_total_insurance` from (`patient_login` join `patient_registration` on((`patient_login`.`patient_login_id` = `patient_registration`.`patient_login_id`))) where (`patient_login`.`is_registered` = 'Y') */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
